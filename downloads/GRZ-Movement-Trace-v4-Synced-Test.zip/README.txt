GRZ Movement Trace v4 - paired client/server timelines

Standalone diagnostic addon. GRZ_Movement is NOT required. It does not change movement, camera, stamina or engine synchronization. It adds a small timestamp RPC exchange every two seconds for the selected player, plus sampled file logging.

INSTALL
Stop both processes. Replace ONLY GRZ_MovementTrace.pbo on client and server, remove older duplicate trace PBOs, sign normally if required, and load the same addon on BOTH sides (not serverMod-only). Keep the current movement/mod configuration unchanged.
Server JSON remains required and is included with Enabled=true, TargetPlayerName=blake. Place it at:
C:\Program Files (x86)\CFTools Software GmbH\Architect\Agent\deployments\GunRunnerZTest2\profiles\GRZMovementTrace.json
That directory must be the actual server -profiles folder. No client JSON required. Restart both.

OUTPUT
Server: $profile:GRZMovementTrace-server.log
Client: $profile:GRZMovementTrace-client.log (your recent logs used C:\Users\hunte\AppData\Local\DayZ)
Logs append; move old files aside before a fresh session. Startup marker says v4.

ALIGNMENT
Both streams use a shared capture ID. GRZSYNC markers retain client-send, server-receive, server-send and client-receive timestamps. Client records include aligned_ms (estimated server clock) after a valid response and clock_bound_ms (half the lowest observed network RTT, excluding measured server processing). Server records use its actual process clock for aligned_ms. Earlier client samples say clock=pending and can be aligned offline using subsequent markers.
The midpoint estimate assumes symmetric network delay; bounds retain the uncertainty from asymmetric delay. Clocks can drift and later RTT can differ; raw markers allow re-estimation over the recording. Do not compare seq values as simultaneous frames or treat this as perfect clock sync. Logging happens at most once per 100ms of process time, including during replay. Independent sample times remain; use time alignment/interpolation, not matching sample indexes.

REPRO
After joining, stand still three seconds, do your usual Shift+W / alternating Q+A and E+D moonwalk, stand still three seconds and repeat. Record a short clip if possible. Tracing stops after 1200 samples per player instance (roughly two minutes). Send BOTH logs from that same session. Server capture starts only after a validated marker from the selected player's client.

SECURITY/OVERHEAD
Server accepts synchronization markers only from the selected player's own identity and rate-limits them. Other RPCs retain inherited handling. No player names/account IDs are written to trace samples. Diagnostic logging adds I/O/network overhead; remove the addon after the controlled test.

VALIDATION
Timing equations checked with known clock offsets, asymmetric network delay and server processing delay. Package checksums/source round-trips, client/SERVER preprocessing, no movement-write API scan, no GRZ movement dependency, short log expressions and ZIP integrity passed. No DayZ Enforce compiler or multiplayer runtime execution was available; check for script errors and the v4 startup marker.
