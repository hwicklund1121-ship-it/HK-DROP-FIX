#ifndef SERVER
modded class MissionGameplay
{
    override void OnMissionStart()
    {
        super.OnMissionStart();
        if (GetGame().IsClient())
        {
            GRZMovementTraceLog.Write("[GRZMOVE] CLIENT trace addon v4 loaded. No client JSON required. Sync handshakes supply shared capture IDs and estimated server times.");
            Print("[GRZMOVE] Client trace v4 loaded; output: $profile:GRZMovementTrace-client.log");
        }
    }
}
#endif
