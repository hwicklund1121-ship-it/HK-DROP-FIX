// Temporary read-only diagnostic addon. Does not change movement or camera state.
class GRZMovementTraceConfig
{
    bool Enabled = false;
    string TargetPlayerName = "";
    private static ref GRZMovementTraceConfig s_Config;

    static GRZMovementTraceConfig Get()
    {
        if (!s_Config)
        {
            s_Config = new GRZMovementTraceConfig();
            string path = "$profile:GRZMovementTrace.json";
            if (FileExist(path))
            {
                GRZMovementTraceConfig loaded = new GRZMovementTraceConfig();
                string error;
                if (JsonFileLoader<GRZMovementTraceConfig>.LoadFile(path, loaded, error) && loaded)
                    s_Config = loaded;
                else
                    Print("[GRZMOVE] Configuration could not be loaded; trace disabled. " + error);
            }
        }
        return s_Config;
    }
}

// Both files resolve through the actual -profiles directory of each process.
class GRZMovementTraceLog
{
    private static bool s_WriteErrorReported;

    static void Write(string text)
    {
        string path = "$profile:GRZMovementTrace-client.log";
        if (GetGame().IsServer())
            path = "$profile:GRZMovementTrace-server.log";
        FileHandle file = OpenFile(path, FileMode.APPEND);
        if (!file)
        {
            if (!s_WriteErrorReported)
            {
                Print("[GRZMOVE] Cannot open diagnostic file: " + path);
                s_WriteErrorReported = true;
            }
            return;
        }
        FPrintln(file, text);
        CloseFile(file);
    }
}

modded class PlayerBase
{
    private int m_GRZTraceCount;
    private int m_GRZTraceLastTime;
    private vector m_GRZTraceLastPosition;
    private string m_GRZTraceCapture;
    private int m_GRZTraceLastPing;
    private int m_GRZTraceLastAcceptedPing;
    private int m_GRZTracePingId;
    private bool m_GRZTraceClockReady;
    private float m_GRZTraceBestRtt = 1000000;
    private float m_GRZTraceClockOffset;
    private static const int GRZ_TRACE_PING = 1789346201;
    private static const int GRZ_TRACE_PONG = 1789346202;

    private bool GRZTraceServerSelected()
    {
        GRZMovementTraceConfig settings = GRZMovementTraceConfig.Get();
        if (!settings.Enabled || settings.TargetPlayerName == "")
            return false;
        PlayerIdentity identity = GetIdentity();
        return identity && identity.GetName() == settings.TargetPlayerName;
    }

    private void GRZTracePing(int now)
    {
        if (m_GRZTraceCapture == "")
        {
            int low, high;
            GetNetworkID(low, high);
            m_GRZTraceCapture = low.ToString() + "-" + high.ToString();
            m_GRZTraceCapture = m_GRZTraceCapture + "-" + now.ToString();
        }
        if (m_GRZTraceLastPing != 0 && now - m_GRZTraceLastPing < 2000)
            return;
        m_GRZTraceLastPing = now;
        m_GRZTracePingId++;
        ScriptRPC request = new ScriptRPC();
        request.Write(m_GRZTraceCapture);
        request.Write(m_GRZTracePingId);
        request.Write(now);
        request.Send(this, GRZ_TRACE_PING, true);
    }

    override void OnRPC(PlayerIdentity sender, int rpc_type, ParamsReadContext ctx)
    {
        if (rpc_type != GRZ_TRACE_PING && rpc_type != GRZ_TRACE_PONG)
        {
            super.OnRPC(sender, rpc_type, ctx);
            return;
        }
        int now = GetGame().GetTime();
        string capture;
        int marker, clientSent;
        if (rpc_type == GRZ_TRACE_PING)
        {
            if (!GetGame().IsServer() || !GRZTraceServerSelected())
                return;
            PlayerIdentity owner = GetIdentity();
            if (!sender || !owner || sender.GetId() != owner.GetId())
                return;
            if (m_GRZTraceLastAcceptedPing != 0 && now - m_GRZTraceLastAcceptedPing < 1000)
                return;
            if (!ctx.Read(capture) || !ctx.Read(marker) || !ctx.Read(clientSent))
                return;
            if (capture == "" || capture.Length() > 80)
                return;
            m_GRZTraceLastAcceptedPing = now;
            if (capture != m_GRZTraceCapture)
            {
                m_GRZTraceCapture = capture;
                m_GRZTraceCount = 0;
                m_GRZTraceLastTime = 0;
            }
            int serverSent = GetGame().GetTime();
            ScriptRPC reply = new ScriptRPC();
            reply.Write(capture);
            reply.Write(marker);
            reply.Write(clientSent);
            reply.Write(now);
            reply.Write(serverSent);
            reply.Send(this, GRZ_TRACE_PONG, true, sender);
            string serverRecord = "[GRZSYNC] side=SERVER capture=" + capture;
            serverRecord = serverRecord + " marker=" + marker.ToString();
            serverRecord = serverRecord + " client_sent_ms=" + clientSent.ToString();
            serverRecord = serverRecord + " server_received_ms=" + now.ToString();
            serverRecord = serverRecord + " server_sent_ms=" + serverSent.ToString();
            GRZMovementTraceLog.Write(serverRecord);
            return;
        }
        if (GetGame().IsServer() || (!IsControlledPlayer() && GetGame().GetPlayer() != this))
            return;
        int serverReceived, serverReplied;
        if (!ctx.Read(capture) || !ctx.Read(marker) || !ctx.Read(clientSent))
            return;
        if (!ctx.Read(serverReceived) || !ctx.Read(serverReplied))
            return;
        if (capture != m_GRZTraceCapture || marker != m_GRZTracePingId || clientSent != m_GRZTraceLastPing)
            return;
        int processing = serverReplied - serverReceived;
        int rtt = now - clientSent - processing;
        if (rtt < 0 || rtt > 10000 || processing < 0)
            return;
        float lowerOffset = serverReplied - now;
        float upperOffset = serverReceived - clientSent;
        float offset = (lowerOffset + upperOffset) * 0.5;
        if (!m_GRZTraceClockReady || rtt <= m_GRZTraceBestRtt)
        {
            m_GRZTraceClockReady = true;
            m_GRZTraceBestRtt = rtt;
            m_GRZTraceClockOffset = offset;
        }
        string clientRecord = "[GRZSYNC] side=CLIENT capture=" + capture;
        clientRecord = clientRecord + " marker=" + marker.ToString();
        clientRecord = clientRecord + " client_sent_ms=" + clientSent.ToString();
        clientRecord = clientRecord + " server_received_ms=" + serverReceived.ToString();
        clientRecord = clientRecord + " server_sent_ms=" + serverReplied.ToString();
        clientRecord = clientRecord + " client_received_ms=" + now.ToString();
        clientRecord = clientRecord + " rtt_ms=" + rtt.ToString();
        clientRecord = clientRecord + " offset_low_ms=" + lowerOffset.ToString();
        clientRecord = clientRecord + " offset_high_ms=" + upperOffset.ToString();
        GRZMovementTraceLog.Write(clientRecord);
    }

    override void CommandHandler(float pDt, int pCurrentCommandID, bool pCurrentCommandFinished)
    {
        super.CommandHandler(pDt, pCurrentCommandID, pCurrentCommandFinished);
        GRZRecordMovement(pDt);
    }

    private void GRZRecordMovement(float deltaTime)
    {
        if (!GetGame() || !IsAlive() || m_GRZTraceCount >= 1200)
            return;
        bool server = GetGame().IsServer();
        if (server)
        {
            if (!GRZTraceServerSelected() || m_GRZTraceCapture == "")
                return;
        }
        else if (!IsControlledPlayer() && GetGame().GetPlayer() != this)
        {
            return;
        }

        int now = GetGame().GetTime();
        if (!server)
            GRZTracePing(now);
        // Wall-clock gating avoids repeated samples during prediction replay.
        if (m_GRZTraceCount > 0 && now - m_GRZTraceLastTime < 100)
            return;
        vector position = GetPosition();
        vector displacement = "0 0 0";
        int interval = 0;
        if (m_GRZTraceCount > 0)
        {
            displacement = position - m_GRZTraceLastPosition;
            interval = now - m_GRZTraceLastTime;
        }
        vector engineVelocity = GetVelocity(this);
        HumanMovementState state = new HumanMovementState();
        GetMovementState(state);
        int netLow, netHigh;
        GetNetworkID(netLow, netHigh);

        string side = "CLIENT";
        if (server)
            side = "SERVER";
        string inputData = " input=unavailable";
        HumanInputController controls = GetInputController();
        if (controls)
        {
            float requestedSpeed;
            vector requestedDirection;
            controls.GetMovement(requestedSpeed, requestedDirection);
            inputData = " input_speed=" + requestedSpeed.ToString() + " input_direction=" + requestedDirection.ToString();
        }
        vector orientation = GetOrientation();
        int command = GetCurrentCommandID();
        string record = "[GRZMOVE] side=" + side;
        record = record + " net=" + netLow.ToString();
        record = record + ":" + netHigh.ToString();
        record = record + " capture=" + m_GRZTraceCapture;
        if (server)
            record = record + " aligned_ms=" + now.ToString();
        else if (m_GRZTraceClockReady)
        {
            float aligned = now + m_GRZTraceClockOffset;
            float bound = m_GRZTraceBestRtt * 0.5;
            record = record + " aligned_ms=" + aligned.ToString();
            record = record + " clock_bound_ms=" + bound.ToString();
        }
        else
            record = record + " clock=pending";
        record = record + " seq=" + m_GRZTraceCount.ToString();
        record = record + " t_ms=" + now.ToString();
        record = record + " dt_ms=" + interval.ToString();
        record = record + " pos=" + position.ToString();
        record = record + " delta=" + displacement.ToString();
        record = record + " engine_velocity=" + engineVelocity.ToString();
        record = record + " orientation=" + orientation.ToString();
        record = record + " command=" + command.ToString();
        record = record + " stance=" + state.m_iStanceIdx.ToString();
        record = record + " movement=" + state.m_iMovement.ToString();
        record = record + inputData;
        GRZMovementTraceLog.Write(record);
        m_GRZTraceLastPosition = position;
        m_GRZTraceLastTime = now;
        m_GRZTraceCount++;
        if (m_GRZTraceCount == 1200)
            GRZMovementTraceLog.Write("[GRZMOVE] " + side + " trace limit reached; recording stopped for this player instance.");
    }
}
