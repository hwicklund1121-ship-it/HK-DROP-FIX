GRZ Original Sprint Lean / No Camera Distance TEST
Only runtime change from GRZ-Native-Camera-Distance-No-HK-Test: restore original GRZRunningLean.c exactly. Removes the experimental super.OnSprintStart call and explicit lean input unlocks. Original running lean remains.
Movement settings remain 0.06 / 100 / 0.14 / 17 / 6.5. Camera-distance overrides, sprint framing overrides and HK-drop recovery distance code remain removed. Native weapon-obstruction handling remains enabled. Other camera features remain present.
Back up the current PBO outside loaded addon folders. Replace the same-name GRZ_Movement.pbo on both test server and clients, remove duplicate versions and restart both. Unsigned: use your normal signing process if required.
Compare the same run/stop and object-proximity movements. This reverts an unsuccessful experiment; it is not a confirmed jitter fix.
Verified: original sprint file byte match, all 12 payload round-trips, PBO checksum, client/SERVER preprocessing, ZIP integrity. Not verified: Enforce compilation or in-game behavior.
