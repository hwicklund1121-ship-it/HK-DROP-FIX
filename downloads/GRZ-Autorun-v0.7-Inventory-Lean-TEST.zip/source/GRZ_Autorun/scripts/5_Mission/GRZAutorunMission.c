#ifndef SERVER
modded class MissionGameplay
{
    protected ref set<int> m_GRZAutorunHeldKeys;
    protected bool m_GRZAutorunCancelledThisFrame;

    protected bool GRZAutorunKeyMatchesAction(int key, int action)
    {
        TIntArray keys = new TIntArray();
        GetGame().GetInput().GetCurrentProfileActionKeys(action, keys);
        return keys.Find(key) != -1;
    }

    protected bool GRZAutorunCanKeepRunningForKey(int key)
    {
        // A conflicting binding to the autorun action must still stop it.
        UAInput autorun = GetUApi().GetInputByName("UAGRZAutorunToggle");
        if (autorun && GRZAutorunKeyMatchesAction(key, autorun.ID()))
            return false;
        if (key == KeyCode.KC_TAB)
            return true;
        return GRZAutorunKeyMatchesAction(key, UALeanLeft) || GRZAutorunKeyMatchesAction(key, UALeanRight);
    }

    override void OnInit()
    {
        super.OnInit();
        GRZAutorunState.Stop();
        m_GRZAutorunHeldKeys = new set<int>();
        m_GRZAutorunCancelledThisFrame = false;
    }

    override void OnKeyPress(int key)
    {
        if (!m_GRZAutorunHeldKeys)
            m_GRZAutorunHeldKeys = new set<int>();
        // Ignore keyboard-repeat events for a key already held down. The
        // initial autorun key must not cancel itself while it is being held.
        if (m_GRZAutorunHeldKeys.Find(key) == -1)
        {
            m_GRZAutorunHeldKeys.Insert(key);
            if (GRZAutorunState.Active && !GRZAutorunCanKeepRunningForKey(key))
            {
                GRZAutorunState.Stop();
                m_GRZAutorunCancelledThisFrame = true;
            }
        }
        super.OnKeyPress(key);
    }

    override void OnKeyRelease(int key)
    {
        if (m_GRZAutorunHeldKeys)
        {
            int index = m_GRZAutorunHeldKeys.Find(key);
            if (index != -1) m_GRZAutorunHeldKeys.Remove(index);
        }
        super.OnKeyRelease(key);
    }

    override void OnUpdate(float timeslice)
    {
        bool cancelledByKey = m_GRZAutorunCancelledThisFrame;
        m_GRZAutorunCancelledThisFrame = false;
        super.OnUpdate(timeslice);
        PlayerBase player = PlayerBase.Cast(GetGame().GetPlayer());
        if (!GRZAutorunState.CanRun(player))
        {
            GRZAutorunState.Stop();
            return;
        }
        // Keep the existing action ID so previously assigned bindings survive.
        // This action starts autorun; keyboard events stop it. Do not restart
        // on the same frame when pressing the bound key stopped a running mode.
        if (!cancelledByKey && !GRZAutorunState.Active && GRZAutorunState.Pressed("UAGRZAutorunToggle"))
        {
            GRZAutorunState.Active = true;
        }
        GRZAutorunState.Apply(player);
    }

    override void OnMissionFinish()
    {
        GRZAutorunState.Stop();
        if (m_GRZAutorunHeldKeys) m_GRZAutorunHeldKeys.Clear();
        super.OnMissionFinish();
    }
}
#endif
