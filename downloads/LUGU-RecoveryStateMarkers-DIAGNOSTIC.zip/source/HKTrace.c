// Observe the local player's graph/camera state. Do not drive animation/input.
modded class PlayerBase
{
    private ref HumanMovementState m_HKTraceState = new HumanMovementState();
    private ref array<string> m_HKTraceNames;
    private ref array<int> m_HKTraceTags;
    private float m_HKTraceElapsed;
    private float m_HKTraceTail;
    private int m_HKTraceSamples;
    private int m_HKTraceHelper = -1;

    override void CommandHandler(float pDt, int pCurrentCommandID, bool pCurrentCommandFinished)
    {
        // Always preserve the existing command-handler chain and its arguments.
        super.CommandHandler(pDt, pCurrentCommandID, pCurrentCommandFinished);

        if (GetGame().IsDedicatedServer() || GetGame().GetPlayer() != this)
            return;
        if (m_HKTraceSamples >= 2400)
            return;

        HumanAnimInterface anim = GetAnimInterface();
        if (!anim)
            return;

        if (!m_HKTraceNames)
        {
            m_HKTraceNames = new array<string>();
            m_HKTraceTags = new array<int>();
            m_HKTraceNames.Insert("TagThrowing");
            m_HKTraceNames.Insert("TagThrowingIdle");
            m_HKTraceNames.Insert("TagThrowingCancel");
            m_HKTraceNames.Insert("TagThrowingPneTransition");
            m_HKTraceNames.Insert("TagStanceChange");
            m_HKTraceNames.Insert("TagPneToErc");
            m_HKTraceNames.Insert("TagPneToErcMove");
            m_HKTraceNames.Insert("TagProneBackExit");
            m_HKTraceNames.Insert("TagProneBack");
            m_HKTraceNames.Insert("TagThrowingIn");
            m_HKTraceNames.Insert("TagThrowingOut");
            m_HKTraceNames.Insert("TagHKRecoveryGraphV1");
            m_HKTraceNames.Insert("TagHKRecoveryOriginal");
            m_HKTraceNames.Insert("TagHKRecoveryProneCancel");
            m_HKTraceNames.Insert("TagHKRecoveryBackRise");
            m_HKTraceNames.Insert("TagHKCancelParent");
            m_HKTraceNames.Insert("TagHKCancelPoBParent");
            for (int bindIndex = 0; bindIndex < m_HKTraceNames.Count(); bindIndex++)
            {
                int tag = anim.BindTag(m_HKTraceNames[bindIndex]);
                m_HKTraceTags.Insert(tag);
                Print("[HKTRACE] bound_tag=" + m_HKTraceNames[bindIndex] + " id=" + tag.ToString());
                if (tag < 0)
                    Print("[HKTRACE] unavailable_tag=" + m_HKTraceNames[bindIndex]);
            }
            m_HKTraceHelper = GetBoneIndexByName("Camera3rd_Helper");
            Print("[HKTRACE] ready version=3_state_markers sample_interval_s=0.01 max_samples=2400");
        }

        HumanCommandMove move = GetCommand_Move();
        bool changing = false;
        bool onBack = false;
        bool risingFromBack = false;
        if (move)
        {
            changing = move.IsChangingStance();
            onBack = move.IsOnBack();
            risingFromBack = move.IsStandingFromBack();
        }

        bool active = changing || risingFromBack;
        string tags;
        for (int tagIndex = 0; tagIndex < m_HKTraceTags.Count(); tagIndex++)
        {
            if (m_HKTraceTags[tagIndex] >= 0 && anim.IsTag(m_HKTraceTags[tagIndex]))
            {
                active = true;
                tags += m_HKTraceNames[tagIndex] + ",";
            }
        }
        if (active)
            m_HKTraceTail = 2.0;
        else
            m_HKTraceTail = Math.Max(0.0, m_HKTraceTail - pDt);
        if (m_HKTraceTail <= 0)
        {
            m_HKTraceElapsed = 0;
            return;
        }
        m_HKTraceElapsed += pDt;
        if (m_HKTraceElapsed < 0.01)
            return;
        m_HKTraceElapsed = 0;

        GetMovementState(m_HKTraceState);
        string weapon = "empty";
        EntityAI held = GetHumanInventory().GetEntityInHands();
        if (held)
            weapon = held.GetType();

        string cameraType = "none";
        DayZPlayerCamera camera = GetCurrentCamera();
        if (camera)
            cameraType = camera.ClassName();

        float inputSpeed;
        vector inputDirection;
        HumanInputController input = GetInputController();
        float heading;
        bool inputRaised = false;
        if (input)
        {
            input.GetMovement(inputSpeed, inputDirection);
            heading = input.GetHeadingAngle();
            inputRaised = input.IsWeaponRaised();
        }
        bool throwMode = false;
        bool throwWindup = false;
        bool throwPlaying = false;
        DayZPlayerImplementThrowing throwing = GetThrowing();
        if (throwing)
        {
            throwMode = throwing.IsThrowingModeEnabled();
            throwWindup = throwing.IsThrowingInProgress();
            throwPlaying = throwing.IsThrowingAnimationPlaying();
        }
        float aimLR;
        HumanCommandWeapons weapons = GetCommandModifier_Weapons();
        if (weapons)
            aimLR = weapons.GetBaseAimingAngleLR();
        float helperY;
        if (m_HKTraceHelper >= 0)
        {
            vector helper = GetBonePositionMS(m_HKTraceHelper);
            helperY = helper[1];
        }
        // Actual view position may lag simulation by a frame. This is distance
        // to player origin, not the configured camera boom/pivot distance.
        float viewToPlayer = vector.Distance(GetGame().GetCurrentCameraPosition(), GetPosition());
        string line = "[HKTRACE] t_ms=" + GetGame().GetTime().ToString();
        line += " weapon=" + weapon + " command=" + GetCurrentCommandID().ToString();
        line += " stance=" + m_HKTraceState.m_iStanceIdx.ToString();
        line += " movement=" + m_HKTraceState.m_iMovement.ToString();
        line += " lean=" + m_HKTraceState.m_fLeaning.ToString();
        line += " changing=" + changing.ToString();
        line += " on_back=" + onBack.ToString() + " rising_from_back=" + risingFromBack.ToString();
        line += " throw_mode=" + throwMode.ToString() + " throw_windup=" + throwWindup.ToString();
        line += " throw_playing=" + throwPlaying.ToString() + " input_raised=" + inputRaised.ToString();
        line += " aim_lr_native=" + aimLR.ToString();
        line += " input_speed=" + inputSpeed.ToString();
        line += " input_x=" + inputDirection[0].ToString() + " input_z=" + inputDirection[2].ToString();
        line += " heading_rad=" + heading.ToString();
        line += " camera=" + cameraType + " blending=" + IsCameraBlending().ToString();
        line += " view_to_player_m=" + viewToPlayer.ToString();
        line += " helper_y_ms=" + helperY.ToString() + " tags=" + tags;
        Print(line);
        m_HKTraceSamples++;
        if (m_HKTraceSamples == 2400)
            Print("[HKTRACE] stopped sample_limit_reached=1");
    }
};
