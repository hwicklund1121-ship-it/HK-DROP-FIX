@echo off
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
 echo Python environment missing. Follow the Windows setup in README.md.
 pause
 exit /b 1
)
".venv\Scripts\python.exe" windows_start.py bot
pause
