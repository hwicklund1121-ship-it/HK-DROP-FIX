# Discord Word Filter + Private Dashboard

Fresh replacement build, not a recovered archive. Discord only; no DayZ mod,
Movement changes, or LUGU content is included.

## Features

- Guild-scoped message deletion, including uncached edited messages fetched from Discord.
- SQLite-backed substring blacklist, read for every event so dashboard changes apply immediately.
- Normalization of case, spacing/punctuation, combining marks, full-width text,
  common leetspeak and selected Greek/Cyrillic lookalikes. Not every Unicode evasion
  can be detected. Substring matching can cause false positives across word boundaries.
- Private HTML administration: password login, add/remove/list, scrypt password hash,
  HMAC-signed one-hour HttpOnly/SameSite cookies, CSRF on all forms, and persistent
  five-attempts-per-five-minutes/IP login throttle. Refresh to see another admin's edits.
- Best-effort anti-nuke: three channel deletions, role deletions, bans or kicks by
  one actor within 20 seconds triggers removal of their removable dangerous roles.
  Audit entries older than 30 seconds are ignored. Only the configured server is monitored.
- Owner-only `/backup` and `/restore`. Restore previews missing roles/channels and
  requires an owner confirmation within 60 seconds. Successful replacement IDs are
  saved after each object, making partial restores retryable.

## Linux deployment

Install Docker Engine with the Compose plugin and Python 3.12 from trusted sources.
Extract this folder and run:

```sh
python3 setup.py
# Container uses UID 1000. Set the data directory ownership accordingly:
sudo chown -R 1000:1000 data
chmod 700 data
chmod 600 .env
docker compose up -d --build
docker compose ps
docker compose logs --tail=100 bot dashboard
```

Setup prompts privately for a real bot token and a new dashboard password (14+
characters), and asks for your server ID. Nothing real is preconfigured. It refuses
an existing .env to avoid overwriting credentials. Back up `.env` securely; do not
upload it. The token is needed only by the bot; Compose env_file also passes the
configuration to the dashboard, so protect both containers and the Docker socket.

In the Discord Developer Portal enable **Message Content Intent**. Invite with
`bot` and `applications.commands` scopes. Grant View Channels, Read Message History,
Manage Messages, View Audit Log, Manage Roles and Manage Channels. Do not grant
Administrator. Put the bot role above roles it should be able to contain and
restore. It needs View Channels in the channels it should monitor. Guild owner
and administrator accounts should use MFA. Restrict who can install bots,
manage roles/channels/webhooks, and access the host.

The dashboard is published only on **127.0.0.1:8080** of the Linux host. From your
own computer:

```sh
ssh -N -L 8080:127.0.0.1:8080 your-user@your-server
```

Then open `http://127.0.0.1:8080` locally. Do not expose the port publicly or change
the bind to 0.0.0.0 on the host. HTTP cookies intentionally omit Secure because the
browser uses localhost HTTP inside the SSH tunnel. Cookie contents are signed,
not encrypted, and contain only authorization state, CSRF nonce and expiry.
Logout clears the browser cookie; a copied cookie remains valid until expiry.
Rotate SESSION_SECRET and restart the dashboard to revoke all sessions.
Do not configure reverse-proxy forwarding headers; the throttle uses the peer IP.
The dashboard health endpoint only checks HTTP, not Discord connectivity.

## Backup and incident recovery

As server owner, run `/backup` **before an incident**. Copy `data/backups/` securely
off-host. A single baseline snapshot is protected from command-based overwrite.
To refresh it, archive the previous JSON outside that directory, remove the active
`<guild-id>.json`, then run `/backup` again. Do not do this during an incident.
Back up the SQLite rules file with SQLite's backup API, or stop both services
before copying the database. Keep runtime data out of release archives.

If attacked, first revoke the attacker's access and compromised integrations or
tokens. Run `/restore`, review the counts and timestamp, then confirm. Restoring
while an attacker remains active can result in further deletions. The command
recreates missing ordinary roles, categories, text and voice channels, preserving
recorded channel permission overwrites and mapping recreated role/category IDs.
It restores recorded role permissions, which can include powerful permissions:
trust the snapshot and review the result. Unresolved role overwrite targets stop
channel creation rather than opening a formerly private channel.

**Limitations:** Discord does not restore deleted messages, original IDs, invites,
webhooks or member role assignments. This implementation also does not restore
threads, forums, media/stage channels, managed/integration roles, exact role order,
server settings or changed existing objects. Member overwrites for users who left
the guild are skipped. Recheck all permissions and role ordering after recovery.
A snapshot is required; `/restore` cannot infer a lost server. Recovery JSON is
sensitive structure/permission data and must remain private and backed up.

Anti-nuke is reactive and cannot guarantee prevention. Damage can occur before
three events arrive; slow attacks, role edits, webhook abuse and other action
types are outside its detection. It cannot strip managed roles, contain the owner,
or act on roles at/above the bot. Restrictive baseline permissions and off-host
backups remain necessary. Do not test destructive behavior on your live community.

## Local development and checks

```sh
python3 -m venv .venv
. .venv/bin/activate
pip install -r requirements.lock
python -m unittest discover -s tests -v
```

Tests use temporary databases, synthetic credentials, real local HTTP requests,
and mocked Discord objects/API calls. They verify filtering, password/session
security, CSRF, throttling, live rules, edited messages, containment threshold,
restore mapping/retries and failure on missing permission targets. They do not
prove live Discord behavior or Docker deployment. The dependency lock pins all
runtime versions for CPython 3.12/Linux. No separate dashboard dependencies exist.

`docker compose down` stops services; it does not remove the bind-mounted data.
Keep `.env`, databases, snapshots and credentials out of Git and ZIPs.

## Windows 11 and dashboard update

Install Python 3.12. In PowerShell inside this folder, run:

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.lock
.\.venv\Scripts\python.exe setup.py
```

Then double-click `Start-Dashboard.cmd` and `Start-Bot.cmd`. The launchers load
`.env` automatically and leave any startup error visible. Open
http://127.0.0.1:8080 on the same PC; no SSH tunnel or Docker is needed.
Keep both windows open and prevent the PC from sleeping. Close them to stop.
The Windows launchers have not been executed on Windows in this build environment.

**Existing installation:** stop the dashboard window with Ctrl+C. Copy only
`dashboard.py`, `ui.py`, `windows_start.py`, `Start-Dashboard.cmd` and `Start-Bot.cmd`
from the updated ZIP into your existing project folder. Preserve your `.env`,
`data`, and `.venv`. No setup or dependency reinstall is required for this dashboard
update. Double-click `Start-Dashboard.cmd`, then refresh your browser.

The redesigned dashboard includes responsive dark styling, blacklist counts,
server-side rule search, clear operation feedback, and a message tester that uses
the same filter as the bot. It deliberately does not claim bot connection status.
Styles are self-contained and permitted by a SHA-256 Content Security Policy;
no JavaScript or third-party resources are loaded.

### Gunrunnerz branding

The dashboard uses a centered layout with a black background and red accents.
Save your original Gunrunnerz logo as `logo.png` beside `dashboard.py`, then
refresh the page to display it in the header on both sign-in and administration
screens. It must be a real PNG no larger than 2 MB. The original uploaded logo
was visible in chat but not accessible as a file in the build workspace, so it is
not embedded in this ZIP. Until you add it, the header shows GUNRUNNERZ text.
For Docker, also add `COPY logo.png ./` to your Dockerfile before rebuilding.
