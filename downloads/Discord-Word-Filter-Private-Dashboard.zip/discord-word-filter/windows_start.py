"""Load local setup configuration and keep startup errors visible on Windows."""
import os
from pathlib import Path
import re
import runpy
import sys

if __name__=='__main__':
    os.chdir(Path(__file__).resolve().parent)
    if len(sys.argv)!=2 or sys.argv[1] not in {'dashboard','bot'}:
        raise SystemExit('Choose dashboard or bot.')
    if not Path('.env').is_file():
        raise SystemExit('Configuration missing. Run .venv\\Scripts\\python.exe setup.py first.')
    for line in Path('.env').read_text().splitlines():
        match=re.fullmatch(r"([A-Z_]+)='([^\r\n]*)'",line)
        if match: os.environ[match[1]]=match[2]
    if sys.argv[1]=='dashboard':
        print('Dashboard: http://127.0.0.1:8080',flush=True)
        print('Keep this window open. Press Ctrl+C to stop.',flush=True)
    runpy.run_path(sys.argv[1]+'.py',run_name='__main__')
