"""Interactive configuration generator, not a package installer."""
import getpass
import json
import os
import secrets
from pathlib import Path
from security import password_hash

if __name__=='__main__':
    target=Path('.env')
    if target.exists(): raise SystemExit('.env already exists; preserve it or move it before setup.')
    token=getpass.getpass('Discord bot token (hidden): ').strip()
    guild=input('Discord server/guild ID: ').strip()
    if not token or not guild.isdigit(): raise SystemExit('Token and numeric guild ID required.')
    password=getpass.getpass('New dashboard password (at least 14 characters): ')
    if len(password)<14 or password!=getpass.getpass('Repeat password: '): raise SystemExit('Passwords must match and contain at least 14 characters.')
    # Compose single quotes preserve literal $, #, and double quotes. Reject line breaks/quotes.
    if any(c in token for c in "\r\n'"): raise SystemExit('Invalid token format')
    values={'DISCORD_TOKEN':token,'DISCORD_GUILD_ID':guild,'ADMIN_PASSWORD_HASH':password_hash(password),'SESSION_SECRET':secrets.token_urlsafe(48)}
    fd=os.open(target,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    with os.fdopen(fd,'w') as f:
        for k,v in values.items(): f.write(k+"='"+v+"'\n")
    Path('data').mkdir(mode=0o700,exist_ok=True)
    print('Created private .env and data directory. Never share these files.')
