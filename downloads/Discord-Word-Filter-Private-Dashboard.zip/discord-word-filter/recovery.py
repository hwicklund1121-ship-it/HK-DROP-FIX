"""Owner-controlled structural recovery; never promises full Discord recovery."""
import asyncio
from collections import defaultdict, deque
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import time
import discord
from discord import app_commands

DANGEROUS = ('administrator','manage_guild','manage_roles','manage_channels','ban_members','kick_members','manage_webhooks')

class Guard:
    def __init__(self, client):
        self.client=client
        self.events=defaultdict(deque)
        self.seen=set()
        self.lock=asyncio.Lock()
        self.directory=Path(os.getenv('BACKUP_DIR','data/backups'))
        self.directory.mkdir(parents=True,exist_ok=True)
    def file(self,guild): return self.directory / (str(guild.id)+'.json')
    def load(self,guild):
        data=json.loads(self.file(guild).read_text())
        if data['guild_id']!=guild.id: raise ValueError('Snapshot server mismatch')
        return data
    async def backup(self,guild):
        roles=[{'id':r.id,'name':r.name,'permissions':r.permissions.value,'colour':r.colour.value,'hoist':r.hoist,'mentionable':r.mentionable,'position':r.position} for r in guild.roles if not r.is_default() and not r.managed]
        channels=[]
        for c in guild.channels:
            # Threads, forum/media/stage channels and integration roles require manual recovery.
            if not isinstance(c,(discord.CategoryChannel,discord.TextChannel,discord.VoiceChannel)): continue
            overwrites=[]
            for target,overwrite in c.overwrites.items():
                allow,deny=overwrite.pair()
                overwrites.append({'id':target.id,'role':isinstance(target,discord.Role),'allow':allow.value,'deny':deny.value})
            channels.append({'id':c.id,'name':c.name,'type':str(c.type),'position':c.position,'category':c.category_id if not isinstance(c,discord.CategoryChannel) else None,'overwrites':overwrites,'topic':getattr(c,'topic',None),'nsfw':getattr(c,'nsfw',False),'slowmode_delay':getattr(c,'slowmode_delay',0),'bitrate':getattr(c,'bitrate',64000),'user_limit':getattr(c,'user_limit',0)})
        data={'guild_id':guild.id,'created':datetime.now(timezone.utc).isoformat(),'roles':roles,'channels':channels,'mapped_roles':{},'mapped_channels':{}}
        self.save(guild,data)
    def save(self,guild,data):
        path=self.file(guild); temporary=path.with_suffix('.tmp')
        with open(temporary,'w',encoding='utf-8') as f:
            os.chmod(temporary,0o600); json.dump(data,f)
        temporary.replace(path)
    def missing(self,guild,data):
        roles=[r for r in data['roles'] if not guild.get_role(data.get('mapped_roles',{}).get(str(r['id']),r['id']))]
        channels=[c for c in data['channels'] if not guild.get_channel(data.get('mapped_channels',{}).get(str(c['id']),c['id']))]
        return roles,channels
    async def restore(self,guild,data):
        # Persist each new ID immediately, so retry does not duplicate successful creations.
        roles,channels=self.missing(guild,data)
        for r in sorted(roles,key=lambda r:r['position']):
            new=await guild.create_role(name=r['name'],permissions=discord.Permissions(r['permissions']),colour=discord.Colour(r['colour']),hoist=r['hoist'],mentionable=r['mentionable'],reason='Owner confirmed snapshot restore')
            data['mapped_roles'][str(r['id'])]=new.id; self.save(guild,data)
        for c in sorted(channels,key=lambda c:(c['type']!='category',c['position'])):
            overwrites={}
            for o in c['overwrites']:
                if o['role']:
                    target=guild.get_role(data['mapped_roles'].get(str(o['id']),o['id']))
                else:
                    target=guild.get_member(o['id'])
                    if target is None:
                        try: target=await guild.fetch_member(o['id'])
                        except discord.NotFound: continue
                if target is None:
                    # Never create a private channel if a permission target cannot be resolved.
                    raise ValueError('Missing permission target; manual recovery required')
                overwrites[target]=discord.PermissionOverwrite.from_pair(discord.Permissions(o['allow']),discord.Permissions(o['deny']))
            parent=guild.get_channel(data['mapped_channels'].get(str(c['category']),c['category'])) if c['category'] else None
            if c['category'] and parent is None: raise ValueError('Missing parent category')
            kwargs={'name':c['name'],'overwrites':overwrites,'position':c['position'],'reason':'Owner confirmed snapshot restore'}
            if c['type']=='category': new=await guild.create_category(**kwargs)
            elif c['type']=='text': new=await guild.create_text_channel(**kwargs,category=parent,topic=c['topic'],nsfw=c['nsfw'],slowmode_delay=c['slowmode_delay'])
            elif c['type']=='voice': new=await guild.create_voice_channel(**kwargs,category=parent,bitrate=min(c['bitrate'],guild.bitrate_limit),user_limit=c['user_limit'])
            else: continue
            data['mapped_channels'][str(c['id'])]=new.id; self.save(guild,data)
        return len(roles),len(channels)
    async def audit(self,entry):
        guild=entry.guild
        if guild.id!=self.client.guild_id or entry.action not in {discord.AuditLogAction.channel_delete,discord.AuditLogAction.role_delete,discord.AuditLogAction.ban,discord.AuditLogAction.kick}: return
        actor=entry.user_id
        if not actor or actor in {guild.owner_id,self.client.user.id} or entry.id in self.seen: return
        if abs((datetime.now(timezone.utc)-entry.created_at).total_seconds())>30: return
        self.seen.add(entry.id)
        if len(self.seen)>10000: self.seen={entry.id}
        key=(guild.id,actor); queue=self.events[key]; now=time.monotonic()
        while queue and queue[0]<now-20: queue.popleft()
        queue.append(now)
        if len(queue)<3: return
        member=guild.get_member(actor) or await guild.fetch_member(actor)
        # Owner and roles at/above the bot cannot be contained by Discord's permission model.
        if member.top_role>=guild.me.top_role: return
        risky=[r for r in member.roles if not r.is_default() and not r.managed and any(getattr(r.permissions,p) for p in DANGEROUS)]
        if risky:
            await member.remove_roles(*risky,reason='Anti-nuke: 3 destructive audit actions within 20 seconds')
        # Managed integration roles cannot be removed; owner must revoke these manually.

class Confirm(discord.ui.View):
    def __init__(self,guard,guild,owner,snapshot):
        super().__init__(timeout=60); self.guard=guard; self.guild=guild; self.owner=owner; self.snapshot=snapshot
    @discord.ui.button(label='Restore missing roles/channels',style=discord.ButtonStyle.danger)
    async def confirm(self,interaction,button):
        if interaction.user.id!=self.owner or interaction.guild.owner_id!=interaction.user.id:
            return await interaction.response.send_message('Server owner only.',ephemeral=True)
        await interaction.response.defer(ephemeral=True,thinking=True)
        async with self.guard.lock:
            button.disabled=True; self.stop()
            try:
                current=self.guard.load(self.guild)
                if current['created']!=self.snapshot['created']: raise ValueError('Snapshot changed; preview again')
                result=await self.guard.restore(self.guild,current)
                await interaction.followup.send(f'Restored {result[0]} roles and {result[1]} channels. Review role order and permissions manually.',ephemeral=True)
            except (discord.HTTPException,ValueError):
                await interaction.followup.send('Restore stopped. Check bot permissions and hierarchy; successful new IDs were saved. Preview /restore again to retry.',ephemeral=True)

def register(tree,guard,guild_id):
    scope=discord.Object(id=guild_id)
    @tree.command(name='backup',description='Owner only: save current roles and channel structure',guild=scope)
    @app_commands.default_permissions(administrator=True)
    async def backup(interaction:discord.Interaction):
        if not interaction.guild or interaction.user.id!=interaction.guild.owner_id:
            return await interaction.response.send_message('Server owner only.',ephemeral=True)
        await interaction.response.defer(ephemeral=True,thinking=True)
        async with guard.lock:
            path=guard.file(interaction.guild)
            if path.exists():
                return await interaction.followup.send('Snapshot already exists. Preserve it off-host; an operator must archive/remove the file before making a replacement. This prevents overwriting the good snapshot during an incident.',ephemeral=True)
            await guard.backup(interaction.guild)
        await interaction.followup.send('Snapshot saved on the host. Copy data/backups securely off-host. Messages and member role assignments are not included.',ephemeral=True)
    @tree.command(name='restore',description='Owner only: preview recovery of missing roles/channels',guild=scope)
    @app_commands.default_permissions(administrator=True)
    async def restore(interaction:discord.Interaction):
        if not interaction.guild or interaction.user.id!=interaction.guild.owner_id:
            return await interaction.response.send_message('Server owner only.',ephemeral=True)
        try: data=guard.load(interaction.guild)
        except (OSError,ValueError):
            return await interaction.response.send_message('No valid snapshot. Run /backup before an incident.',ephemeral=True)
        roles,channels=guard.missing(interaction.guild,data)
        await interaction.response.send_message(f"Snapshot {data['created']}: {len(roles)} missing roles; {len(channels)} missing channels. Grants recorded role permissions. Does not recover messages, old IDs, member assignments, managed roles, or modified existing objects. Contain the attacker first. Confirm within 60 seconds.",view=Confirm(guard,interaction.guild,interaction.user.id,data),ephemeral=True)
