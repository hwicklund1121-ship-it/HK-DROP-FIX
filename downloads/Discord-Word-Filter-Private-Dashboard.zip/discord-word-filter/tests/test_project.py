import asyncio
import http.client
import json
import tempfile
import threading
import time
import unittest
from pathlib import Path
from types import SimpleNamespace as NS
from unittest.mock import AsyncMock
import discord
from core import Rules,normalize
from security import password_hash,password_ok,sign,verify
from dashboard import make_server
from bot import enforce,FilterBot
from recovery import Guard
from urllib.parse import urlencode

class CoreTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.addCleanup(self.tmp.cleanup)
        self.rules=Rules(Path(self.tmp.name)/'rules.db')
    def test_evasion(self):
        self.rules.add('badword')
        for text in ['b a d w o r d','b4dw0rd','ＢＡＤＷＯＲＤ','bаdwоrd','ba\u200bdword','bádword']:
            self.assertTrue(self.rules.matches(text),text)
        self.assertFalse(self.rules.matches('hello community'))
    def test_live_rules(self):
        other=Rules(self.rules.path); self.rules.add('badword')
        self.assertTrue(other.matches('badword')); self.rules.remove('badword'); self.assertFalse(other.matches('badword'))
    def test_validation(self):
        for text in ['','---','a'*101]:
            with self.assertRaises(ValueError): self.rules.add(text)
    def test_duplicate(self):
        self.rules.add('bad'); self.rules.add('b4d'); self.assertEqual(self.rules.list(),['bad'])
    def test_throttle(self):
        self.assertTrue(all(self.rules.attempt('local',100) for _ in range(5)))
        self.assertFalse(Rules(self.rules.path).attempt('local',101)); self.assertTrue(self.rules.attempt('local',401))
    def test_password(self):
        encoded=password_hash('test-only-password')
        self.assertTrue(password_ok('test-only-password',encoded)); self.assertFalse(password_ok('wrong',encoded))
        self.assertNotEqual(encoded,password_hash('test-only-password'))
    def test_session(self):
        token=sign({'expires':time.time()+60},'test-key')
        self.assertIsNotNone(verify(token,'test-key')); self.assertIsNone(verify(token+'x','test-key'))
        self.assertIsNone(verify(sign({'expires':0},'test-key'),'test-key'))

class WebTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.rules=Rules(Path(self.tmp.name)/'rules.db')
        self.server=make_server(('127.0.0.1',0),self.rules,password_hash('test-only-password'),'k'*48)
        self.thread=threading.Thread(target=self.server.serve_forever,daemon=True); self.thread.start()
        self.cookie=''
    def tearDown(self):
        self.server.shutdown(); self.server.server_close(); self.thread.join(); self.tmp.cleanup()
    def request(self,path='/',data=None):
        c=http.client.HTTPConnection('127.0.0.1',self.server.server_port,timeout=5)
        headers={'Cookie':self.cookie}
        if data is not None: headers['Content-Type']='application/x-www-form-urlencoded'
        c.request('GET' if data is None else 'POST',path,None if data is None else urlencode(data),headers)
        response=c.getresponse(); body=response.read().decode()
        cookie=response.getheader('Set-Cookie')
        if cookie: self.cookie=cookie.split(';')[0]
        status=response.status; c.close(); return status,body
    def csrf(self): return verify(self.cookie.split('=',1)[1],'k'*48)['csrf']
    def login(self):
        self.request(); return self.request('/login',{'csrf':self.csrf(),'password':'test-only-password'})
    def test_login_csrf(self):
        self.request(); self.assertEqual(self.request('/login',{'password':'test-only-password'})[0],403)
        self.assertEqual(self.login()[0],200)
    def test_live_add_remove_xss(self):
        self.login(); token=self.csrf(); term='<script>alert(1)</script>'
        status,body=self.request('/add',{'csrf':token,'term':term})
        self.assertEqual(status,200); self.assertIn('&lt;script&gt;',body); self.assertNotIn('<script>',body)
        self.assertTrue(self.rules.matches(term))
        self.request('/remove',{'csrf':token,'term':term}); self.assertEqual(self.rules.list(),[])
    def test_unauth_and_logout(self):
        self.request(); self.assertEqual(self.request('/add',{'csrf':self.csrf(),'term':'bad'})[0],401)
        self.login(); self.request('/logout',{'csrf':self.csrf()}); self.assertEqual(self.cookie,'session=')
    def test_search_escaping_and_privacy(self):
        self.rules.add('secret-rule'); self.rules.add('other-rule')
        _,body=self.request('/?q=secret')
        self.assertNotIn('secret-rule',body)
        self.login()
        _,body=self.request('/?q=secret')
        self.assertIn('secret-rule',body); self.assertNotIn('other-rule',body)
        _,body=self.request('/?q=%22%3E%3Cscript%3E')
        self.assertNotIn('<script>',body); self.assertIn('&lt;script&gt;',body)
    def test_message_tester_auth_and_no_mutation(self):
        self.rules.add('badword'); self.request()
        self.assertEqual(self.request('/test',{'csrf':self.csrf(),'message':'hello'})[0],401)
        self.login(); token=self.csrf()
        self.assertEqual(self.request('/test',{'message':'badword'})[0],403)
        self.assertIn('BLOCKED',self.request('/test',{'csrf':token,'message':'b a d w o r d'})[1])
        self.assertIn('ALLOWED',self.request('/test',{'csrf':token,'message':'hello'})[1])
        self.assertEqual(self.rules.list(),['badword'])
    def test_document_and_csp(self):
        import base64,hashlib,re
        c=http.client.HTTPConnection('127.0.0.1',self.server.server_port,timeout=5)
        c.request('GET','/'); response=c.getresponse(); body=response.read().decode()
        css=re.search(r'<style>(.*?)</style>',body,re.S).group(1)
        digest=base64.b64encode(hashlib.sha256(css.encode()).digest()).decode()
        self.assertIn('sha256-'+digest,response.getheader('Content-Security-Policy'))
        self.assertIn('HttpOnly',response.getheader('Set-Cookie'))
        self.assertIn('name="viewport"',body); self.assertIn('<!doctype html>',body)
        c.close()
    def test_throttle_http(self):
        self.request(); token=self.csrf()
        for _ in range(5): self.assertEqual(self.request('/login',{'csrf':token,'password':'wrong'})[0],401)
        self.assertEqual(self.request('/login',{'csrf':token,'password':'wrong'})[0],429)

class DiscordTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.addCleanup(self.tmp.cleanup)
        self.rules=Rules(Path(self.tmp.name)/'rules.db'); self.rules.add('badword')
    async def test_filter_scope(self):
        message=NS(guild=NS(id=1),author=NS(bot=False),content='b4dw0rd',delete=AsyncMock())
        await enforce(message,self.rules,1); message.delete.assert_awaited_once()
        message.delete.reset_mock(); await enforce(message,self.rules,2); message.delete.assert_not_awaited()
    async def test_uncached_edit(self):
        bot=FilterBot(self.rules,1)
        message=NS(guild=NS(id=1),author=NS(bot=False),content='badword',delete=AsyncMock())
        channel=NS(fetch_message=AsyncMock(return_value=message))
        bot.get_channel=lambda _:channel
        await bot.on_raw_message_edit(NS(guild_id=1,channel_id=3,message_id=5))
        message.delete.assert_awaited_once(); await bot.close()
    async def test_guard_threshold(self):
        dangerous=NS(is_default=lambda:False,managed=False,permissions=discord.Permissions(administrator=True))
        member=NS(top_role=2,roles=[dangerous],remove_roles=AsyncMock())
        guild=NS(id=1,owner_id=9,me=NS(top_role=10),get_member=lambda _:member)
        guard=Guard(NS(guild_id=1,user=NS(id=8))); guard.directory=Path(self.tmp.name)
        for i in range(2): await guard.audit(NS(id=i,guild=guild,user_id=2,action=discord.AuditLogAction.channel_delete,created_at=discord.utils.utcnow()))
        member.remove_roles.assert_not_awaited()
        await guard.audit(NS(id=3,guild=guild,user_id=2,action=discord.AuditLogAction.channel_delete,created_at=discord.utils.utcnow()))
        member.remove_roles.assert_awaited_once()
    async def test_guard_owner_hierarchy_and_duplicates(self):
        member=NS(top_role=20,roles=[],remove_roles=AsyncMock())
        guild=NS(id=1,owner_id=9,me=NS(top_role=10),get_member=lambda _:member)
        guard=Guard(NS(guild_id=1,user=NS(id=8))); guard.directory=Path(self.tmp.name)
        for actor in [9,8,2]:
            for i in range(4):
                await guard.audit(NS(id=100*actor+i,guild=guild,user_id=actor,action=discord.AuditLogAction.role_delete,created_at=discord.utils.utcnow()))
        member.remove_roles.assert_not_awaited()
        self.assertNotIn((1,9),guard.events)
        self.assertNotIn((1,8),guard.events)
        entry=NS(id=999,guild=guild,user_id=3,action=discord.AuditLogAction.role_delete,created_at=discord.utils.utcnow())
        await guard.audit(entry); await guard.audit(entry)
        self.assertEqual(len(guard.events[(1,3)]),1)
    async def test_restore_retry(self):
        guard=Guard(NS()); guard.directory=Path(self.tmp.name)
        roles={}; channels={}
        async def create_role(**kw):
            r=NS(id=50); roles[50]=r; return r
        async def create_text(**kw):
            c=NS(id=60); channels[60]=c; return c
        guild=NS(id=1,get_role=roles.get,get_channel=channels.get,create_role=AsyncMock(side_effect=create_role),create_text_channel=AsyncMock(side_effect=create_text))
        data={'guild_id':1,'created':'test','roles':[{'id':5,'name':'role','permissions':0,'colour':0,'hoist':False,'mentionable':False,'position':1}],'channels':[{'id':6,'name':'private','type':'text','position':1,'category':None,'overwrites':[],'topic':None,'nsfw':False,'slowmode_delay':0}],'mapped_roles':{},'mapped_channels':{}}
        self.assertEqual(await guard.restore(guild,data),(1,1))
        self.assertEqual(await guard.restore(guild,guard.load(guild)),(0,0))
        guild.create_role.assert_awaited_once(); guild.create_text_channel.assert_awaited_once()
    async def test_restore_unresolved_permissions(self):
        guard=Guard(NS()); guard.directory=Path(self.tmp.name)
        guild=NS(id=1,get_role=lambda _:None,get_channel=lambda _:None,create_text_channel=AsyncMock())
        data={'roles':[],'channels':[{'id':1,'type':'text','position':0,'overwrites':[{'role':True,'id':9,'allow':0,'deny':1024}]}],'mapped_roles':{},'mapped_channels':{}}
        with self.assertRaises(ValueError): await guard.restore(guild,data)
        guild.create_text_channel.assert_not_awaited()

if __name__=='__main__': unittest.main()
