import asyncio
import logging
import os
import discord
from core import Rules
from recovery import Guard, register

async def enforce(message, rules, guild_id):
    if not message.guild or message.guild.id != guild_id or message.author.bot:
        return
    if await asyncio.to_thread(rules.matches,message.content):
        try:
            await message.delete()
        except (discord.Forbidden,discord.NotFound,discord.HTTPException):
            logging.warning('Unable to delete filtered Discord message (check permissions).')

class FilterBot(discord.Client):
    def __init__(self,rules,guild_id):
        intents=discord.Intents.default(); intents.message_content=True; intents.moderation=True
        super().__init__(intents=intents)
        self.rules=rules; self.guild_id=guild_id
        self.tree=discord.app_commands.CommandTree(self)
        self.guard=Guard(self)
        register(self.tree,self.guard,guild_id)
    async def setup_hook(self):
        await self.tree.sync(guild=discord.Object(id=self.guild_id))
    async def on_audit_log_entry_create(self,entry):
        try:
            await self.guard.audit(entry)
        except discord.HTTPException:
            logging.warning("Anti-nuke containment failed; check role hierarchy and audit permissions.")
    async def on_message(self,message):
        await enforce(message,self.rules,self.guild_id)
    async def on_raw_message_edit(self,event):
        if event.guild_id!=self.guild_id: return
        try:
            channel=self.get_channel(event.channel_id) or await self.fetch_channel(event.channel_id)
            message=await channel.fetch_message(event.message_id)
            await enforce(message,self.rules,self.guild_id)
        except (discord.Forbidden,discord.NotFound,discord.HTTPException):
            logging.warning('Unable to inspect edited Discord message.')

if __name__=='__main__':
    logging.basicConfig(level=logging.INFO)
    FilterBot(Rules(os.getenv('DATABASE_PATH','data/rules.sqlite3')),int(os.environ['DISCORD_GUILD_ID'])).run(os.environ['DISCORD_TOKEN'],log_handler=None)
