import sqlite3
import unicodedata
from contextlib import closing

# Common Latin lookalikes; this is intentionally not a complete confusable table.
LOOKALIKES = str.maketrans({'а':'a','е':'e','о':'o','р':'p','с':'c','х':'x','у':'y','і':'i','ј':'j','ѕ':'s','Α':'a','α':'a','Ε':'e','ε':'e','Ο':'o','ο':'o','Ι':'i','ι':'i','κ':'k','τ':'t','ν':'v','ρ':'p', '0':'o','1':'i','3':'e','4':'a','5':'s','7':'t','8':'b','@':'a','$':'s','!':'i'})

def normalize(text):
    text = unicodedata.normalize('NFKD', text).translate(LOOKALIKES).casefold().translate(LOOKALIKES)
    return ''.join(c for c in text if c.isalnum() and not unicodedata.combining(c))

class Rules:
    def __init__(self, path):
        self.path = str(path)
        with closing(self.connect()) as db:
            db.execute('CREATE TABLE IF NOT EXISTS rules (term TEXT PRIMARY KEY, canonical TEXT NOT NULL UNIQUE)')
            db.execute('CREATE TABLE IF NOT EXISTS attempts (ip TEXT, at REAL)')
            db.commit()
    def connect(self):
        return sqlite3.connect(self.path, timeout=15)
    def list(self):
        with closing(self.connect()) as db:
            return [r[0] for r in db.execute('SELECT term FROM rules ORDER BY term')]
    def add(self, term):
        term = term.strip()
        key = normalize(term)
        if not key or len(term)>100:
            raise ValueError('Use a rule with 1–100 characters and at least one letter or number.')
        with closing(self.connect()) as db:
            db.execute('INSERT OR IGNORE INTO rules VALUES (?,?)', (term,key)); db.commit()
    def remove(self, term):
        with closing(self.connect()) as db:
            db.execute('DELETE FROM rules WHERE term=?',(term,)); db.commit()
    def matches(self, text):
        content = normalize(text)
        with closing(self.connect()) as db:
            return any(key in content for key, in db.execute('SELECT canonical FROM rules'))
    def attempt(self, ip, now):
        # Atomic persistent limit, including successful attempts: five per five minutes/IP.
        with closing(self.connect()) as db:
            db.execute('BEGIN IMMEDIATE')
            db.execute('DELETE FROM attempts WHERE at <= ?', (now-300,))
            count=db.execute('SELECT COUNT(*) FROM attempts WHERE ip=?',(ip,)).fetchone()[0]
            if count >= 5:
                db.commit(); return False
            db.execute('INSERT INTO attempts VALUES (?,?)',(ip,now)); db.commit(); return True
