import base64
import hashlib
import hmac
import json
import secrets
import time


def password_hash(password):
    salt=secrets.token_bytes(16)
    digest=hashlib.scrypt(password.encode(),salt=salt,n=16384,r=8,p=1)
    return 'scrypt:'+salt.hex()+':'+digest.hex()


def password_ok(password, encoded):
    try:
        kind,salt,digest=encoded.split(':')
        return kind=='scrypt' and hmac.compare_digest(hashlib.scrypt(password.encode(),salt=bytes.fromhex(salt),n=16384,r=8,p=1).hex(),digest)
    except (ValueError,TypeError):
        return False


def sign(payload,key):
    body=base64.urlsafe_b64encode(json.dumps(payload,separators=(',',':')).encode()).decode()
    return body+'.'+hmac.new(key.encode(),body.encode(),hashlib.sha256).hexdigest()


def verify(token,key):
    try:
        body,signature=token.rsplit('.',1)
        if not hmac.compare_digest(signature,hmac.new(key.encode(),body.encode(),hashlib.sha256).hexdigest()): return None
        data=json.loads(base64.urlsafe_b64decode(body))
        if data['expires'] <= time.time(): return None
        return data
    except (ValueError,KeyError,TypeError): return None
