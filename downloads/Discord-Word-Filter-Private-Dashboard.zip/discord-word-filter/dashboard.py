import html
import json
import os
import secrets
import time
from http import cookies
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs
from core import Rules
from security import password_ok, sign, verify

class Handler(BaseHTTPRequestHandler):
    def setup(self):
        super().setup()
        self.connection.settimeout(10)
    def log_message(self, *args):
        pass  # Do not log submitted credentials, cookies, or rule text.
    def reply(self,status,body,token=None):
        data=body.encode()
        self.send_response(status)
        for key,value in {'Content-Type':'text/html; charset=utf-8','Content-Length':str(len(data)), 'Cache-Control':'no-store','X-Content-Type-Options':'nosniff','X-Frame-Options':'DENY','Content-Security-Policy':"default-src 'none'; form-action 'self'; frame-ancestors 'none'; base-uri 'none'",'Referrer-Policy':'no-referrer'}.items(): self.send_header(key,value)
        if token is not None:
            self.send_header('Set-Cookie','session='+token+'; HttpOnly; SameSite=Strict; Path=/; Max-Age='+('3600' if token else '0'))
        self.end_headers(); self.wfile.write(data)
    def session(self):
        try:
            jar=cookies.SimpleCookie(self.headers.get('Cookie',''))
            return verify(jar['session'].value,self.server.key)
        except (KeyError,cookies.CookieError): return None
    def page(self,session):
        csrf=html.escape(session['csrf'],quote=True)
        if not session['auth']:
            return '<h1>Private Discord filter</h1><form method="post" action="/login"><input type="hidden" name="csrf" value="'+csrf+'"><label>Password <input type="password" name="password" required autocomplete="current-password"></label><button>Log in</button></form>'
        fields='<input type="hidden" name="csrf" value="'+csrf+'">'
        rows=''.join('<li>'+html.escape(term)+'<form method="post" action="/remove">'+fields+'<input type="hidden" name="term" value="'+html.escape(term,quote=True)+'"><button>Remove</button></form></li>' for term in self.server.rules.list())
        return '<h1>Discord blacklist</h1><p>Changes apply to the next message or edit without restarting the bot.</p><ul>'+rows+'</ul><form method="post" action="/add">'+fields+'<label>Rule <input name="term" required maxlength="100"></label><button>Add</button></form><form method="post" action="/logout">'+fields+'<button>Log out</button></form>'
    def do_GET(self):
        if self.path=='/health': return self.reply(200,'ok')
        if self.path!='/': return self.reply(404,'Not found')
        session=self.session()
        token=None
        if not session:
            session={'auth':False,'csrf':secrets.token_urlsafe(32),'expires':time.time()+3600}
            token=sign(session,self.server.key)
        self.reply(200,self.page(session),token)
    def do_POST(self):
        if self.path not in ['/login','/add','/remove','/logout']: return self.reply(404,'Not found')
        try: size=int(self.headers.get('Content-Length','0'))
        except ValueError: return self.reply(400,'Invalid request')
        if not 0<size<=8192: return self.reply(413,'Request too large or empty')
        if self.headers.get('Content-Type','').split(';')[0]!='application/x-www-form-urlencoded': return self.reply(415,'Form required')
        try: form=parse_qs(self.rfile.read(size).decode(),max_num_fields=10)
        except (ValueError,UnicodeError): return self.reply(400,'Invalid form')
        session=self.session()
        if not session or not secrets.compare_digest(form.get('csrf',[''])[0],session['csrf']): return self.reply(403,'Invalid CSRF token')
        if self.path=='/login':
            if not self.server.rules.attempt(self.client_address[0],time.time()): return self.reply(429,'Try again in five minutes')
            if not password_ok(form.get('password',[''])[0],self.server.password): return self.reply(401,'Invalid password')
            session={'auth':True,'csrf':secrets.token_urlsafe(32),'expires':time.time()+3600}
            return self.reply(200,self.page(session),sign(session,self.server.key))
        if not session['auth']: return self.reply(401,'Log in first')
        if self.path=='/logout': return self.reply(200,'Logged out. <a href="/">Log in</a>', '')
        try:
            term=form.get('term',[''])[0]
            if self.path=='/add': self.server.rules.add(term)
            else: self.server.rules.remove(term)
        except ValueError as e: return self.reply(400,html.escape(str(e)))
        self.reply(200,self.page(session))

def make_server(address,rules,password,key):
    server=ThreadingHTTPServer(address,Handler)
    server.rules=rules; server.password=password; server.key=key
    return server

if __name__=='__main__':
    key=os.environ['SESSION_SECRET']
    if len(key)<32: raise SystemExit('SESSION_SECRET must have at least 32 characters')
    make_server((os.getenv('DASHBOARD_HOST','127.0.0.1'),8080),Rules(os.getenv('DATABASE_PATH','data/rules.sqlite3')),os.environ['ADMIN_PASSWORD_HASH'],key).serve_forever()
