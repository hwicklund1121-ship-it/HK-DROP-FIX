import html
import json
import os
import secrets
import time
from pathlib import Path
from http import cookies
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlsplit
from core import Rules
from security import password_ok, sign, verify
from ui import document, render, STYLE_HASH

class Handler(BaseHTTPRequestHandler):
    def setup(self):
        super().setup()
        self.connection.settimeout(10)
    def log_message(self, *args):
        pass  # Do not log submitted credentials, cookies, or rule text.
    def reply(self,status,body,token=None):
        data=(body if self.path=='/health' else document(body,Path(__file__).with_name('logo.png').is_file())).encode()
        self.send_response(status)
        for key,value in {'Content-Type':'text/html; charset=utf-8','Content-Length':str(len(data)), 'Cache-Control':'no-store','X-Content-Type-Options':'nosniff','X-Frame-Options':'DENY','Content-Security-Policy':f"default-src 'none'; img-src 'self'; style-src 'sha256-{STYLE_HASH}'; form-action 'self'; frame-ancestors 'none'; base-uri 'none'",'Referrer-Policy':'no-referrer'}.items(): self.send_header(key,value)
        if token is not None:
            self.send_header('Set-Cookie','session='+token+'; HttpOnly; SameSite=Strict; Path=/; Max-Age='+('3600' if token else '0'))
        self.end_headers(); self.wfile.write(data)
    def session(self):
        try:
            jar=cookies.SimpleCookie(self.headers.get('Cookie',''))
            return verify(jar['session'].value,self.server.key)
        except (KeyError,cookies.CookieError): return None
    def page(self,session,query='',notice=''):
        return render(session,self.server.rules.list() if session['auth'] else [],query,notice)
    def do_GET(self):
        if self.path=='/logo.png':
            path=Path(__file__).with_name('logo.png')
            try:
                data=path.read_bytes()
                if len(data)>2_000_000 or not data.startswith(b'\x89PNG\r\n\x1a\n'): raise ValueError('PNG required')
            except (OSError,ValueError): return self.reply(404,'Logo not found')
            self.send_response(200)
            self.send_header('Content-Type','image/png')
            self.send_header('Content-Length',str(len(data)))
            self.send_header('X-Content-Type-Options','nosniff')
            self.send_header('Cache-Control','no-store')
            self.end_headers(); self.wfile.write(data)
            return

        if self.path=='/health': return self.reply(200,'ok')
        if urlsplit(self.path).path!='/': return self.reply(404,'Not found')
        session=self.session()
        token=None
        if not session:
            session={'auth':False,'csrf':secrets.token_urlsafe(32),'expires':time.time()+3600}
            token=sign(session,self.server.key)
        query=parse_qs(urlsplit(self.path).query).get('q',[''])[0][:100]
        self.reply(200,self.page(session,query),token)
    def do_POST(self):
        if self.path not in ['/login','/add','/remove','/logout','/test']: return self.reply(404,'Not found')
        try: size=int(self.headers.get('Content-Length','0'))
        except ValueError: return self.reply(400,'Invalid request')
        if not 0<size<=8192: return self.reply(413,'Request too large or empty')
        if self.headers.get('Content-Type','').split(';')[0]!='application/x-www-form-urlencoded': return self.reply(415,'Form required')
        try: form=parse_qs(self.rfile.read(size).decode(),max_num_fields=10)
        except (ValueError,UnicodeError): return self.reply(400,'Invalid form')
        session=self.session()
        if not session or not secrets.compare_digest(form.get('csrf',[''])[0],session['csrf']): return self.reply(403,'Invalid CSRF token')
        if self.path=='/login':
            if not self.server.rules.attempt(self.client_address[0],time.time()): return self.reply(429,self.page(session,notice='Too many login attempts. Try again in five minutes.'))
            if not password_ok(form.get('password',[''])[0],self.server.password): return self.reply(401,self.page(session,notice='Incorrect password. Please try again.'))
            session={'auth':True,'csrf':secrets.token_urlsafe(32),'expires':time.time()+3600}
            return self.reply(200,self.page(session),sign(session,self.server.key))
        if not session['auth']: return self.reply(401,'Log in first')
        if self.path=='/logout': return self.reply(200,'<h1>Signed out</h1><p><a href="/">Return to sign in</a></p>', '')
        if self.path=='/test':
            message=form.get('message',[''])[0]
            if not message or len(message)>2000: return self.reply(400,self.page(session,notice='Enter a test message with 1–2000 characters.'))
            blocked=self.server.rules.matches(message)
            return self.reply(200,self.page(session,notice='Test result: '+('BLOCKED — this text matches your blacklist.' if blocked else 'ALLOWED — no current rule matched this text.')))
        try:
            term=form.get('term',[''])[0]
            if self.path=='/add': self.server.rules.add(term)
            else: self.server.rules.remove(term)
        except ValueError as e: return self.reply(400,self.page(session,notice=str(e)))
        self.reply(200,self.page(session,notice='Rule added. Changes apply immediately.' if self.path=='/add' else 'Rule removed. Changes apply immediately.'))

def make_server(address,rules,password,key):
    server=ThreadingHTTPServer(address,Handler)
    server.rules=rules; server.password=password; server.key=key
    return server

if __name__=='__main__':
    key=os.environ['SESSION_SECRET']
    if len(key)<32: raise SystemExit('SESSION_SECRET must have at least 32 characters')
    make_server((os.getenv('DASHBOARD_HOST','127.0.0.1'),8080),Rules(os.getenv('DATABASE_PATH','data/rules.sqlite3')),os.environ['ADMIN_PASSWORD_HASH'],key).serve_forever()
