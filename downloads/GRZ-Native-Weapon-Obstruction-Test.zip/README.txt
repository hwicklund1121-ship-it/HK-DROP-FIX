GRZ Native Weapon Obstruction TEST
Based on GRZ-SprintLean-Restore-Test. Only change: remove GRZ CheckLiftWeapon override so inherited weapon lift and obstruction processing runs.
No forced SendLiftWeaponSync(false, 0.0) from GRZ. Weapons may now lift/lower normally near obstacles.
Snappy movement preset (0.06/100/0.14/17/6.5), sprint lean restoration and camera code remain unchanged from the prior lean-restored test.
This isolates weapon obstruction; it does not change player collision or camera collision. No confirmed fix claim.
INSTALL: Back up existing GRZ_Movement.pbo outside loaded addon directories. Replace the same-name PBO on BOTH test server and clients. Remove duplicate old GRZ copies. Restart both. Unsigned; use your usual signing process if required.
TEST: At the same static object, run/stop and strafe toward/along/away from its edge. Compare empty hands versus rifle, lowered versus raised weapon, first versus third person, and open ground. Watch for body pulling, camera displacement and weapon lift. Have a second player observe if possible.
If unchanged or worse, restore your previous PBO and restart both.
VERIFIED: PBO checksum, all payload round-trips, ZIP integrity, client/SERVER preprocessing. NOT VERIFIED: Enforce compilation or in-game behavior.
