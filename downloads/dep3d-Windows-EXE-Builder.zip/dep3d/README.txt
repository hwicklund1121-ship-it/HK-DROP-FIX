MAKE A WINDOWS APPLICATION (dep3d.exe)

1. Install Windows Python 3.10 or newer (64-bit Python 3.12 recommended), including the Python launcher.
2. Extract this entire ZIP.
3. Double-click BUILD_EXE.cmd. Internet access is needed to install PyInstaller.
4. Your application will be in dist\dep3d.exe.

The resulting EXE is standalone: copy it anywhere; Python is not needed to run it. Build on Windows for a Windows EXE. A local .build-venv contains build dependencies, so no administrator installation is needed. Rebuilding replaces the generated dist\dep3d.exe.

Open CMD and run:
  "C:\Tools\dep3d.exe" "C:\Models\BC_A2CHEY.p3d"
  "C:\Tools\dep3d.exe" "C:\Models" -o "C:\Converted"
  "C:\Tools\dep3d.exe" --help

You can also drag a P3D onto dep3d.exe; use CMD to keep its output visible. Running the EXE alone shows usage, not a graphical window.

Converted files use _mlod names by default. Existing matching output files are overwritten; keep backups. Original input overwrite is refused. Model.cfg reconstruction is approximate.

Your converter was tested against BC_A2CHEY.p3d (ODOL 56, 10 LODs) and the generated MLOD passed its read-back check. This package supplies the Windows EXE builder, not an already compiled EXE. Windows packaging cannot be executed or verified in the current Linux environment.
