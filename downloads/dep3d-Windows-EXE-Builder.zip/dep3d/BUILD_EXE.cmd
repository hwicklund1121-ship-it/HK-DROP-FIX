@echo off
setlocal
pushd "%~dp0"
if errorlevel 1 exit /b 1
where py >nul 2>nul
if errorlevel 1 goto use_python
py -3 -m venv ".build-venv"
if errorlevel 1 goto failed
goto build

:use_python
where python >nul 2>nul
if errorlevel 1 goto missing_python
python -m venv ".build-venv"
if errorlevel 1 goto failed

:build
".build-venv\Scripts\python.exe" -m pip install --disable-pip-version-check -r "requirements-build.txt"
if errorlevel 1 goto failed
".build-venv\Scripts\python.exe" -m PyInstaller --noconfirm --clean --onefile --console --name dep3d "dep3d.py"
if errorlevel 1 goto failed
if not exist "dist\dep3d.exe" goto failed
echo.
echo SUCCESS: Your application is "%CD%\dist\dep3d.exe"
echo You can copy that EXE anywhere. Python is not needed to run it.
popd
pause
exit /b 0

:missing_python
echo ERROR: Install Python 3.10 or newer for Windows, including the Python launcher.
echo Python is needed only on the computer building the EXE.
popd
pause
exit /b 2

:failed
echo.
echo BUILD FAILED. Read the error above. No working EXE is confirmed.
popd
pause
exit /b 1
