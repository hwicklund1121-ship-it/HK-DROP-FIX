GRZ Sprint-start diagnostic test
Based on this repository's GRZ v0.32 sources, not a supplied deployed GRZ PBO.
Only runtime source change: GRZRunningLean.c calls super.OnSprintStart().
Original response settings retained: 0.06 / 100 / 0.14 / 17 / 6.5.
Native sprint lean restrictions may return. No other runtime source changes.
Back up your existing GRZ PBO outside loaded addon directories. Replace it with
this same-name PBO on the test server and clients; do not load both versions.
Restart server and clients. Sign with your own key if signatures are enforced;
this PBO is unsigned. Do not change signature enforcement for this test.
Compare jog-stop, sprint-stop, and crouch-run-stop, with identical gear.
Check whether post-stop body stutter changes; also check sprint lean and ADS.
If unchanged or worse, restore your backed-up PBO and restart.
Verified: client/SERVER preprocessing, PBO checksum and all payload round-trips.
Not verified: Enforce compilation or in-game behavior. This is not a confirmed fix.
