// Diagnostic: restore inherited sprint-start processing.
// Native sprint lean restrictions may return in this test.
modded class DayZPlayerImplement
{
    override void OnSprintStart()
    {
        super.OnSprintStart();
    }
}
