# GRZ Movement 0.7 — revert unsuccessful zoom changes

Fresh movement-response implementation for DayZ 1.30. Uses the supplied LWP response values: 0.01 sprint smoothing, 200 acceleration limit, 0.1 strafe smoothing, 17-degree turn threshold, 6.5 lean speed and unrestricted water movement speed. Initializes through the native implementation first. No animation assets from LUGU are included or changed.

This baseline matches movement response settings, not every behavior of the legacy movement PBO. Lean inputs remain available when sprint starts. Stamina, weapon sway, weapon lifting, item stance rules, movement-change callbacks, sprint-end cleanup and stance callbacks remain native. The built-in legacy camera policy selects raised stance cameras directly during transitions and restores sprint-camera selection from the movement index. It uses native camera FOV values and your FOV setting; it does not set a fixed FOV angle or force zoom input. Held eye zoom is preserved for standing/crouching movement; exact equivalence to a third-party FOV mod is not established. In particular, it does not abort weapon events or refresh weapon animations during stance changes. These legacy overrides are possible conflict points, not a confirmed diagnosis.

## Install and test

1. Extract the ZIP and load @GRZ_Movement on the client and server where required. Use the same build on both.
2. Disable lwp_movement, ronjam_fix and other movement replacements, including loose legacy 1337/OPM scripts in another PBO. GRZ cannot undo their overrides while they remain loaded.
3. Use the owner's verified working LUGU PBO. Remove previous experimental LUGU replacements and HK shoulder/camera/stance patches. This ZIP deliberately does not ship another LUGU version.
4. First test LUGU alone with required dependencies. Then add GRZ and repeat G → prone → look right → A/D, on flat ground and a hill. Compare rifle, pistol and empty hands. If LUGU alone fails, GRZ cannot establish that the movement mod caused it.
5. Disable StormZz_Zoom and other camera/FOV replacements when testing this build; GRZ now includes its own camera policy. Add other mods one at a time. Check sprint/strafe/lean, crouch, prone, recovery and held middle-mouse zoom. Keep any newly changed RPT/script errors.

Package checks verify PBO checksum, decompression and source round-trip. DayZ script compilation and movement compatibility require in-game validation; they have not been verified here. This is an unsigned test build; signature-enforcing public servers need an appropriate signed release.

Source: GRZ_Movement/scripts/4_World/GRZMovement.c. Rebuild with `python tools/build_grz_movement.py` from the repository root.

See PROVENANCE.md for package contents and rights limitations. No guarantee against copyright claims is made.

Version 0.3 adds only GRZRunningLean.c to the runtime payload. It skips the native sprint-start lean-input locks. Movement tuning and camera code are byte-identical to version 0.2. Test left/right lean while jogging and sprinting, hold lean while entering/leaving sprint, release lean to check return to center, and repeat the LUGU sequence. In-game validation is required.

Version 0.4 adds GRZSteadyCamera.c: zero sprint camera roll and removal of the crouch speed-height contribution after the native update. The raised crouch camera inherits this correction. Existing movement, running lean, FOV policy and LUGU resources are unchanged. This addresses third-person locomotion bob; first-person head-bone motion, intentional lean, recoil, impact shake, stance transitions and LUGU prone motion are not removed. Test sprint and crouch movement, both shoulders, held zoom, raised weapons and the drop sequence. Runtime validation is required.

Version 0.5 adds GRZHoldEyeZoom.c. After native view processing, an active held/toggled eye-zoom input restores NORMAL only if the native eye-zoom level was cleared during standing/crouching movement. It excludes ADS/scopes, fighting, prone, special commands and requested sprint. No saved zoom latch, forced FOV, camera-distance override or input override is used. All v0.4 runtime files remain byte-identical. Test holding middle mouse while repeatedly crouching/standing, starting zoom while crouched, releasing during a transition, sprint, ADS/scopes and LUGU. In-game validation is required.

Version 0.6 replaces the unsuccessful v0.5 HandleView patch with a held-input eye-zoom getter and a shared standing/crouching camera-distance hold. This targets both FOV and boom changes during crouching, without changing configured FOV or native smoothing. After prone-to-standing recovery, adds 0.4 meters of camera distance for 0.6 seconds then fades it out over 0.6 seconds. This applies to all prone recoveries, not exclusively the LUGU glitch. Prone output itself remains untouched. Eye zoom takes priority over recovery distance. Camera collision can still shorten the distance. These are unverified tuning choices, not a confirmed root-cause fix. Test button release, ADS, repeated crouch, flat-ground recovery and downhill drop. Earlier version notes describe historical builds.

Version 0.7 removes the v0.5/v0.6 eye-zoom overrides and camera-distance lock following in-game regression reports. Native eye zoom and crouch camera distance are restored; the original crouch pullback remains unresolved. Recovery clearance remains, but is bypassed while eye zoom or ADS input is active. Running lean, bob removal, response settings and the v0.4 legacy camera policy are unchanged. Historical version notes above do not describe the current zoom behavior.
