# Player animation graph inputs

Contains the seven uploaded graph sheets and player_main.asi unchanged under
original/, plus the existing seven-selector motorcycle-blocking experiment under
experiment/. Do not install the ZIP as a mod: it is source, not a compiled addon.

Inspection:
- All direct Child/Child0/Child1 node references resolve to definitions in the
  supplied graph sheets after removing resource GUID prefixes. This is a limited
  static reference check, not proof that the full project can compile.
- master.agf routes on-foot movement to LocomotionQ and vehicles to VehicleMaster.
- locomotion.agf selects ErcToCroT/CroToErcT for stationary crouch transitions,
  with separate lowered/raised groups selected by Raised.
- player_main.asi maps lowered unarmed crouch/stand transitions to:
  DZ/anims/anm/player/moves/unarmed/transitions/p_erc_trans_cro_low.anm
  DZ/anims/anm/player/moves/unarmed/transitions/p_cro_trans_erc_low.anm
- Those paths are not motorcycle clips. This does not exclude a shared-state,
  blending, IK or engine issue, and does not establish the cause of the arm pose.
- The ASI template reference is:
  DZ/anims/workspaces/player/player_main/player_main.ast
  That AST is not among the uploaded inputs.

No DayZ Tools graph compiler is installed here. The top-level graph resource /
project that assembles these sheets is also not supplied. master.agf is a sheet
containing MasterControl and Death, not a build manifest listing these files.
The animation assets referenced by the project must be available in the matching
DayZ Tools workspace. Packaging these text inputs alone in a PBO will not activate
the experimental graph edits.

Next build step: open the original player graph project in the matching DayZ Tools
workspace, substitute experiment/vehicles.agf for the original sheet, and compile
/export the graph. Keep all other inputs unchanged for this isolation test. The
resulting compiled graph can then be referenced from a separate addon config and
packed/signed. Do not replace base-game PBOs. In-game crouch and non-motorcycle
vehicle checks are still required; no runtime compatibility is claimed.
