// Original CustomWatermark by K3BA6; GRZ widget-lifetime correction.
#ifndef SERVER
modded class MissionGameplay
{
    Widget s_logowidget;
    ImageWidget s_logo;
    string activatelogo = "true";

    protected void GRZWatermarkCleanup()
    {
        if (GetGame())
            GetGame().GetCallQueue(CALL_CATEGORY_GAMEPLAY).Remove(this.DelayLogoStartup);
        s_logo = null;
        if (s_logowidget)
        {
            s_logowidget.Unlink();
            s_logowidget = null;
        }
    }

    override void OnMissionStart()
    {
        super.OnMissionStart();
        GRZWatermarkCleanup();
        if (!GetGame() || GetGame().IsDedicatedServer() || !LogoActivated())
            return;
        if (!GetGame().GetWorkspace())
            return;
        s_logowidget = GetGame().GetWorkspace().CreateWidgets("CustomWatermark/gui_watermark/client.layout");
        if (!s_logowidget)
        {
            Print("[GRZ Watermark v0.1] Layout creation failed; logo skipped.");
            return;
        }
        s_logo = ImageWidget.Cast(s_logowidget.FindAnyWidget("logo"));
        s_logowidget.Show(false);
        if (!s_logo)
        {
            Print("[GRZ Watermark v0.1] Image widget 'logo' missing; logo skipped.");
            GRZWatermarkCleanup();
            return;
        }
        // Original counter shows on its 17th one-second tick. Use one callback.
        GetGame().GetCallQueue(CALL_CATEGORY_GAMEPLAY).CallLater(DelayLogoStartup, 17000, false);
    }

    void DelayLogoStartup()
    {
        if (!GetGame() || GetGame().GetMission() != this || !s_logowidget || !s_logo)
        {
            Print("[GRZ Watermark v0.1] Mission/widget no longer available; logo skipped.");
            GRZWatermarkCleanup();
            return;
        }
        if (!s_logo.LoadImageFile(0, "set:logo image:logo"))
        {
            Print("[GRZ Watermark v0.1] Logo image failed to load; logo skipped.");
            GRZWatermarkCleanup();
            return;
        }
        s_logowidget.Show(true);
    }

    override void OnMissionFinish()
    {
        GRZWatermarkCleanup();
        super.OnMissionFinish();
    }

    void ~MissionGameplay()
    {
        GRZWatermarkCleanup();
    }

    bool LogoActivated()
    {
        return true;
    }
}
#endif
