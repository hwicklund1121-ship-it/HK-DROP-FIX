"""Replace only a CustomWatermark mission script, preserving other PBO entries."""
import argparse
import hashlib
from pathlib import Path
import struct
import zipfile
from pbo_format import read_pbo, decompress, compress_literals


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--input', type=Path, required=True)
    ap.add_argument('--script', type=Path, required=True)
    ap.add_argument('--readme', type=Path, required=True)
    ap.add_argument('--output', type=Path, required=True)
    args = ap.parse_args()
    original = args.input.read_bytes()
    properties, entries = read_pbo(original)
    target = b'5_Mission\\mission\\missiongameplay.c'
    patched = []
    replaced = 0
    for name, fields, payload in entries:
        if name == target:
            raw = args.script.read_bytes()
            meta = list(fields)
            if fields[0] == 0x43707273:
                payload = compress_literals(raw)
                meta[1] = len(raw)
            else:
                assert fields[0] == 0
                payload = raw
                meta[1] = 0
            meta[4] = len(payload)
            fields = tuple(meta)
            replaced += 1
        patched.append((name, fields, payload))
    assert replaced == 1
    header = properties + b''.join(n + b'\0' + struct.pack('<5I', *m) for n, m, _ in patched)
    body = header + b'\0' + bytes(20) + b''.join(d for _, _, d in patched)
    pbo = body + b'\0' + hashlib.sha1(body).digest()
    props2, entries2 = read_pbo(pbo)
    assert props2 == properties
    for old, new in zip(entries, entries2):
        if old[0] != target:
            assert old == new
        else:
            n, m, d = new
            assert (decompress(d, m[1]) if m[0] == 0x43707273 else d) == args.script.read_bytes()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    addon = '@CustomWatermark/addons/CustomWatermark.pbo'
    with zipfile.ZipFile(args.output, 'w', zipfile.ZIP_DEFLATED) as z:
        z.writestr(addon, pbo)
        z.write(args.readme, 'READ-ME-FIRST.txt')
        z.writestr('SHA256.txt', hashlib.sha256(pbo).hexdigest() + '  ' + addon + '\n')
        for n, m, d in entries2:
            raw = decompress(d, m[1]) if m[0] == 0x43707273 else d
            z.writestr('source/CustomWatermark/' + n.decode().replace('\\', '/'), raw)
        z.write(Path(__file__), 'source/tools/build_watermark_fix.py')
        import pbo_format
        z.write(Path(pbo_format.__file__), 'source/tools/pbo_format.py')
    with zipfile.ZipFile(args.output) as z:
        assert z.testzip() is None
        assert z.read(addon) == pbo
    print('PASS: one script changed; all other stored entries/properties identical; PBO/ZIP verified.')
    print(args.output)


if __name__ == '__main__':
    main()
