Restore the original zoom and movement PBOs

These are the exact original PBOs uploaded by the user, with no camera patches.
Back up the current files outside loaded addons folders, then replace both PBOs
in your mod's addons folder on client and server and restart. Load only one copy
of each. Disable standalone HK_CrouchZoom/HK_CrouchHandsGuard test addons. Use
the original Luigi PBO, not the unsuccessful motorcycle graph experiment.

Use your original matching signatures if your server requires signatures. This
ZIP does not include keys or signatures. It restores the original behavior; it
does not fix crouch unzoom or camera bob.
