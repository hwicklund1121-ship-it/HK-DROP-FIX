# GUNRUNNERZ AUTORUN v0.8 — explicit Q/E lean exceptions

Fix candidate for the owner's v0.7 report that Q/E still cancel autorun. The exact runtime cause was not logged. Q, E and Tab are now checked directly as physical key codes BEFORE any profile/action binding lookup and cannot cancel autorun through its fresh-key handler. This does not depend on lean inputs being unlocked or the legacy profile API mapping those keys correctly. Rebound lean keys still use the v0.7 profile lookup; their behavior remains unverified.

Because the explicit exceptions have priority, do not use Q, E or Tab as the autorun start/stop binding. If already bound there, it can start but that same key will not stop it; another non-exempt key still stops. Bind a different key under Controls > Unsorted. Manual movement cancellation and other state checks still apply, including if Q/E are also bound to a directional movement or raising action.

Inventory continuity from v0.7 remains. Full sprint, silent operation, HUD guard and server RPC/lease are unchanged. The actual sprint lean animation continues to depend on GRZ Movement permitting it; this addon does not force-unlock lean inputs.

Replace v0.7 (or v0.6) on both client and server via shared -mod; only one GRZ_Autorun PBO may be loaded. Back up the prior PBO and matching signature outside loaded addons; re-sign this changed PBO with your normal workflow. Test start > Q held > E held > alternating Q/E > release > Tab open/close > stop with another key. Confirm forward sprint continues throughout leaning, key-repeat does not stop, and the chosen autorun key still stops without restarting. Also check W/A/S/D, Escape, inventory interactions, aim/raise, death/reconnect and server movement agreement. If Q/E still stop it, provide that session's client script log and loaded-mod list so another copy or another stop path can be identified.

Package/source checks and SERVER preprocessing are local checks only. DayZ compilation and the Q/E fix are NOT runtime-verified. Rollback restores the prior PBO/signature; no persistence wipe. No movement/stamina/scope/LUGU file is included or changed.

Earlier version notes are historical where superseded above.

## v0.7 — inventory and lean exceptions

While autorun is active, Tab and keys assigned to lean left/right no longer cancel it. Lean keys are read from the current input profile using DayZ's action-key API; Q/E are not hard-coded. If a key is also assigned to the autorun action, that action retains its stop behavior. Key-repeat handling and fresh-key detection are unchanged. Custom/combination bindings need runtime verification.

The normal inventory screen (MENU_INVENTORY) may remain open during an already active autorun, including its normal input suppression. Closing it with Tab also keeps the run active. Autorun cannot be started inside inventory. Other menus, pause/settings/chat, other fresh keyboard keys, manual directional movement, raised weapon, death/unconsciousness/restraint and leaving the move command still cancel. Movement overrides and the existing server heartbeat continue while inventory is open. If inventory actions themselves raise the weapon or start a non-movement command, those existing checks still stop the run. Do not assume a custom inventory UI with a different menu ID is supported.

This change does not force-enable or unlock lean inputs. GRZ Movement already permits sprint leaning. Vanilla/other movement mods may lock lean during sprint even though this autorun addon no longer cancels on the lean key. No lean/animation code from other mods is copied here.

Full native sprint, the Unsorted GUNRUNNERZ AUTORUN binding, silent operation, stamina-bar visibility guard, fixed speed/angle, server ownership validation, 1-second heartbeat and 3.5-second lease are retained. GRZ_ActionStamina still provides punch/breath-only drain. No movement, stamina, scope or LUGU PBO is included or changed.

## Install/test/rollback

Replace the v0.6 GRZ_Autorun PBO with this build on both server and clients via normal shared -mod. Keep only one autorun copy. Back up the old PBO/signature outside loaded addons and re-sign the changed PBO through your normal signing workflow. The included PBO is unsigned.

Test: start autorun, open/close inventory with Tab several times, hold lean left/right, alternate lean, then release lean. Rebind lean to other simple keyboard keys and repeat. Check that an unrelated key and the autorun key still stop, and pressing the autorun key to stop cannot restart it that frame. Test W/A/S/D while leaning, Escape/settings, inventory interactions, raising a gun, menu opening by mouse, death/respawn, reconnect, loss of heartbeat and server/client agreement. Verify no run-in-place regression or stamina HUD flashing. Check starting inside inventory remains blocked. Profile key-code mapping, inventory update timing and custom bindings require actual DayZ tests.

Local verification covers package payloads/integrity, unchanged server protocol/input XML/localization/HUD code, and client/SERVER preprocessing. DayZ compilation, inventory autorun, rebound lean keys and multiplayer behavior are not verified here. Rollback restores v0.6 PBO and matching signature on both sides; no persistence wipe.

Previous version documentation below is historical where changed by v0.7.

## v0.6 — shared input-state test

Press the rebindable GUNRUNNERZ AUTORUN key once to start normal full sprint. Any fresh keyboard key press afterward stops it, including the same key. Held-key repetition is ignored. There is no speed setting, speed key, notification, chat ping or continuous log output. Bind the existing action under Controls > Unsorted (runtime display verification required). Old speed JSON files are ignored.

## Correction from v0.5

v0.5 applied input overrides only locally. v0.6 applies matching fixed native speed/angle overrides on the owning player's server entity via a dedicated reliable state RPC. The server accepts only that entity's authenticated owner and a boolean start/stop state; no client-selected speed, angle, position or velocity is accepted. Speed is fixed at native 3.0 and forward angle at 0.0. No position or velocity is written and native sprint restrictions remain in place.

A one-second active heartbeat renews a 3.5-second server lease. Stop clears local owned input immediately and sends stop to the server. The server also clears its input on lease expiry, death/unconsciousness/restraint/raised state or leaving the move command. There are no call-queue timers, no per-frame RPCs, no changes to engine reconciliation and no promise of general desync repair. RPC traffic/delivery and input behavior must be checked in DayZ. Packets in flight may delay the remote stop until delivery or lease expiry.

This corrects a concrete omission, not a verified root-cause diagnosis of every run-in-place symptom. API declarations and the public Carim/Schana autorun architecture were inspected as references; the original third-party addon is not bundled. Attribution and license notices are in the ZIP.

## Existing behavior

Manual movement also cancels as a fallback. Menus/disabled controls, raised hands/weapon, death, unconsciousness, restraint or leaving the normal movement command stop autorun. Mission initialization/reconnect starts OFF. A native HUD visibility guard suppresses stamina-bar dimming while active without changing its amount or forcing the parent HUD visible. Custom HUD behavior is unverified.

This addon does not change stamina costs. Keep the existing GRZ_ActionStamina addon for empty-hands punch/breath-only drain. Existing movement/FOV/LUGU files are not part of this download and are not changed.

## Install and rollback

Stop client AND server. Back up the old GRZ_Autorun PBO/signature outside all loaded addon directories. Replace it with this exact build on BOTH sides, distributed via shared -mod; do not load duplicate versions or another autorun addon. Installing only on the client cannot supply the new server RPC handler. Use the owner's normal signing/public-key distribution workflow where required; do not disable verification.

Release manual movement keys, start autorun, and verify forward sprint rather than running in place. Stop with an unbound keyboard key, modifier, the autorun key and movement keys. Test menus, aim, jump/vehicle transitions, death/respawn and reconnect. Check that cancellation cannot restart in the same frame, that server movement stops after loss of heartbeat, and that stamina/punch/breath and HUD behavior are preserved. Do this on the test deployment first.

Rollback: stop both, restore the previous PBO/signature or remove this addon from both shared launch lists, restart. No persistence wipe is required.

Local validation covers PBO checksum, compressed payload/source round-trip, ZIP CRC, XML/localization consistency, source rebuild and client/SERVER preprocessing of the shared protocol. Enforce compilation, live server authority/ownership checks, heartbeat timing, sprinting and animation behavior remain unverified without DayZ.
