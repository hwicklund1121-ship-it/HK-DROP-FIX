dep3d - Windows Command Prompt P3D debinarizer

Requires Python 3 (standard library only; no pip packages). This is a CMD launcher plus Python source, not a standalone EXE.
Extract the entire ZIP and keep dep3d.cmd beside dep3d.py. Open CMD in that folder.

Usage:
  dep3d.cmd "C:\Models\model.p3d"
  dep3d.cmd "C:\Models" -o "C:\Converted"
  dep3d.cmd "C:\Models\model.p3d" --no-cfg
  dep3d.cmd --help

From another folder, use the full quoted path to dep3d.cmd. Add this extracted folder to PATH if you want to run dep3d from any CMD window. From another batch script use CALL dep3d.cmd followed by your arguments.

Output: model_mlod.p3d and reconstructed model_mlod_model.cfg by default. Keep originals backed up; output files with matching names are overwritten. The tool refuses to overwrite the input P3D itself. Folder inputs are recursive. Use a separate output folder outside the input tree to keep repeated folder runs simple. Reconstructed model.cfg is approximate and needs review. Textures/material files are not included or extracted from elsewhere.

Exit status: 0 on successful/skipped conversion; 1 if any conversion failed; 2 for usage errors or missing Python. The CMD launcher does not pause, so it can be used in scripts.

Packaged from your supplied Python converter. Its parsing/conversion logic is retained; the launcher was separated and mixed-batch failures now return a nonzero status. Windows launcher execution requires testing on Windows.
