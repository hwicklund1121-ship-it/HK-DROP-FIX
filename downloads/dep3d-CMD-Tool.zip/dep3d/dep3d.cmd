@echo off
setlocal
where py >nul 2>nul
if errorlevel 1 goto use_python
py -3 "%~dp0dep3d.py" %*
exit /b %errorlevel%

:use_python
where python >nul 2>nul
if errorlevel 1 goto missing_python
python "%~dp0dep3d.py" %*
exit /b %errorlevel%

:missing_python
echo ERROR: Python 3 is required. Install Python 3 and enable its command-line launcher. 1>&2
exit /b 2
