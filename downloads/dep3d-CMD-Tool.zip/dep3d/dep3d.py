# dep3d - binarised DayZ p3d (ODOL) -> MLOD. Single-file build: line 1 is batch, the rest is Python.
# ======== lzo.py ========
"""Pure-Python LZO1X decompressor (as used inside ODOL / PBO data).

ODOL does not store the compressed size of a block, only the expected
decompressed size, so the decoder must report how many input bytes it consumed.
"""


class LZOError(Exception):
    pass


def _copy_match(out, dist, length):
    start = len(out) - dist
    if start < 0:
        raise LZOError("lookbehind overrun")
    if dist >= length:
        out += out[start:start + length]
    else:  # overlapping copy, byte by byte semantics
        for k in range(length):
            out.append(out[start + k])


def decompress(buf, pos, expected):
    """Decompress LZO1X data from buf starting at pos.

    Returns (bytes, new_pos)."""
    out = bytearray()
    ip = pos
    b = buf

    def need_out(n):
        if len(out) + n > expected:
            raise LZOError("output overrun")

    state = 0  # 0 = start, decide by first byte
    t = 0
    if b[ip] > 17:
        t = b[ip] - 17
        ip += 1
        if t < 4:
            # match_next: copy t literals then read match
            need_out(t)
            out += b[ip:ip + t]
            ip += t
            t = b[ip]
            ip += 1
            state = 2  # go to match
        else:
            need_out(t)
            out += b[ip:ip + t]
            ip += t
            state = 1  # first_literal_run
    while True:
        if state == 0:
            # B_3: literal run
            t = b[ip]
            ip += 1
            if t >= 16:
                state = 2
                continue
            if t == 0:
                while b[ip] == 0:
                    t += 255
                    ip += 1
                t += 15 + b[ip]
                ip += 1
            n = t + 3
            need_out(n)
            out += b[ip:ip + n]
            ip += n
            state = 1
            continue
        if state == 1:
            # first_literal_run
            t = b[ip]
            ip += 1
            if t >= 16:
                state = 2
                continue
            dist = 1 + 0x0800 + (t >> 2) + (b[ip] << 2)
            ip += 1
            need_out(3)
            _copy_match(out, dist, 3)
            state = 3
            continue
        if state == 2:
            # match
            if t >= 64:
                dist = 1 + ((t >> 2) & 7) + (b[ip] << 3)
                ip += 1
                length = (t >> 5) - 1 + 2
            elif t >= 32:
                t &= 31
                if t == 0:
                    while b[ip] == 0:
                        t += 255
                        ip += 1
                    t += 31 + b[ip]
                    ip += 1
                dist = 1 + (b[ip] >> 2) + (b[ip + 1] << 6)
                ip += 2
                length = t + 2
            elif t >= 16:
                dist = (t & 8) << 11
                t &= 7
                if t == 0:
                    while b[ip] == 0:
                        t += 255
                        ip += 1
                    t += 7 + b[ip]
                    ip += 1
                dist += (b[ip] >> 2) + (b[ip + 1] << 6)
                ip += 2
                if dist == 0:
                    # end of stream marker
                    if len(out) != expected:
                        raise LZOError("output underrun (%d of %d)" % (len(out), expected))
                    return bytes(out), ip
                dist += 0x4000
                length = t + 2
            else:
                dist = 1 + (t >> 2) + (b[ip] << 2)
                ip += 1
                length = 2
            need_out(length)
            _copy_match(out, dist, length)
            state = 3
            continue
        if state == 3:
            # match_done
            t = b[ip - 2] & 3
            if t == 0:
                state = 0
                continue
            need_out(t)
            out += b[ip:ip + t]
            ip += t
            t = b[ip]
            ip += 1
            state = 2
            continue


# ======== binreader.py ========
import struct



class Reader:
    """Little-endian binary reader with the RV-engine array helpers."""

    def __init__(self, data, pos=0):
        self.d = data
        self.pos = pos
        self.version = 0
        self.use_lzo = False
        self.use_comp_flag = False

    # ---- primitives -----------------------------------------------------
    def bytes(self, n):
        v = self.d[self.pos:self.pos + n]
        if len(v) != n:
            raise EOFError("read past end at %d" % self.pos)
        self.pos += n
        return v

    def _s(self, fmt, size):
        v = struct.unpack_from(fmt, self.d, self.pos)
        self.pos += size
        return v

    def u8(self):
        v = self.d[self.pos]
        self.pos += 1
        return v

    def i8(self):
        return self._s('<b', 1)[0]

    def bool(self):
        return self.u8() != 0

    def u16(self):
        return self._s('<H', 2)[0]

    def i16(self):
        return self._s('<h', 2)[0]

    def u32(self):
        return self._s('<I', 4)[0]

    def i32(self):
        return self._s('<i', 4)[0]

    def f32(self):
        return self._s('<f', 4)[0]

    def vec3(self):
        return self._s('<3f', 12)

    def asciiz(self):
        end = self.d.index(b'\0', self.pos)
        s = self.d[self.pos:end].decode('latin-1')
        self.pos = end + 1
        return s

    def matrix(self):
        """4x3 matrix: aside, up, dir, position."""
        v = self._s('<12f', 48)
        return (v[0:3], v[3:6], v[6:9], v[9:12])

    # ---- arrays ------------------------------------------------------------
    def array(self, fn, n=None):
        if n is None:
            n = self.i32()
        return [fn() for _ in range(n)]

    def compressed(self, expected, force=False):
        """Raw (maybe compressed) block of `expected` bytes."""
        if expected == 0:
            return b''
        if self.use_lzo:
            is_comp = expected >= 1024 or force
            if self.use_comp_flag:
                is_comp = self.bool()
            if not is_comp:
                return self.bytes(expected)
            data, self.pos = decompress(self.d, self.pos, expected)
            return data
        if expected < 1024:
            return self.bytes(expected)
        raise NotImplementedError("LZSS-compressed ODOL (very old versions) not supported")

    def compressed_array(self, fmt, elem_size):
        """count + compressed block of fixed-size structs. Returns list of tuples or scalars."""
        n = self.i32()
        raw = self.compressed(n * elem_size)
        return _unpack_many(raw, fmt, elem_size, n)

    def condensed_array(self, fmt, elem_size):
        """count + defaultFill flag + (single element | compressed block)."""
        n = self.i32()
        default_fill = self.bool()
        if default_fill:
            v = self._s('<' + fmt, elem_size)
            v = v[0] if len(v) == 1 else v
            return [v] * n
        raw = self.compressed(n * elem_size)
        return _unpack_many(raw, fmt, elem_size, n)


def _unpack_many(raw, fmt, elem_size, n):
    if n == 0:
        return []
    vals = struct.unpack('<' + fmt * n, raw[:n * elem_size])
    per = len(vals) // n
    if per == 1:
        return list(vals)
    return [vals[i:i + per] for i in range(0, len(vals), per)]


# ======== odol.py ========
"""ODOL (binarised p3d) reader.

Structure follows the MIT-licensed BIS.P3D reader (bis-file-formats), checked
against DayZ 1.30 assets (ODOL v56). Version gates for v44-v75 are kept so
Arma 3 era files parse too.
"""
from types import SimpleNamespace as NS


ANIM_TYPES = {
    0: 'rotation', 1: 'rotationX', 2: 'rotationY', 3: 'rotationZ',
    4: 'translation', 5: 'translationX', 6: 'translationY', 7: 'translationZ',
    8: 'direct', 9: 'hide',
}


class ODOLError(Exception):
    pass


def read_model_info(r, v, nlods, dayz=False):
    m = NS()
    m.special = r.i32()
    m.bounding_sphere = r.f32()
    m.geometry_sphere = r.f32()
    m.remarks = r.i32()
    m.and_hints = r.i32()
    m.or_hints = r.i32()
    m.aiming_center = r.vec3()
    m.color = r.u32()
    m.color_type = r.u32()
    m.view_density = r.f32()
    m.bbox_min = r.vec3()
    m.bbox_max = r.vec3()
    if v >= 70:
        m.lod_density_coef = r.f32()
    if v >= 71:
        m.draw_importance = r.f32()
    if v >= 52:
        m.bbox_min_visual = r.vec3()
        m.bbox_max_visual = r.vec3()
    m.bounding_center = r.vec3()
    m.geometry_center = r.vec3()
    m.center_of_mass = r.vec3()
    m.inv_inertia = [r.vec3() for _ in range(3)]
    m.auto_center = r.bool()
    m.lock_auto_center = r.bool()
    m.can_occlude = r.bool()
    m.can_be_occluded = r.bool()
    if dayz:
        # DayZ fork of ODOL v56 carries 9 extra bytes here (flag + 2 floats)
        m.dayz_flag = r.u8()
        m.dayz_f1 = r.f32()
        m.dayz_f2 = r.f32()
    if v >= 73:
        m.ai_covers = r.bool()
    if v >= 42:
        m.ht_min, m.ht_max, m.af_max, m.mf_max = r.f32(), r.f32(), r.f32(), r.f32()
    if v >= 43:
        m.m_fact, m.t_body = r.f32(), r.f32()
    if v >= 33:
        m.force_not_alpha = r.bool()
    if v >= 37:
        m.sb_source = r.i32()
        m.prefer_shadow_volume = r.bool()
    if v >= 48:
        m.shadow_offset = r.f32()
    m.animated = r.bool()
    # skeleton
    sk = NS(name=r.asciiz(), discrete=False, bones=[], pivots='')
    if sk.name:
        if v >= 23:
            sk.discrete = r.bool()
        sk.bones = r.array(lambda: (r.asciiz(), r.asciiz()))
        if v > 40:
            sk.pivots = r.asciiz()
    m.skeleton = sk
    m.map_type = r.u8()
    m.mass_array = r.compressed_array('f', 4)
    m.mass = r.f32()
    m.inv_mass = r.f32()
    m.armor = r.f32()
    m.inv_armor = r.f32()
    if v >= 72:
        m.explosion_shielding = r.f32()
    m.lod_index = {}
    if dayz:
        order = ('memory', 'geometry', 'geometry_phys', 'geometry_fire', 'geometry_view',
                 'geometry_view_pilot', 'geometry_view_gunner', '_unknown', 'geometry_view_cargo',
                 'land_contact', 'roadway', 'paths', 'hitpoints')
    else:
        if v >= 53:
            m.lod_index['geometry_simple'] = r.u8()
        if v >= 54:
            m.lod_index['geometry_phys'] = r.u8()
        order = ('memory', 'geometry', 'geometry_fire', 'geometry_view', 'geometry_view_pilot',
                 'geometry_view_gunner', '_unknown', 'geometry_view_cargo', 'land_contact',
                 'roadway', 'paths', 'hitpoints')
    for k in order:
        m.lod_index[k] = r.u8()
    m.min_shadow = r.u32()
    if v >= 38:
        m.can_blend = r.bool()
    m.class_name = r.asciiz()
    m.damage = r.asciiz()
    m.frequent = r.bool()
    if v >= 31:
        m.unused31 = r.u32()
    if dayz:
        m.dayz_tail = r.u8()
    if v >= 57:
        m.pref_shadow_volume_lod = [r.i32() for _ in range(nlods)]
        m.pref_shadow_buffer_lod = [r.i32() for _ in range(nlods)]
        m.pref_shadow_buffer_lod_vis = [r.i32() for _ in range(nlods)]
    return m


def read_anim_class(r, v, dayz=False, hide2=True):
    a = NS()
    a.type = r.u32()
    a.name = r.asciiz()
    a.source = r.asciiz()
    a.min_phase, a.max_phase, a.min_value, a.max_value = r.f32(), r.f32(), r.f32(), r.f32()
    a.anim_period = a.init_phase = 0.0
    if v >= 56 and not dayz:
        a.anim_period = r.f32()
        a.init_phase = r.f32()
    a.source_address = r.u32()
    t = a.type
    if t <= 3:
        a.angle0, a.angle1 = r.f32(), r.f32()
    elif t <= 7:
        a.offset0, a.offset1 = r.f32(), r.f32()
    elif t == 8:
        a.axis_pos = r.vec3()
        a.axis_dir = r.vec3()
        a.angle = r.f32()
        a.axis_offset = r.f32()
    elif t == 9:
        a.hide_value = r.f32()
        if v >= 55 and hide2:
            a.unhide_value = r.f32()
    else:
        raise ODOLError("unknown animation type %d (%s)" % (t, a.name))
    return a


def read_animations(r, v, dayz=False, hide2=True):
    an = NS()
    an.classes = r.array(lambda: read_anim_class(r, v, dayz, hide2))
    # per LOD -> per bone -> list of animation indices
    an.bones2anims = r.array(lambda: r.array(lambda: r.array(r.u32)))
    an.anims2bones = []
    an.axis = []
    for _lod in an.bones2anims:
        a2b, ax = [], []
        for cls in an.classes:
            b = r.i32()
            a2b.append(b)
            if b != -1 and cls.type not in (8, 9):
                ax.append((r.vec3(), r.vec3()))
            else:
                ax.append(None)
        an.anims2bones.append(a2b)
        an.axis.append(ax)
    return an


def read_material(r):
    m = NS()
    m.name = r.asciiz()
    m.version = ver = r.u32()
    m.emissive = r._s('<4f', 16)
    m.ambient = r._s('<4f', 16)
    m.diffuse = r._s('<4f', 16)
    m.forced_diffuse = r._s('<4f', 16)
    m.specular = r._s('<4f', 16)
    m.specular2 = r._s('<4f', 16)
    m.specular_power = r.f32()
    if ver >= 20:
        # DayZ material block (v20): 104 bytes of extra shader parameters
        m.dayz_params = r.bytes(104)
    m.pixel_shader = r.u32()
    m.vertex_shader = r.u32()
    m.main_light = r.u32()
    m.fog_mode = r.u32()
    if ver == 3:
        r.bool()
    m.surface = r.asciiz() if ver >= 6 else ''
    if ver >= 4:
        m.n_render_flags = r.u32()
        m.render_flags = r.u32()
    n_stages = r.u32() if ver > 6 else 0
    n_texgen = r.u32() if ver > 8 else n_stages

    def stage_tex():
        s = NS(filter=0, texture='', stage_id=0, world_env=False)
        if ver >= 5:
            s.filter = r.u32()
        s.texture = r.asciiz()
        if ver >= 8:
            s.stage_id = r.u32()
        if ver >= 11:
            s.world_env = r.bool()
        return s

    def stage_tf():
        return NS(uv_source=r.u32(), matrix=r.matrix())

    m.stages, m.texgens = [], []
    if ver < 8:
        for _ in range(n_stages):
            m.texgens.append(stage_tf())
            m.stages.append(stage_tex())
    else:
        m.stages = [stage_tex() for _ in range(n_stages)]
        m.texgens = [stage_tf() for _ in range(n_texgen)]
    m.stage_ti = stage_tex() if ver >= 10 else None
    return m


def read_uvset(r, v):
    u = NS(discrete=v >= 45, min_u=0.0, min_v=0.0, max_u=1.0, max_v=1.0)
    if v >= 45:
        u.min_u, u.min_v, u.max_u, u.max_v = r.f32(), r.f32(), r.f32(), r.f32()
    u.n = r.u32()
    u.default_fill = r.bool()
    esz = 4 if v >= 45 else 8
    if u.default_fill:
        u.default = r.bytes(esz)
        u.data = None
    else:
        u.data = r.compressed(u.n * esz)
    return u


def uvset_values(u):
    import struct
    if u.discrete:
        du = u.max_u - u.min_u
        dv = u.max_v - u.min_v

        def sc(val, d, mn):
            return 1.52587890625e-05 * (val + 32767) * d + mn
        if u.default_fill:
            a, b = struct.unpack('<2h', u.default)
            return [(sc(a, du, u.min_u), sc(b, dv, u.min_v))] * u.n
        raw = struct.unpack('<%dh' % (u.n * 2), u.data)
        return [(sc(raw[i], du, u.min_u), sc(raw[i + 1], dv, u.min_v)) for i in range(0, len(raw), 2)]
    if u.default_fill:
        return [struct.unpack('<2f', u.default)] * u.n
    raw = struct.unpack('<%df' % (u.n * 2), u.data)
    return [(raw[i], raw[i + 1]) for i in range(0, len(raw), 2)]


def read_lod(r, v, resolution):
    L = NS(resolution=resolution)
    idx_fmt, idx_sz = ('i', 4) if v >= 69 else ('H', 2)

    def proxy():
        p = NS(model=r.asciiz(), matrix=r.matrix(), seq_id=r.i32(), sel_index=r.i32(), bone_index=r.i32())
        p.section_index = r.i32() if v >= 40 else -1
        return p
    L.proxies = r.array(proxy)
    L.subskel_to_skel = r.array(r.i32)
    L.skel_to_subskel = r.array(lambda: r.array(r.i32))
    if v >= 50:
        L.vertex_count = r.u32()
    else:
        L.clip_old = r.condensed_array('i', 4)
    if v >= 51:
        L.face_area = r.f32()
    L.or_hints = r.i32()
    L.and_hints = r.i32()
    L.bmin = r.vec3()
    L.bmax = r.vec3()
    L.bcenter = r.vec3()
    L.bradius = r.f32()
    L.textures = r.array(r.asciiz)
    L.materials = r.array(lambda: read_material(r))
    L.point_to_vertex = r.compressed_array(idx_fmt, idx_sz)
    L.vertex_to_point = r.compressed_array(idx_fmt, idx_sz)
    # polygons
    nfaces = r.i32()
    L.faces_alloc = r.u32()
    L.faces_unused = r.u16()
    faces = []
    for _ in range(nfaces):
        n = r.u8()
        faces.append(r._s('<%d%s' % (n, idx_fmt), n * idx_sz))
    L.faces = faces

    def section():
        s = NS()
        s.face_lo, s.face_hi = r.i32(), r.i32()
        s.min_bone, s.bones_count = r.i32(), r.i32()
        s.unused = r.u32()
        s.texture_index = r.i16()
        s.special = r.u32()
        s.material_index = r.i32()
        s.material = r.asciiz() if s.material_index == -1 else None
        if v >= 36:
            s.area_over_tex = r.array(r.f32)
            if v >= 67:
                f = r.i32()
                if f >= 1:
                    [r.f32() for _ in range(11)]
        else:
            s.area_over_tex = [r.f32()]
        return s
    L.sections = r.array(section)

    def named_sel():
        s = NS()
        s.name = r.asciiz()
        s.faces = r.compressed_array(idx_fmt, idx_sz)
        s.unused = r.i32()
        s.is_sectional = r.bool()
        s.sections = r.compressed_array('i', 4)
        s.vertices = r.compressed_array(idx_fmt, idx_sz)
        n = r.i32()
        s.weights = r.compressed(n)
        return s
    L.selections = r.array(named_sel)
    L.properties = r.array(lambda: (r.asciiz(), r.asciiz()))
    L.frames = r.array(lambda: (r.f32(), r.array(r.vec3)))
    L.color_top = r.u32()
    L.color = r.u32()
    L.special = r.i32()
    L.vbr_simple = r.bool()
    L.rest_size = r.u32()
    rest_start = r.pos
    if v >= 50:
        L.clip = r.condensed_array('i', 4)
    else:
        L.clip = L.clip_old
    uv0 = read_uvset(r, v)
    nuv = r.u32()
    L.uvsets = [uv0] + [read_uvset(r, v) for _ in range(nuv - 1)]
    L.vertices = r.compressed_array('3f', 12)
    if v >= 45:
        L.normals_packed = r.condensed_array('i', 4)
        L.st = r.compressed_array('ii', 8)
    else:
        L.normals_float = r.condensed_array('3f', 12)
        L.st = r.compressed_array('6f', 24)
    # skinning: (count, 4x(u8 bone, u8 weight)) per vertex
    L.vertex_bone_ref = r.compressed_array('i8B', 12)
    L.neighbor_bone_ref = r.compressed_array('H2Bi8BH2Bi8B', 32)
    if v >= 67:
        r.u32()
    if r.pos - rest_start != L.rest_size:
        L.warn = "rest-of-data size mismatch: stored %d, read %d" % (L.rest_size, r.pos - rest_start)
    if v >= 68:
        r.u8()
    return L


def unpack_normal(val):
    sf = -1.0 / 511.0
    x = val & 0x3FF
    y = (val >> 10) & 0x3FF
    z = (val >> 20) & 0x3FF
    if x > 511:
        x -= 1024
    if y > 511:
        y -= 1024
    if z > 511:
        z -= 1024
    return (x * sf, y * sf, z * sf)


def lod_normals(L):
    if hasattr(L, 'normals_packed'):
        return [unpack_normal(n) for n in L.normals_packed]
    return list(L.normals_float)


VARIANTS = [
    ('DayZ', dict(dayz=True, hide2=True)),
    ('DayZ', dict(dayz=True, hide2=False)),
    ('Arma', dict(dayz=False, hide2=True)),
]


def read_odol(data):
    """Try each known layout; accept the first whose LOD offsets line up exactly."""
    errors = []
    for label, opts in VARIANTS:
        try:
            o = _read_odol(data, **opts)
        except ODOLError:
            raise
        except Exception as e:  # layout mismatch -> try the next variant
            errors.append('%s %s: %s: %s' % (label, opts, type(e).__name__, e))
            continue
        bad = [w for w in o.warnings if 'expected' in w]
        if bad:
            errors.append('%s %s: %s' % (label, opts, bad[0]))
            continue
        o.flavor = label
        return o
    raise ODOLError('could not parse file with any known layout:\n  ' + '\n  '.join(errors))


class LayoutMismatch(Exception):
    pass


def _read_odol(data, dayz=True, hide2=True):
    r = Reader(data)
    if r.bytes(4) != b'ODOL':
        if data[:4] == b'MLOD':
            raise ODOLError("file is already MLOD (unbinarised)")
        raise ODOLError("not an ODOL p3d")
    o = NS()
    o.version = v = r.u32()
    r.version = v
    if v < 44:
        raise ODOLError("ODOL v%d is too old (pre-LZO) - not supported" % v)
    r.use_lzo = v >= 44
    r.use_comp_flag = v >= 64
    if v >= 75:
        e1, e2 = r.u32(), r.u32()
        if e1 or e2:
            raise ODOLError("this p3d is encrypted (ODOL v75 protected) - cannot be read")
    o.app_id = r.u32() if v >= 59 else 0
    o.muzzle_flash = r.asciiz() if v >= 58 else ''
    o.resolutions = r.array(r.f32)
    nlods = len(o.resolutions)
    o.model_info = read_model_info(r, v, nlods, dayz)
    o.animations = None
    if v >= 30 and r.bool():
        o.animations = read_animations(r, v, dayz, hide2)
    starts = [r.u32() for _ in range(nlods)]
    ends = [r.u32() for _ in range(nlods)]
    permanent = [r.bool() for _ in range(nlods)]
    o.loadable = []
    for i in range(nlods):
        if not permanent[i]:
            li = NS(nfaces=r.i32(), color=r.u32(), special=r.i32(), or_hints=r.u32())
            if v >= 39:
                li.has_skeleton = r.bool()
            if v >= 51:
                li.nverts = r.i32()
                li.face_area = r.f32()
            o.loadable.append(li)
        else:
            o.loadable.append(None)
    if nlods and r.pos != min(starts):
        raise LayoutMismatch('header ends at %d but first LOD starts at %d' % (r.pos, min(starts)))
    o.lods = []
    o.warnings = []
    for i in range(nlods):
        r.pos = starts[i]
        L = read_lod(r, v, o.resolutions[i])
        if r.pos != ends[i]:
            o.warnings.append("LOD %g: ended at %d, expected %d" % (o.resolutions[i], r.pos, ends[i]))
        if getattr(L, 'warn', None):
            o.warnings.append("LOD %g: %s" % (o.resolutions[i], L.warn))
        o.lods.append(L)
    return o


# ======== convert.py ========
"""ODOL -> MLOD reconstruction."""
import math
from collections import defaultdict
from types import SimpleNamespace as NS


# ---------------------------------------------------------------- LOD names
SPECIAL_LODS = [
    (1e13, 'Geometry'), (2e13, 'Geometry Buoyancy'), (4e13, 'Geometry PhysX'),
    (1e15, 'Memory'), (2e15, 'Land Contact'), (3e15, 'Roadway'), (4e15, 'Paths'),
    (5e15, 'Hit-points'), (6e15, 'View Geometry'), (7e15, 'Fire Geometry'),
    (8e15, 'View Cargo Geometry'), (9e15, 'View Cargo Fire Geometry'),
    (1e16, 'View Commander'), (1.1e16, 'View Commander Geometry'),
    (1.2e16, 'View Commander Fire Geometry'), (1.3e16, 'View Pilot Geometry'),
    (1.4e16, 'View Pilot Fire Geometry'), (1.5e16, 'View Gunner Geometry'),
    (1.6e16, 'View Gunner Fire Geometry'), (1.7e16, 'Sub Parts'),
    (1.8e16, 'Shadow Volume - View Cargo'), (1.9e16, 'Shadow Volume - View Pilot'),
    (2e16, 'Shadow Volume - View Gunner'), (2.1e16, 'Wreck'),
]


def lod_name(res):
    for v, n in SPECIAL_LODS:
        if abs(res - v) <= v * 1e-6:
            return n
    if 1000 <= res < 1200:
        return 'View Gunner (%g)' % res
    if 1200 <= res < 1300:
        return 'View Pilot (%g)' % res
    if 10000 <= res < 20000:
        return 'Shadow Volume %g' % (res - 10000)
    if res >= 1e13:
        return 'Special %g' % res
    return 'Resolution %g' % res


# ---------------------------------------------------------------- helpers
def clip_to_point_flags(clip):
    """Engine clip flags -> MLOD point flags (land/decal/fog/light/user hints)."""
    f = 0
    f |= (clip & 0x00000F00) >> 8     # land     0x100 step  -> 0x1 step
    f |= (clip & 0x00003000) >> 4     # decal    0x1000 step -> 0x100 step
    f |= (clip & 0x0000C000) >> 2     # fog      0x4000 step -> 0x1000 step
    f |= (clip & 0x000F0000) >> 12    # lighting 0x10000     -> 0x10 step
    f |= (clip & 0x0FF00000) >> 4     # user     0x100000    -> 0x10000 step
    return f


def weight_to_mlod_byte(w):
    """MLOD selection byte: 0 = not selected, 1 = 1.0, b -> (256-b)/255."""
    if w <= 0.0:
        return 0
    if w >= 0.999:
        return 1
    return max(2, min(255, int(round(256 - w * 255))))


def face_byte_offsets(faces, idx_size):
    """Byte offset of each face inside the ODOL polygon block (sections use these)."""
    tri = 8 if idx_size == 2 else 16
    quad_pad = 2 if idx_size == 2 else 4
    offs = []
    pos = 0
    for f in faces:
        offs.append(pos)
        pos += tri + (quad_pad if len(f) == 4 else 0)
    return offs


def face_sections(L, version):
    """section index for every face."""
    offs = face_byte_offsets(L.faces, 4 if version >= 69 else 2)
    out = [-1] * len(L.faces)
    for si, s in enumerate(L.sections):
        for fi, o in enumerate(offs):
            if s.face_lo <= o < s.face_hi:
                out[fi] = si
    return out


# ---------------------------------------------------------------- mass
def distribute_mass(points, total, com):
    """Per-point masses >= 0 summing to `total` whose centre of mass matches `com`
    as closely as possible, staying close to a uniform distribution."""
    n = len(points)
    if n == 0 or total <= 0:
        return [0.0] * n
    try:
        import numpy as np
    except ImportError:  # numpy is optional: fall back to an even split
        return [total / n] * n
    P = np.asarray(points, dtype=float)
    w = np.full(n, total / n)
    target = np.asarray(com, dtype=float) * total
    active = np.ones(n, bool)
    for _ in range(50):
        A = np.vstack([np.ones(n), P.T])[:, active]
        b = np.concatenate([[total], target]) - np.vstack([np.ones(n), P.T])[:, ~active] @ w[~active]
        u = np.full(active.sum(), total / n)
        try:
            corr = A.T @ np.linalg.lstsq(A @ A.T, b - A @ u, rcond=None)[0]
        except np.linalg.LinAlgError:
            break
        wa = u + corr
        if (wa >= 0).all():
            w[active] = wa
            break
        idx = np.where(active)[0]
        neg = idx[wa < 0]
        w[active] = np.maximum(wa, 0)
        w[neg] = 0
        active[neg] = False
        if not active.any():
            w = np.full(n, total / n)
            break
    w = np.maximum(w, 0)
    if w.sum() > 0:
        w *= total / w.sum()
    return [float(x) for x in w]


# ---------------------------------------------------------------- per LOD
def convert_lod(o, li, bones, report):
    L = o.lods[li]
    v = o.version
    nv = len(L.vertices)
    verts = L.vertices
    normals = lod_normals(L) if nv else []
    if len(normals) != nv:
        normals = [(0.0, 1.0, 0.0)] * nv
    uvs = [uvset_values(u) for u in L.uvsets]
    uvs = [u if len(u) == nv else [(0.0, 0.0)] * nv for u in uvs]
    clip = L.clip if len(L.clip) == nv else [0] * nv

    # --- per-vertex bone assignment (skinned LODs)
    vbones = [()] * nv
    if len(L.vertex_bone_ref) == nv:
        for i, ref in enumerate(L.vertex_bone_ref):
            cnt = ref[0]
            lst = []
            for k in range(min(cnt, 4)):
                b, w = ref[1 + 2 * k], ref[2 + 2 * k]
                if w == 0:
                    continue
                sk = L.subskel_to_skel[b] if b < len(L.subskel_to_skel) else -1
                if 0 <= sk < len(bones):
                    lst.append((bones[sk], w / 255.0))
            vbones[i] = tuple(sorted(lst))

    bone_set = set(bones)
    fsec = face_sections(L, v)

    # --- selection membership per ODOL vertex
    sel_vert_w = {}   # name -> {vertex: weight}
    sel_faces = {}    # name -> set(face)
    dropped = []
    for s in L.selections:
        if s.name.startswith('* '):  # binarize diagnostic selections
            dropped.append(s.name)
            continue
        faces = set(s.faces)
        if not faces and s.is_sectional and s.sections:
            secset = set(s.sections)
            faces = {fi for fi, si in enumerate(fsec) if si in secset}
        vw = {}
        if len(s.vertices):
            if len(s.weights) == len(s.vertices):
                for vi, b in zip(s.vertices, s.weights):
                    vw[vi] = b / 255.0
            else:
                for vi in s.vertices:
                    vw[vi] = 1.0
        else:
            for fi in faces:
                for vi in L.faces[fi]:
                    vw[vi] = 1.0
        sel_vert_w[s.name] = vw
        sel_faces[s.name] = faces
    if dropped:
        report.append('    dropped binarize-only selections: %s' % ', '.join(dropped))

    # skinning is the truth for bone selections in skinned LODs
    skinned = any(vbones)
    if skinned:
        bone_vw = defaultdict(dict)
        for i, bl in enumerate(vbones):
            for name, w in bl:
                bone_vw[name][i] = w
        for name in list(sel_vert_w):
            if name in bone_set:
                sel_vert_w[name] = bone_vw.get(name, {})
        for name, vw in bone_vw.items():
            if name not in sel_vert_w:
                sel_vert_w[name] = vw
                sel_faces[name] = set()

    # --- weld split render vertices back into MLOD points
    # key: exact position + point flags + bone binding (never weld across bones)
    vert_bone_key = [None] * nv
    if skinned:
        vert_bone_key = vbones
    else:
        bone_members = defaultdict(list)
        for name, vw in sel_vert_w.items():
            if name in bone_set:
                for vi, w in vw.items():
                    bone_members[vi].append((name, round(w, 3)))
        vert_bone_key = [tuple(sorted(bone_members.get(i, ()))) for i in range(nv)]
    point_of = [0] * nv
    key2pt = {}
    points = []
    for i in range(nv):
        x, y, z = verts[i]
        pf = clip_to_point_flags(clip[i])
        key = (x, y, z, pf, vert_bone_key[i])
        p = key2pt.get(key)
        if p is None:
            p = len(points)
            key2pt[key] = p
            points.append((x, y, z, pf))
        point_of[i] = p
    np_ = len(points)

    # --- normals (dedup)
    nkey = {}
    nlist = []
    nidx_of = [0] * nv
    for i in range(nv):
        n = normals[i]
        k = (round(n[0], 4), round(n[1], 4), round(n[2], 4))
        j = nkey.get(k)
        if j is None:
            j = len(nlist)
            nkey[k] = j
            nlist.append(n)
        nidx_of[i] = j

    # --- faces
    def sec_tex_mat(si):
        if si < 0:
            return '', ''
        s = L.sections[si]
        tex = L.textures[s.texture_index] if 0 <= s.texture_index < len(L.textures) else ''
        if s.material_index >= 0 and s.material_index < len(L.materials):
            mat = L.materials[s.material_index].name
        else:
            mat = s.material or ''
        return tex, mat

    faces = []
    face_map = {}  # odol face -> mlod face
    degenerate = 0
    extra_point_src = []  # (new point, odol vertex) for points split off degenerate faces
    for fi, f in enumerate(L.faces):
        order = list(reversed(f))  # ODOL winding is opposite to MLOD
        pts = [point_of[i] for i in order]
        fpts = list(pts)
        if len(set(pts)) < len(pts):
            # two corners at the same spot: the source had separate points there
            degenerate += 1
            seen = set()
            for k, i in enumerate(order):
                if fpts[k] in seen:
                    x, y, z, pf = points[fpts[k]]
                    fpts[k] = len(points)
                    points.append((x, y, z, pf))
                    extra_point_src.append((fpts[k], i))
                seen.add(fpts[k])
        tex, mat = sec_tex_mat(fsec[fi])
        fv = [(fpts[k], nidx_of[i], uvs[0][i][0] if uvs else 0.0, uvs[0][i][1] if uvs else 0.0)
              for k, i in enumerate(order)]
        face_map[fi] = len(faces)
        faces.append(NS(verts=fv, flags=0, texture=tex, material=mat, odol_verts=order))
    if degenerate:
        report.append('    %d faces had coincident corners; gave them separate points' % degenerate)
    nf = len(faces)
    np_ = len(points)

    # --- uv sets
    uvset_tags = {}
    for k, uv in enumerate(uvs):
        uvset_tags[k] = [[uv[i] for i in f.odol_verts] for f in faces]

    # --- selections
    selections = {}
    for name, vw in sel_vert_w.items():
        pw = bytearray(np_)
        pbest = {}
        for vi, w in vw.items():
            p = point_of[vi]
            if w > pbest.get(p, 0.0):
                pbest[p] = w
        for p_new, vi in extra_point_src:
            if vi in vw and vw[vi] > pbest.get(p_new, 0.0):
                pbest[p_new] = vw[vi]
        for p, w in pbest.items():
            pw[p] = weight_to_mlod_byte(w)
        fw = bytearray(nf)
        for fi in sel_faces.get(name, ()):
            m = face_map.get(fi)
            if m is not None:
                fw[m] = 1
        if not any(pw) and not any(fw):
            # keep empty selections too: model.cfg may reference them
            pass
        selections[name] = (pw, fw)

    # --- sharp edges: edge whose two faces don't share normals at its points
    sharp = []
    if nf and L.resolution < 1e13:
        edge_faces = defaultdict(list)
        for mi, f in enumerate(faces):
            vs = f.verts
            for k in range(len(vs)):
                a, b = vs[k], vs[(k + 1) % len(vs)]
                key = (a[0], b[0]) if a[0] < b[0] else (b[0], a[0])
                edge_faces[key].append((mi, {a[0]: a[1], b[0]: b[1]}))
        for (a, b), lst in edge_faces.items():
            if len(lst) < 2:
                continue
            n0 = lst[0][1]
            for _, n1 in lst[1:]:
                if not (_same_n(nlist, n0[a], n1[a]) and _same_n(nlist, n0[b], n1[b])):
                    sharp.append((a, b))
                    break

    out = NS(resolution=L.resolution, points=points, normals=nlist,
             faces=faces, selections=selections, properties=list(L.properties), mass=None,
             uvsets=uvset_tags if nf else {}, sharp_edges=sharp, frames=L.frames)
    report.append('  LOD %-22s %6d verts -> %6d points, %6d faces, %3d selections, %d sharp edges'
                  % (lod_name(L.resolution), nv, np_, nf, len(selections), len(sharp)))
    return out


def _same_n(nlist, i, j):
    if i == j:
        return True
    a, b = nlist[i], nlist[j]
    return a[0] * b[0] + a[1] * b[1] + a[2] * b[2] > 0.9995


# ---------------------------------------------------------------- whole model
def convert(o):
    report = []
    mi = o.model_info
    bones = [b[0] for b in mi.skeleton.bones]
    lods = []
    for li in range(len(o.lods)):
        lods.append(convert_lod(o, li, bones, report))

    # mass on the geometry LOD
    gi = mi.lod_index.get('geometry', 255)
    if gi < len(lods):
        G = lods[gi]
        n = len(G.points)
        if len(mi.mass_array) == len(o.lods[gi].vertices) and n:
            # stored per render vertex; take the value of the first vertex of each point
            L = o.lods[gi]
            pts = {}
            for i, vtx in enumerate(L.vertices):
                pts.setdefault(tuple(vtx), mi.mass_array[i])
            G.mass = [pts.get(tuple(p[:3]), 0.0) for p in G.points]
            report.append('  mass: restored per-point mass from ODOL (total %.3f)' % sum(G.mass))
        elif n and mi.mass > 0:
            G.mass = distribute_mass([p[:3] for p in G.points], mi.mass, mi.center_of_mass)
            report.append('  mass: per-point masses not stored in this ODOL; distributed total %.3f kg '
                          'over %d geometry points to reproduce the original centre of mass %s'
                          % (mi.mass, n, tuple(round(c, 4) for c in mi.center_of_mass)))
    return lods, report


# ======== mlod.py ========
"""MLOD (editable p3d, Object Builder format) reader and writer."""
import struct
from types import SimpleNamespace as NS


# ---------------------------------------------------------------- writing
def _asciiz(s):
    return s.encode('latin-1', 'replace') + b'\0'


def _tagg(name, payload):
    return b'\x01' + _asciiz(name) + struct.pack('<I', len(payload)) + payload


def build_lod(lod):
    """lod: NS(resolution, points[(x,y,z,flags)], normals[(x,y,z)],
    faces[NS(verts=[(pt, nrm, u, v)], flags, texture, material)],
    selections{name: (point_weight_bytes, face_bytes)}, properties[(k,v)],
    mass[float]|None, uvsets{idx: [[(u,v)...] per face]}, sharp_edges[(a,b)])"""
    np_, nn, nf = len(lod.points), len(lod.normals), len(lod.faces)
    out = [b'P3DM', struct.pack('<6I', 28, 0x100, np_, nn, nf, 0)]
    out.append(b''.join(struct.pack('<3fI', *p) for p in lod.points))
    out.append(b''.join(struct.pack('<3f', *n) for n in lod.normals))
    fbuf = []
    for f in lod.faces:
        vs = list(f.verts)
        b = [struct.pack('<I', len(vs))]
        for i in range(4):
            if i < len(vs):
                b.append(struct.pack('<IIff', *vs[i]))
            else:
                b.append(b'\0' * 16)
        b.append(struct.pack('<I', f.flags))
        b.append(_asciiz(f.texture))
        b.append(_asciiz(f.material))
        fbuf.append(b''.join(b))
    out.append(b''.join(fbuf))
    out.append(b'TAGG')
    if lod.sharp_edges:
        out.append(_tagg('#SharpEdges#', b''.join(struct.pack('<II', a, b) for a, b in lod.sharp_edges)))
    for k, v in lod.properties:
        out.append(_tagg('#Property#', k.encode('latin-1')[:63].ljust(64, b'\0') +
                         v.encode('latin-1')[:63].ljust(64, b'\0')))
    if lod.mass is not None:
        out.append(_tagg('#Mass#', struct.pack('<%df' % len(lod.mass), *lod.mass)))
    for idx in sorted(lod.uvsets):
        per_face = lod.uvsets[idx]
        payload = [struct.pack('<I', idx)]
        for uvs in per_face:
            payload.append(b''.join(struct.pack('<2f', u, v) for u, v in uvs))
        out.append(_tagg('#UVSet#', b''.join(payload)))
    for name, (pw, fw) in lod.selections.items():
        out.append(_tagg(name, bytes(pw) + bytes(fw)))
    for t, pts in lod.frames:
        out.append(_tagg('#Animation#', struct.pack('<f', t) + b''.join(struct.pack('<3f', *p) for p in pts)))
    out.append(_tagg('#EndOfFile#', b''))
    out.append(struct.pack('<f', lod.resolution))
    return b''.join(out)


def build_mlod(lods):
    return b'MLOD' + struct.pack('<II', 257, len(lods)) + b''.join(build_lod(l) for l in lods)


# ---------------------------------------------------------------- reading
def read_mlod(data):
    p = 0
    if data[:4] != b'MLOD':
        raise ValueError('not MLOD')
    ver, nl = struct.unpack_from('<II', data, 4)
    p = 12
    lods = []
    for _ in range(nl):
        if data[p:p + 4] != b'P3DM':
            raise ValueError('only P3DM LODs supported (got %r)' % data[p:p + 4])
        hs, v, np_, nn, nf, fl = struct.unpack_from('<6I', data, p + 4)
        p += 28
        L = NS()
        L.points = [struct.unpack_from('<3fI', data, p + 16 * i) for i in range(np_)]
        p += 16 * np_
        L.normals = [struct.unpack_from('<3f', data, p + 12 * i) for i in range(nn)]
        p += 12 * nn
        L.faces = []
        for _ in range(nf):
            n = struct.unpack_from('<I', data, p)[0]
            vs = [struct.unpack_from('<IIff', data, p + 4 + 16 * i) for i in range(4)]
            p += 68
            flags = struct.unpack_from('<I', data, p)[0]
            p += 4
            e = data.index(b'\0', p)
            tex = data[p:e].decode('latin-1')
            p = e + 1
            e = data.index(b'\0', p)
            mat = data[p:e].decode('latin-1')
            p = e + 1
            L.faces.append(NS(verts=vs[:n], flags=flags, texture=tex, material=mat))
        assert data[p:p + 4] == b'TAGG', data[p:p + 4]
        p += 4
        L.taggs = []
        while True:
            active = data[p]
            e = data.index(b'\0', p + 1)
            name = data[p + 1:e].decode('latin-1')
            size = struct.unpack_from('<I', data, e + 1)[0]
            payload = data[e + 5:e + 5 + size]
            p = e + 5 + size
            L.taggs.append((name, payload))
            if name == '#EndOfFile#':
                break
        L.resolution = struct.unpack_from('<f', data, p)[0]
        p += 4
        lods.append(L)
    if p != len(data):
        raise ValueError('trailing data: %d bytes' % (len(data) - p))
    return lods


# ======== modelcfg.py ========
"""Rebuild model.cfg (CfgSkeletons + CfgModels animations) from ODOL data."""
import math
import os


SRC_ADDR = {0: 'clamp', 1: 'loop', 2: 'mirror'}
TYPE_NAME = {0: 'rotation', 1: 'rotationX', 2: 'rotationY', 3: 'rotationZ',
             4: 'translation', 5: 'translationX', 6: 'translationY', 7: 'translationZ',
             8: 'direct', 9: 'hide'}


def _f(x):
    if abs(x) < 1e-7:
        x = 0.0
    s = '%.6f' % x
    s = s.rstrip('0').rstrip('.') if '.' in s else s
    return s if s not in ('-0', '') else '0'


def _sub(a, b):
    return (a[0] - b[0], a[1] - b[1], a[2] - b[2])


def _len(a):
    return math.sqrt(a[0] ** 2 + a[1] ** 2 + a[2] ** 2)


def _two_point_selections(mem):
    out = []
    for name, (pw, fw) in mem.selections.items():
        idx = [i for i, b in enumerate(pw) if b]
        if len(idx) == 2:
            out.append((name, mem.points[idx[0]][:3], mem.points[idx[1]][:3]))
    return out


def _match_axis(cands, pos, d, is_rotation, tol=2e-3):
    dl = _len(d)
    if dl < 1e-9:
        return None
    for name, p0, p1 in cands:
        for flipped, (a, b) in ((False, (p0, p1)), (True, (p1, p0))):
            ab = _sub(b, a)
            l = _len(ab)
            if l < 1e-9:
                continue
            if is_rotation:
                cos = sum(ab[i] * d[i] for i in range(3)) / (l * dl)
                if cos > 0.9995 and _len(_sub(a, pos)) < tol:
                    return name, flipped
            else:
                if _len(_sub(ab, d)) < tol:
                    return name, flipped
    # rotation axis may be stored at a different point on the same line
    if is_rotation:
        for name, p0, p1 in cands:
            ab = _sub(p1, p0)
            l = _len(ab)
            if l < 1e-9:
                continue
            cs = sum(ab[i] * d[i] for i in range(3)) / (l * dl)
            ap = _sub(pos, p0)
            # distance of pos from line p0-p1
            cr = (ap[1] * ab[2] - ap[2] * ab[1], ap[2] * ab[0] - ap[0] * ab[2], ap[0] * ab[1] - ap[1] * ab[0])
            if abs(cs) > 0.9995 and _len(cr) / l < tol:
                return name, cs < 0
    return None, False


def build_model_cfg(o, mlods, model_name):
    """Returns (text, notes). May append generated axis points to the memory LOD."""
    mi = o.model_info
    sk = mi.skeleton
    notes = []
    an = o.animations
    mem_i = mi.lod_index.get('memory', 255)
    mem = mlods[mem_i] if mem_i < len(mlods) else None
    cands = _two_point_selections(mem) if mem else []
    bones = [b[0] for b in sk.bones]

    skel_name = sk.name or (model_name + '_skeleton')
    L = []
    w = L.append
    w('// model.cfg reconstructed by dep3d from binarised %s.p3d' % model_name)
    w('// Axis memory points were matched by position; anything marked "dep3d_axis_*"')
    w('// was not found in the memory LOD and has been added to it by dep3d.')
    w('')
    w('class CfgSkeletons')
    w('{')
    w('\tclass %s' % skel_name)
    w('\t{')
    w('\t\tisDiscrete = %d;' % (1 if sk.discrete else 0))
    w('\t\tskeletonInherit = "";')
    w('\t\tskeletonBones[] =')
    w('\t\t{')
    for i, (b, p) in enumerate(sk.bones):
        w('\t\t\t"%s", "%s"%s' % (b, p, ',' if i < len(sk.bones) - 1 else ''))
    w('\t\t};')
    w('\t};')
    w('};')
    w('')

    # sections: selections the binariser kept as whole sections (hiddenSelections, damage, lights)
    sectional = []
    lod0 = o.lods[0] if o.lods else None
    if lod0:
        for s in lod0.selections:
            if s.is_sectional and s.name not in bones and not s.name.startswith('proxy:') \
                    and s.name not in sectional:
                sectional.append(s.name)

    w('class CfgModels')
    w('{')
    w('\tclass Default')
    w('\t{')
    w('\t\tsections[] = {};')
    w('\t\tsectionsInherit = "";')
    w('\t\tskeletonName = "";')
    w('\t};')
    w('\tclass %s : Default' % model_name)
    w('\t{')
    w('\t\tskeletonName = "%s";' % skel_name)
    if sectional:
        w('\t\t// selections stored as whole sections in the ODOL (hiddenSelections, damage zones, lights)')
        w('\t\tsections[] =')
        w('\t\t{')
        for i, s in enumerate(sectional):
            w('\t\t\t"%s"%s' % (s, ',' if i < len(sectional) - 1 else ''))
        w('\t\t};')
    w('\t\tclass Animations')
    w('\t\t{')
    added = 0
    matched = 0
    flips = 0
    if an:
        for k, c in enumerate(an.classes):
            bone, axis = -1, None
            for li in range(len(an.anims2bones)):
                b = an.anims2bones[li][k]
                if b != -1:
                    bone = b
                    axis = an.axis[li][k]
                    break
            sel = bones[bone] if 0 <= bone < len(bones) else ''
            w('\t\t\tclass %s' % _cls(c.name))
            w('\t\t\t{')
            w('\t\t\t\ttype = "%s";' % TYPE_NAME.get(c.type, 'rotation'))
            w('\t\t\t\tsource = "%s";' % c.source)
            w('\t\t\t\tselection = "%s";' % sel)
            if c.type <= 7 and axis is not None:
                pos, d = axis
                is_rot = c.type <= 3
                name, flipped = _match_axis(cands, pos, d, is_rot)
                if flipped:
                    # memory points are stored in the opposite order: invert the motion instead
                    flips += 1
                    if is_rot:
                        c.angle0, c.angle1 = -c.angle0, -c.angle1
                    else:
                        c.offset0, c.offset1 = -c.offset0, -c.offset1
                if name is not None:
                    matched += 1
                elif mem is not None:
                    name = 'dep3d_axis_%s' % _cls(c.name).lower()
                    if is_rot:
                        dl = _len(d) or 1.0
                        p1 = tuple(pos[i] + d[i] / dl * 0.1 for i in range(3))
                    else:
                        p1 = tuple(pos[i] + d[i] for i in range(3))
                    _add_axis(mem, name, pos, p1)
                    cands.append((name, tuple(pos), p1))
                    added += 1
                if name:
                    w('\t\t\t\taxis = "%s";' % name)
            w('\t\t\t\tmemory = 1;')
            w('\t\t\t\tsourceAddress = "%s";' % SRC_ADDR.get(c.source_address, 'clamp'))
            w('\t\t\t\tminValue = %s;' % _f(c.min_value))
            w('\t\t\t\tmaxValue = %s;' % _f(c.max_value))
            if abs(c.min_phase - c.min_value) > 1e-6 or abs(c.max_phase - c.max_value) > 1e-6:
                w('\t\t\t\tminPhase = %s;' % _f(c.min_phase))
                w('\t\t\t\tmaxPhase = %s;' % _f(c.max_phase))
            if c.type <= 3:
                w('\t\t\t\tangle0 = %s;\t// %s deg' % (_f(c.angle0), _f(math.degrees(c.angle0))))
                w('\t\t\t\tangle1 = %s;\t// %s deg' % (_f(c.angle1), _f(math.degrees(c.angle1))))
            elif c.type <= 7:
                w('\t\t\t\toffset0 = %s;' % _f(c.offset0))
                w('\t\t\t\toffset1 = %s;' % _f(c.offset1))
            elif c.type == 8:
                w('\t\t\t\taxisPos[] = {%s};' % ', '.join(_f(x) for x in c.axis_pos))
                w('\t\t\t\taxisDir[] = {%s};' % ', '.join(_f(x) for x in c.axis_dir))
                w('\t\t\t\tangle = %s;' % _f(c.angle))
                w('\t\t\t\taxisOffset = %s;' % _f(c.axis_offset))
            elif c.type == 9:
                w('\t\t\t\thideValue = %s;' % _f(c.hide_value))
                if hasattr(c, 'unhide_value'):
                    w('\t\t\t\tunHideValue = %s;' % _f(c.unhide_value))
            w('\t\t\t};')
    w('\t\t};')
    w('\t};')
    w('};')
    if an:
        notes.append('  model.cfg: %d bones, %d animations, %d axes matched to memory points '
                     '(%d with reversed point order, compensated), %d axes generated'
                     % (len(bones), len(an.classes), matched, flips, added))
    else:
        notes.append('  model.cfg: %d bones, no animations' % len(bones))
    return '\n'.join(L) + '\n', notes


def _cls(name):
    out = ''.join(ch if (ch.isalnum() or ch == '_') else '_' for ch in name)
    if not out or out[0].isdigit():
        out = '_' + out
    return out


def _add_axis(mem, name, p0, p1):
    n0 = len(mem.points)
    mem.points.append((p0[0], p0[1], p0[2], 0))
    mem.points.append((p1[0], p1[1], p1[2], 0))
    newsel = {}
    for k, (pw, fw) in mem.selections.items():
        newsel[k] = (bytes(pw) + b'\0\0', fw)
    pw = bytearray(len(mem.points))
    pw[n0] = pw[n0 + 1] = weight_to_mlod_byte(1.0)
    newsel[name] = (bytes(pw), bytearray(len(mem.faces)))
    mem.selections = newsel
    if mem.mass is not None:
        mem.mass += [0.0, 0.0]


# ======== cli.py ========
"""dep3d - convert binarised (ODOL) DayZ p3d models back into editable MLOD.

usage: dep3d.cmd <input.p3d | folder> [-o OUTDIR] [--no-cfg] [--suffix _mlod]
"""
import argparse
import os
import sys
import time



def convert_file(src, outdir, write_cfg=True, suffix=''):
    t0 = time.time()
    data = open(src, 'rb').read()
    o = read_odol(data)
    base = os.path.splitext(os.path.basename(src))[0]
    report = ['%s: ODOL v%d (%s layout), %d LODs' % (os.path.basename(src), o.version, o.flavor, len(o.lods))]
    for wmsg in o.warnings:
        if 'rest-of-data' in wmsg and o.flavor == 'DayZ':
            continue  # DayZ counts the size field itself; harmless
        report.append('  warning: ' + wmsg)
    mlods, rep = convert(o)
    report += rep
    cfg_text = None
    if write_cfg:
        cfg_text, notes = build_model_cfg(o, mlods, base)
        report += notes
    blob = build_mlod(mlods)
    read_mlod(blob)  # self-check: output must parse as MLOD
    os.makedirs(outdir, exist_ok=True)
    out_p3d = os.path.join(outdir, base + suffix + '.p3d')
    if os.path.abspath(out_p3d) == os.path.abspath(src):
        raise SystemExit('refusing to overwrite the input file; use -o or --suffix')
    with open(out_p3d, 'wb') as f:
        f.write(blob)
    if cfg_text:
        cfg_path = os.path.join(outdir, base + suffix + '_model.cfg')
        with open(cfg_path, 'w', newline='\r\n') as f:
            f.write(cfg_text)
    report.append('  -> %s (%.1f MB) in %.1fs' % (out_p3d, len(blob) / 1e6, time.time() - t0))
    return report


def main(argv=None):
    ap = argparse.ArgumentParser(prog='dep3d', description='Binarised p3d (ODOL) -> MLOD converter for DayZ')
    ap.add_argument('inputs', nargs='*', help='.p3d files or folders (searched recursively)')
    ap.add_argument('-o', '--out', default=None, help='output folder (default: same folder as the input p3d)')
    ap.add_argument('--no-cfg', action='store_true', help='do not write the reconstructed model.cfg')
    ap.add_argument('--suffix', default='_mlod', help='suffix added to output names (default _mlod)')
    a = ap.parse_args(argv)
    if not a.inputs:
        print('dep3d - drag binarised .p3d files or folders onto dep3d.cmd')
        print('(or run: dep3d.cmd file.p3d [--suffix _mlod] [--no-cfg] [-o outdir])')
        return

    files = []
    for p in a.inputs:
        if os.path.isdir(p):
            for root, _, names in os.walk(p):
                if 'dep3d_out' in root:
                    continue
                files += [os.path.join(root, n) for n in names if n.lower().endswith('.p3d')]
        else:
            files.append(p)
    ok = fail = skip = 0
    for src in files:
        outdir = a.out or os.path.dirname(os.path.abspath(src))
        if a.out and len(a.inputs) == 1 and os.path.isdir(a.inputs[0]):
            rel = os.path.relpath(os.path.dirname(os.path.abspath(src)), os.path.abspath(a.inputs[0]))
            outdir = os.path.normpath(os.path.join(a.out, rel))
        try:
            for line in convert_file(src, outdir, not a.no_cfg, a.suffix):
                print(line)
            ok += 1
        except ODOLError as e:
            msg = str(e)
            if 'already MLOD' in msg:
                skip += 1
                print('%s: skipped (%s)' % (src, msg))
            else:
                fail += 1
                print('%s: FAILED - %s' % (src, msg))
        except Exception as e:  # keep going on batch runs
            fail += 1
            print('%s: FAILED - %s: %s' % (src, type(e).__name__, e))
    if len(files) > 1:
        print('\n%d converted, %d skipped, %d failed' % (ok, skip, fail))
    sys.exit(1 if fail else 0)





if __name__ == '__main__':
    main()
