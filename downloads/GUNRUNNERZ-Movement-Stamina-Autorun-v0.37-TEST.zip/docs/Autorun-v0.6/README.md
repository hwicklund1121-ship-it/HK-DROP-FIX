# GUNRUNNERZ AUTORUN v0.6 — shared input-state test

Press the rebindable GUNRUNNERZ AUTORUN key once to start normal full sprint. Any fresh keyboard key press afterward stops it, including the same key. Held-key repetition is ignored. There is no speed setting, speed key, notification, chat ping or continuous log output. Bind the existing action under Controls > Unsorted (runtime display verification required). Old speed JSON files are ignored.

## Correction from v0.5

v0.5 applied input overrides only locally. v0.6 applies matching fixed native speed/angle overrides on the owning player's server entity via a dedicated reliable state RPC. The server accepts only that entity's authenticated owner and a boolean start/stop state; no client-selected speed, angle, position or velocity is accepted. Speed is fixed at native 3.0 and forward angle at 0.0. No position or velocity is written and native sprint restrictions remain in place.

A one-second active heartbeat renews a 3.5-second server lease. Stop clears local owned input immediately and sends stop to the server. The server also clears its input on lease expiry, death/unconsciousness/restraint/raised state or leaving the move command. There are no call-queue timers, no per-frame RPCs, no changes to engine reconciliation and no promise of general desync repair. RPC traffic/delivery and input behavior must be checked in DayZ. Packets in flight may delay the remote stop until delivery or lease expiry.

This corrects a concrete omission, not a verified root-cause diagnosis of every run-in-place symptom. API declarations and the public Carim/Schana autorun architecture were inspected as references; the original third-party addon is not bundled. Attribution and license notices are in the ZIP.

## Existing behavior

Manual movement also cancels as a fallback. Menus/disabled controls, raised hands/weapon, death, unconsciousness, restraint or leaving the normal movement command stop autorun. Mission initialization/reconnect starts OFF. A native HUD visibility guard suppresses stamina-bar dimming while active without changing its amount or forcing the parent HUD visible. Custom HUD behavior is unverified.

This addon does not change stamina costs. Keep the existing GRZ_ActionStamina addon for empty-hands punch/breath-only drain. Existing movement/FOV/LUGU files are not part of this download and are not changed.

## Install and rollback

Stop client AND server. Back up the old GRZ_Autorun PBO/signature outside all loaded addon directories. Replace it with this exact build on BOTH sides, distributed via shared -mod; do not load duplicate versions or another autorun addon. Installing only on the client cannot supply the new server RPC handler. Use the owner's normal signing/public-key distribution workflow where required; do not disable verification.

Release manual movement keys, start autorun, and verify forward sprint rather than running in place. Stop with an unbound keyboard key, modifier, the autorun key and movement keys. Test menus, aim, jump/vehicle transitions, death/respawn and reconnect. Check that cancellation cannot restart in the same frame, that server movement stops after loss of heartbeat, and that stamina/punch/breath and HUD behavior are preserved. Do this on the test deployment first.

Rollback: stop both, restore the previous PBO/signature or remove this addon from both shared launch lists, restart. No persistence wipe is required.

Local validation covers PBO checksum, compressed payload/source round-trip, ZIP CRC, XML/localization consistency, source rebuild and client/SERVER preprocessing of the shared protocol. Enforce compilation, live server authority/ownership checks, heartbeat timing, sprinting and animation behavior remain unverified without DayZ.
