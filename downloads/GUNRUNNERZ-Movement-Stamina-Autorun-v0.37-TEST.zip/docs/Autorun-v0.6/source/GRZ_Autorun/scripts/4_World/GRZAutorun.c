#ifndef SERVER
class GRZAutorunState
{
    static bool Active;

    static bool Pressed(string name)
    {
        UAInput input = GetUApi().GetInputByName(name);
        return input && input.LocalPress();
    }

    static bool Held(string name)
    {
        UAInput input = GetUApi().GetInputByName(name);
        return input && input.LocalValue() > 0.1;
    }

    static bool CanRun(PlayerBase player)
    {
        if (!player || !player.IsAlive() || player.IsUnconscious() || player.IsRestrained() || player.IsRaised())
            return false;
        if (!GetGame().GetMission() || GetGame().GetMission().IsControlDisabled() || GetGame().GetUIManager().GetMenu())
            return false;
        return player.GetCurrentCommandID() == DayZPlayerConstants.COMMANDID_MOVE;
    }

    private static PlayerBase s_InputOwner;
    private static int s_LastSync;

    private static void SendState(PlayerBase player, bool running)
    {
        if (GetGame().IsMultiplayer() && !GetGame().IsServer())
            GetGame().RPCSingleParam(player, GRZAutorunProtocol.RPC_STATE, new Param1<bool>(running), true);
    }

    static void Stop()
    {
        Active = false;
        if (s_InputOwner)
        {
            SendState(s_InputOwner, false);
            HumanInputController controls = s_InputOwner.GetInputController();
            if (controls)
            {
                controls.OverrideMovementSpeed(HumanInputControllerOverrideType.DISABLED, 0.0);
                controls.OverrideMovementAngle(HumanInputControllerOverrideType.DISABLED, 0.0);
            }
        }
        s_InputOwner = null;
        s_LastSync = 0;
    }

    static void Apply(PlayerBase player)
    {
        if (!Active) return;
        if (s_InputOwner && s_InputOwner != player)
        {
            Stop();
            return;
        }
        if (!CanRun(player) || Held("UAMoveForward") || Held("UAMoveBack") || Held("UAMoveLeft") || Held("UAMoveRight"))
        {
            Stop();
            return;
        }
        HumanInputController controls = player.GetInputController();
        if (!controls)
        {
            Stop();
            return;
        }
        bool starting = !s_InputOwner;
        s_InputOwner = player;
        // Keep native forward/sprint input active between mission updates.
        // Explicitly release only these owned overrides on every stop path.
        controls.OverrideMovementSpeed(HumanInputControllerOverrideType.ENABLED, 3.0);
        controls.OverrideMovementAngle(HumanInputControllerOverrideType.ENABLED, 0.0);
        int now = GetGame().GetTime();
        if (starting || now - s_LastSync >= GRZAutorunProtocol.HEARTBEAT_MS)
        {
            SendState(player, true);
            s_LastSync = now;
        }
    }
}
#endif
