# GRZ release contents and rights notes

The standalone GRZ package contains GRZ integration scripts, camera-policy scripts, configuration, and these documents. Version 0.33 explicitly adopts the numerical movement preset from the supplied OPM_Scripts PBO. **Original movement credit: Ronjam**, as identified by the server owner. The supplied OPM configuration separately attributes itself to **Operation Monarch / Echo**; both attributions are retained. The original OPM PBO and its broader player/item/weapon callback implementations are not bundled. This attribution is not a claim that every GRZ feature was written by Ronjam or that the supplied OPM fork's complete authorship has been independently verified.

No LUGU, StormZz or LWP PBOs, animation graphs, clips, artwork or obfuscated resources are included in this candidate. It depends on an installed, licensed copy of DayZ and uses DayZ scripting interfaces. The OPM input was inspected read-only; no LUGU resource was modified, repacked or redistributed.

Development used the supplied movement settings as a behavior reference, inspected supplied mods, and consulted DayZ script interfaces. This is not a claim of an independent clean-room process. Similar behavior or numerical tuning alone does not establish infringement, but this document is not legal clearance or a guarantee against claims.

The LUGU addon remains a separate optional installation. Permission to use it does not necessarily include permission to redistribute it. Obtain permission before bundling any third-party addon or using another creator's artwork or branding. No trademark search for GRZ Movement has been performed. DayZ and third-party platform license terms still apply.

Distribute the standalone GRZ ZIP, not an archive of the historical HK-DROP-FIX repository: that repository contains third-party inputs and earlier experimental packages which are outside this GRZ release.

Version 0.20 camera settings use a newly written normalized-coordinate layout with native DayZ widgets/font references and newly written preference/menu code. GunRunnerZ supplied the visual feature reference only; its code, layout and artwork are not included. The user later requested the text label GunRunnerZ FOV; that label is included in version 0.21. No trademark clearance is claimed.

Version 0.37 adds GRZ session-only FOV preview state and settings-menu commit/discard integration. All World scripts, movement tuning and animation/resource content remain byte-identical to v0.36. No LUGU animation data is included.
