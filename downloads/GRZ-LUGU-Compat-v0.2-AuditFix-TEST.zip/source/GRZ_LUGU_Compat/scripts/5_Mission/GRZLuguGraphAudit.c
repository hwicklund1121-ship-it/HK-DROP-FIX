class GRZLuguGraphAudit
{
    static string NormalizePath(string path)
    {
        path.Replace("\\", "/");
        while (path.IndexOf("//") != -1)
            path.Replace("//", "/");
        path.ToLower();
        return path;
    }

    static void Record(string playerType)
    {
        string actual;
        string expected = "LUGUINSTADROPFIX/IO2JF/GJDH4KD/FGHJDGH/I3FJ4/GJKL2H/GJKDF9G/JFLK21KGH/KLJSDF8F23/GHJKDSDSHIG.agr";
        string side = "CLIENT";
        if (GetGame().IsServer()) side = "SERVER";
        GetGame().ConfigGetText("CfgVehicles " + playerType + " enfAnimSys graphName", actual);
        string status = "MISMATCH";
        if (NormalizePath(actual) == NormalizePath(expected)) status = "MATCH";
        Print("[GRZLUGU] side=" + side + " type=" + playerType + " graph=" + actual + " expected_graph=" + status);
    }
}
#ifdef SERVER
modded class MissionServer
{
    override void OnInit()
    {
        super.OnInit();
        GRZLuguGraphAudit.Record("SurvivorBase");
    }
}
#else
modded class MissionGameplay
{
    protected bool m_GRZLuguPlayerChecked;
    override void OnInit()
    {
        super.OnInit();
        m_GRZLuguPlayerChecked = false;
        GRZLuguGraphAudit.Record("SurvivorBase");
    }
    override void OnUpdate(float timeslice)
    {
        super.OnUpdate(timeslice);
        if (m_GRZLuguPlayerChecked) return;
        PlayerBase player = PlayerBase.Cast(GetGame().GetPlayer());
        if (!player) return;
        m_GRZLuguPlayerChecked = true;
        GRZLuguGraphAudit.Record(player.GetType());
    }
}
#endif
