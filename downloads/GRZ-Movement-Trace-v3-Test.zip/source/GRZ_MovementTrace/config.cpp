class CfgPatches
{
    class GRZ_MovementTrace
    {
        units[] = {};
        weapons[] = {};
        requiredVersion = 0.1;
        requiredAddons[] = {"DZ_Scripts", "GRZ_Movement"};
    };
};
class CfgMods
{
    class GRZ_MovementTrace
    {
        dir = "GRZ_MovementTrace";
        name = "GRZ Movement Trace";
        type = "mod";
        dependencies[] = {"World", "Mission"};
        class defs
        {
            class missionScriptModule
            {
                value = "";
                files[] = {"GRZ_MovementTrace/scripts/5_Mission"};
            };
            class worldScriptModule
            {
                value = "";
                files[] = {"GRZ_MovementTrace/scripts/4_World"};
            };
        };
    };
};
