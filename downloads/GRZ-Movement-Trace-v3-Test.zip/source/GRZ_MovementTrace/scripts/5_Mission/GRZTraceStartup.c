#ifndef SERVER
modded class MissionGameplay
{
    override void OnMissionStart()
    {
        super.OnMissionStart();
        if (GetGame().IsClient())
        {
            GRZMovementTraceLog.Write("[GRZMOVE] CLIENT trace addon v3 loaded. No client JSON required. Session marker; times below are local process times.");
            Print("[GRZMOVE] Client trace v3 loaded; output: $profile:GRZMovementTrace-client.log");
        }
    }
}
#endif
