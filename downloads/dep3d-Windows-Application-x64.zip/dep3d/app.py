import os
import runpy
import sys

def launch():
    interactive = len(sys.argv) == 1
    args = sys.argv[1:]
    if interactive:
        print("dep3d - P3D debinarizer")
        print("Enter a P3D file or folder path. Outputs are saved beside the originals.")
        path = input("File or folder: ").strip().strip('"')
        if not path:
            return 0
        args = [path]
    code = 0
    try:
        converter = runpy.run_path(os.path.join(os.path.dirname(__file__), "dep3d.py"))
        converter["main"](args)
    except SystemExit as error:
        code = error.code if isinstance(error.code, int) else 1
    except Exception as error:
        print("ERROR:", error, file=sys.stderr)
        code = 1
    finally:
        if interactive:
            input("Press Enter to close...")
    return code

if __name__ == "__main__":
    sys.exit(launch())
