dep3d - Ready-built Windows 64-bit console application

1. Extract the ENTIRE ZIP to a folder on your PC. Do not run it inside the ZIP.
2. Open dep3d.exe. Enter the P3D path when prompted.

No Python installation, pip or build step is needed. Keep dep3d.exe, app.py, dep3d.py and the runtime folder together. This is a portable application folder, not a single self-contained EXE.

CMD usage:
  dep3d.exe "C:\Models\BC_A2CHEY.p3d"
  dep3d.exe "C:\Models" -o "C:\Converted"
  dep3d.exe --help

A double-click opens a console prompt, not a graphical editor. Drag-and-drop files onto the EXE also passes their paths; run from CMD if you need the output to remain visible.

Outputs use _mlod filenames. Matching existing outputs are overwritten, so keep backups. Model.cfg reconstruction is approximate. Original input overwrite is refused.

Includes official Python 3.12.10 x64 runtime from the Python NuGet package and an x64 Windows PE launcher cross-compiled from the included C source with Zig 0.13.0. Python license is runtime\LICENSE.txt. Runtime is bundled unchanged from that package.

Converter successfully processed the supplied ODOL v56 model with 10 LODs and parsed the generated MLOD. Windows executable architecture/header checks passed; actual Windows execution has not been verified in this Linux environment. Requires 64-bit Windows with Python 3.12 runtime platform requirements. The application is unsigned.
