COMPILE FIX: Split the diagnostic log expression into small statements to address Enforce "Formula too complex" at former line 118. No logging fields, target selection or file paths changed. Runtime compilation still requires verification in DayZ.

YOUR SERVER PATHS
Config: C:\Program Files (x86)\CFTools Software GmbH\Architect\Agent\deployments\GunRunnerZTest2\profiles\GRZMovementTrace.json
Log: C:\Program Files (x86)\CFTools Software GmbH\Architect\Agent\deployments\GunRunnerZTest2\profiles\GRZMovementTrace-server.log
The addon uses DayZ $profile: for both. Confirm the server startup -profiles option selects the directory above. No hard-coded machine path is used by the client.

GRZ movement diagnostic addon - NOT a replacement GRZ build

Keeps your installed GRZ movement/camera settings unchanged. Adds read-only sampled movement diagnostics. No movement, animation or camera writes and no extra network RPCs. The inherited command handler always runs first. Logging/file I/O adds overhead; use for a short controlled test.

INSTALL
1. Keep your existing GRZ_Movement addon. Load @GRZ_MovementTrace AFTER that mod on BOTH test server and your client. Do not use -serverMod alone; client data is essential. This addon is unsigned; use your usual signing process if signatures are enforced.
2. Copy configuration/GRZMovementTrace.json to the SERVER profiles directory selected by -profiles. Edit TargetPlayerName to your exact in-game name, keeping Enabled true. Only that player's server data is recorded. No account IDs are logged.
3. Copy the same JSON to your CLIENT DayZ profile directory (normally Documents\DayZ, or your custom -profiles folder). Client logs only the locally controlled player; it never traces remote players.
4. Restart server and client after configuration changes. Join and reproduce promptly. Recording stops after 1200 samples per player instance, approximately two minutes at 10 samples/sec, potentially longer at lower simulation rates.

LOG FILES
Server: <server -profiles folder>\GRZMovementTrace-server.log
Client: <client profile folder>\GRZMovementTrace-client.log
They append and close the file after every sample. Move old logs aside before starting a fresh session. If no file appears, verify config, player name and addon loading; an open-file error is printed once to the script log.

REPRODUCTION
Record a clip: stand still 3 seconds, move backward until the forward jolt happens, stand still 3 seconds, repeat, then move normally forward for comparison. Record rough clip times. Send BOTH log files and the matching clip.

INTERPRETATION
Fields: local process t_ms, sample interval, network object ID, world position/displacement, engine-reported velocity, orientation, command, stance/movement indices and movement input if available. Server input is not necessarily raw physical keyboard input. Engine velocity may differ from rendered character motion. Client/server clocks and sample numbers are NOT synchronized; match trajectories/actions and network IDs rather than comparing identical timestamps. A large displacement alone does not prove a correction. This trace does not directly measure final rendered camera transforms or animation bones.

REMOVE
Remove the diagnostic addon from both launch lists and restart to stop logging. The JSON/logs can be archived or deleted separately. No automatic changes to your main GRZ PBO.

VALIDATION
PBO checksum/source round-trip, client/SERVER preprocessing, logger paths, read-only API scan and ZIP integrity passed. Native API signatures checked against the available DayZ script reference. No DayZ 1.30 Enforce compilation/runtime execution was possible here; check script errors first and remove the addon if it fails to compile.
