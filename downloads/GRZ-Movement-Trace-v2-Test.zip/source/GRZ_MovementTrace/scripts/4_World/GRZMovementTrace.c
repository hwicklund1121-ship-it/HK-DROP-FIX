// Temporary read-only diagnostic addon. Does not change movement or camera state.
class GRZMovementTraceConfig
{
    bool Enabled = false;
    string TargetPlayerName = "";
    private static ref GRZMovementTraceConfig s_Config;

    static GRZMovementTraceConfig Get()
    {
        if (!s_Config)
        {
            s_Config = new GRZMovementTraceConfig();
            string path = "$profile:GRZMovementTrace.json";
            if (FileExist(path))
            {
                GRZMovementTraceConfig loaded = new GRZMovementTraceConfig();
                string error;
                if (JsonFileLoader<GRZMovementTraceConfig>.LoadFile(path, loaded, error) && loaded)
                    s_Config = loaded;
                else
                    Print("[GRZMOVE] Configuration could not be loaded; trace disabled. " + error);
            }
        }
        return s_Config;
    }
}

// Both files resolve through the actual -profiles directory of each process.
class GRZMovementTraceLog
{
    private static bool s_WriteErrorReported;

    static void Write(string text)
    {
        string path = "$profile:GRZMovementTrace-client.log";
        if (GetGame().IsServer())
            path = "$profile:GRZMovementTrace-server.log";
        FileHandle file = OpenFile(path, FileMode.APPEND);
        if (!file)
        {
            if (!s_WriteErrorReported)
            {
                Print("[GRZMOVE] Cannot open diagnostic file: " + path);
                s_WriteErrorReported = true;
            }
            return;
        }
        FPrintln(file, text);
        CloseFile(file);
    }
}

modded class PlayerBase
{
    private float m_GRZTraceElapsed;
    private int m_GRZTraceCount;
    private int m_GRZTraceLastTime;
    private vector m_GRZTraceLastPosition;

    override void CommandHandler(float pDt, int pCurrentCommandID, bool pCurrentCommandFinished)
    {
        super.CommandHandler(pDt, pCurrentCommandID, pCurrentCommandFinished);
        GRZRecordMovement(pDt);
    }

    private void GRZRecordMovement(float deltaTime)
    {
        if (!GetGame() || !IsAlive() || m_GRZTraceCount >= 1200)
            return;
        GRZMovementTraceConfig settings = GRZMovementTraceConfig.Get();
        if (!settings.Enabled || settings.TargetPlayerName == "")
            return;

        bool server = GetGame().IsServer();
        if (server)
        {
            PlayerIdentity identity = GetIdentity();
            if (!identity || identity.GetName() != settings.TargetPlayerName)
                return;
        }
        else if (!IsControlledPlayer())
        {
            return;
        }

        m_GRZTraceElapsed += deltaTime;
        if (m_GRZTraceElapsed < 0.1)
            return;
        m_GRZTraceElapsed = 0;

        int now = GetGame().GetTime();
        vector position = GetPosition();
        vector displacement = "0 0 0";
        int interval = 0;
        if (m_GRZTraceCount > 0)
        {
            displacement = position - m_GRZTraceLastPosition;
            interval = now - m_GRZTraceLastTime;
        }
        vector engineVelocity = GetVelocity(this);
        HumanMovementState state = new HumanMovementState();
        GetMovementState(state);
        int netLow, netHigh;
        GetNetworkID(netLow, netHigh);

        string side = "CLIENT";
        if (server)
            side = "SERVER";
        string inputData = " input=unavailable";
        HumanInputController controls = GetInputController();
        if (controls)
        {
            float requestedSpeed;
            vector requestedDirection;
            controls.GetMovement(requestedSpeed, requestedDirection);
            inputData = " input_speed=" + requestedSpeed.ToString() + " input_direction=" + requestedDirection.ToString();
        }
        vector orientation = GetOrientation();
        int command = GetCurrentCommandID();
        string record = "[GRZMOVE] side=" + side;
        record = record + " net=" + netLow.ToString();
        record = record + ":" + netHigh.ToString();
        record = record + " seq=" + m_GRZTraceCount.ToString();
        record = record + " t_ms=" + now.ToString();
        record = record + " dt_ms=" + interval.ToString();
        record = record + " pos=" + position.ToString();
        record = record + " delta=" + displacement.ToString();
        record = record + " engine_velocity=" + engineVelocity.ToString();
        record = record + " orientation=" + orientation.ToString();
        record = record + " command=" + command.ToString();
        record = record + " stance=" + state.m_iStanceIdx.ToString();
        record = record + " movement=" + state.m_iMovement.ToString();
        record = record + inputData;
        GRZMovementTraceLog.Write(record);
        m_GRZTraceLastPosition = position;
        m_GRZTraceLastTime = now;
        m_GRZTraceCount++;
        if (m_GRZTraceCount == 1200)
            GRZMovementTraceLog.Write("[GRZMOVE] " + side + " trace limit reached; recording stopped for this player instance.");
    }
}
