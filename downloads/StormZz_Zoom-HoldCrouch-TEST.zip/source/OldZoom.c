/*
Custom Made Script Made By StormZz. Any Attempts at stealing this will result in a DMCA.
For Repack Purposes Contact Myself On Discord StormZz#7514
*/
modded class DayZPlayerImplement
{
	private bool m_HKZoomHeld;
	private bool m_HKZoomHoldRaised;
	private bool m_HKZoomHoldReported;

	override int CameraHandler(int pCameraMode)
	{
		super.CameraHandler(pCameraMode)
		//! ironsights
		if (!m_LiftWeapon_player)
		{
			ItemOptics optics = null;
			EntityAI entityInHands = GetHumanInventory().GetEntityInHands();
			Weapon weapon = Weapon.Cast(entityInHands);
			if (weapon)
				optics = weapon.GetAttachedOptics();
			else if (entityInHands)
				Class.CastTo(optics,entityInHands);
			
			if (m_CameraOptics && optics)
			{
				return DayZPlayerCameras.DAYZCAMERA_OPTICS;
			}
			else if (m_CameraIronsight && weapon)
			{
				return DayZPlayerCameras.DAYZCAMERA_IRONSIGHTS;
			}
		}
		
		//uncon
		if (m_IsUnconscious)
		{
			return DayZPlayerCameras.DAYZCAMERA_1ST_UNCONSCIOUS;
		}
		
		HumanCommandVehicle vehicleCommand = GetCommand_Vehicle();
		
		if (!m_Camera3rdPerson)
		{
			if (vehicleCommand)
			{
				return DayZPlayerCameras.DAYZCAMERA_1ST_VEHICLE;
			}
			
			return DayZPlayerCameras.DAYZCAMERA_1ST;
		}
		else
		{
			if (vehicleCommand)
			{
				Transport transport = vehicleCommand.GetTransport();
				if (transport && GetParent())
				{
					return transport.Get3rdPersonCameraType();
				}
			}
			
			//! get movement state 
			GetMovementState(m_MovementState);
			
			//! VKOSTIK: v ostatnich commandech mimo COMMANDID_MOVE je 
			//! m_MovementState.m_iStanceIdx - DayZPlayerConstants.STANCEIDX_ERECT
			//! m_MovementState.m_iMovement = 0 (idle)

			//! COMMANDID_ACTION returns stance right - ERECT/CROUCH

			//! melee camera - not melee - stays in stance camera

			if (m_MovementState.m_CommandTypeId == DayZPlayerConstants.COMMANDID_CLIMB)
			{
				return DayZPlayerCameras.DAYZCAMERA_3RD_CLIMB;
			}

			if (m_JumpClimb.m_bIsJumpInProgress)
			{
				return DayZPlayerCameras.DAYZCAMERA_3RD_JUMP;
			}
			
			//		
			// normal movement cameras			
            // Preserve this mod's original raised-camera framing during a zoom hold.
            HumanInputController hkInput = GetInputController();
            bool hkZoom = hkInput && (hkInput.IsZoom() || hkInput.IsZoomToggle());
            if (!hkZoom)
            {
                m_HKZoomHeld = false;
                m_HKZoomHoldRaised = false;
                m_HKZoomHoldReported = false;
            }
            else if (!m_HKZoomHeld)
            {
                m_HKZoomHeld = true;
                m_HKZoomHoldRaised = hkInput.IsWeaponRaised() || m_MovementState.IsRaised();
                Print("[HKZOOMHOLD] captured_raised=" + m_HKZoomHoldRaised.ToString());
            }
            if (hkZoom && m_HKZoomHoldRaised && GetCurrentCommandID() == DayZPlayerConstants.COMMANDID_MOVE)
            {
                int hkStance = m_MovementState.m_iStanceIdx;
                if (hkStance == DayZPlayerConstants.STANCEIDX_CROUCH || hkStance == DayZPlayerConstants.STANCEIDX_RAISEDCROUCH)
                {
                    if (!m_HKZoomHoldReported && hkStance == DayZPlayerConstants.STANCEIDX_CROUCH)
                    {
                        Print("[HKZOOMHOLD] preserving_crouch_camera=1");
                        m_HKZoomHoldReported = true;
                    }
                    return DayZPlayerCameras.DAYZCAMERA_3RD_CRO_RAISED;
                }
                if (hkStance == DayZPlayerConstants.STANCEIDX_ERECT || hkStance == DayZPlayerConstants.STANCEIDX_RAISEDERECT)
                {
                    if (m_IsWeapon)
                        return DayZPlayerCameras.DAYZCAMERA_3RD_ERC_RAISED;
                    return DayZPlayerCameras.DAYZCAMERA_3RD_ERC_RAISED_MELEE;
                }
            }

			if (m_MovementState.m_iStanceIdx == DayZPlayerConstants.STANCEIDX_CROUCH)
			{
				return DayZPlayerCameras.DAYZCAMERA_3RD_CRO;
			}
			else if (m_MovementState.m_iStanceIdx == DayZPlayerConstants.STANCEIDX_RAISEDCROUCH)
			{
				return DayZPlayerCameras.DAYZCAMERA_3RD_CRO_RAISED;
			}
			else if (m_MovementState.m_iStanceIdx == DayZPlayerConstants.STANCEIDX_PRONE)
			{
				return DayZPlayerCameras.DAYZCAMERA_3RD_PRO;
			}
			else if (m_MovementState.m_iStanceIdx == DayZPlayerConstants.STANCEIDX_RAISEDPRONE)
			{
				return DayZPlayerCameras.DAYZCAMERA_3RD_PRO_RAISED;
			}

			if (m_MovementState.m_iStanceIdx == DayZPlayerConstants.STANCEIDX_RAISEDERECT)
			{
				if (m_IsWeapon) 
				{
					return DayZPlayerCameras.DAYZCAMERA_3RD_ERC_RAISED;
				}
				else
				{
					return DayZPlayerCameras.DAYZCAMERA_3RD_ERC_RAISED_MELEE;
				}
			}
			else if (m_MovementState.m_iMovement == DayZPlayerConstants.MOVEMENTIDX_SPRINT)
			{
				return DayZPlayerCameras.DAYZCAMERA_3RD_ERC_SPR;
			}

			// DayZPlayerConstants.STANCEIDX_ERECT
			return DayZPlayerCameras.DAYZCAMERA_3RD_ERC;
		}
		
		return DayZPlayerCameras.DAYZCAMERA_1ST;
	}
}
