// Camera-only quick-scope candidate. No ADS/readiness/weapon-state overrides.
#ifndef SERVER
class GRZQuickScopePolicy
{
    static const float IRONSIGHT_BLEND_SECONDS = 0.14;

    static bool IsSightCamera(int camera)
    {
        return camera == DayZPlayerCameras.DAYZCAMERA_IRONSIGHTS || camera == DayZPlayerCameras.DAYZCAMERA_OPTICS;
    }

    static bool IsSupportedSource(DayZPlayerCamera camera)
    {
        if (!camera)
            return false;
        string name = camera.ClassName();
        return name == "DayZPlayerCamera1stPerson" || name == "DayZPlayerCamera3rdPersonErc" || name == "DayZPlayerCamera3rdPersonCrouch" || name == "DayZPlayerCamera3rdPersonProne" || name == "DayZPlayerCamera3rdPersonErcRaised" || name == "DayZPlayerCamera3rdPersonCrouchRaised" || name == "DayZPlayerCamera3rdPersonProneRaised" || name == "DayZPlayerCameraIronsights" || name == "DayZPlayerCameraOptics";
    }

    static bool IsOnFootCamera(int camera)
    {
        return IsSightCamera(camera) || camera == DayZPlayerCameras.DAYZCAMERA_1ST || camera == DayZPlayerCameras.DAYZCAMERA_3RD_ERC || camera == DayZPlayerCameras.DAYZCAMERA_3RD_CRO || camera == DayZPlayerCameras.DAYZCAMERA_3RD_PRO || camera == DayZPlayerCameras.DAYZCAMERA_3RD_ERC_RAISED || camera == DayZPlayerCameras.DAYZCAMERA_3RD_CRO_RAISED || camera == DayZPlayerCameras.DAYZCAMERA_3RD_PRO_RAISED;
    }
}

modded class DayZPlayerCameras
{
    override static float GetTransitionTime(int pFrom, int pTo)
    {
        float originalTime = super.GetTransitionTime(pFrom, pTo);
        if (!GetGame())
            return originalTime;
        PlayerBase player = PlayerBase.Cast(GetGame().GetPlayer());
        if (!player || !player.IsAlive() || !Weapon_Base.Cast(player.GetItemInHands()))
            return originalTime;
        if (!GRZQuickScopePolicy.IsOnFootCamera(pFrom) || !GRZQuickScopePolicy.IsOnFootCamera(pTo))
            return originalTime;
        if (pFrom == DAYZCAMERA_OPTICS || pTo == DAYZCAMERA_OPTICS)
            return 0.0;
        if (pFrom == DAYZCAMERA_IRONSIGHTS || pTo == DAYZCAMERA_IRONSIGHTS)
            return Math.Min(originalTime, GRZQuickScopePolicy.IRONSIGHT_BLEND_SECONDS);
        return originalTime;
    }
}

modded class DayZPlayerCameraOptics
{
    private float m_GRZScopeEntryElapsed = -1;
    private float m_GRZScopeEntryFov;
    private bool m_GRZScopeBuildLogged;

    override void OnActivate(DayZPlayerCamera pPrevCamera, DayZPlayerCameraResult pPrevCameraResult)
    {
        super.OnActivate(pPrevCamera, pPrevCameraResult);
        m_GRZScopeEntryElapsed = -1;
        if (!m_weaponUsed || !m_opticsUsed || !GetGame() || GetGame().GetPlayer() != m_pPlayer)
            return;
        if (!GRZQuickScopePolicy.IsSupportedSource(pPrevCamera))
            return;

        // Apply native scope effects and visibility now rather than waiting
        // for the next GUI call-queue tick. Native exit handles restoration.
        SetCameraPP(true, this);
        PlayerBase player = PlayerBase.Cast(m_pPlayer);
        if (player)
            player.HideClothing(m_opticsUsed, true);

        if (!m_opticsUsed.AllowsDOF() && pPrevCameraResult && pPrevCameraResult.m_fFovAbsolute > 0)
        {
            m_GRZScopeEntryFov = pPrevCameraResult.m_fFovAbsolute;
            m_GRZScopeEntryElapsed = 0;
        }
        if (!m_GRZScopeBuildLogged)
        {
            Print("[GRZQuickScope v0.2] Slower FOV entry; immediate native scope visibility. Runtime result requires verification.");
            m_GRZScopeBuildLogged = true;
        }
    }

    override float HoldBreathFOVEffect(float pDt)
    {
        float nativeFov = super.HoldBreathFOVEffect(pDt);
        if (m_GRZScopeEntryElapsed < 0 || !m_opticsUsed || m_opticsUsed.AllowsDOF())
            return nativeFov;
        m_GRZScopeEntryElapsed = m_GRZScopeEntryElapsed + Math.Max(pDt, 0);
        float fraction = Math.Clamp(m_GRZScopeEntryElapsed / 0.18, 0, 1);
        // Ease the lens FOV while the camera is already at the sight point.
        // Do not interpolate camera position through the body or firearm.
        float eased = fraction * fraction * (3 - 2 * fraction);
        float outputFov = m_GRZScopeEntryFov + (nativeFov - m_GRZScopeEntryFov) * eased;
        if (fraction >= 1)
            m_GRZScopeEntryElapsed = -1;
        return outputFov;
    }

    override void SetCameraPPDelay(DayZPlayerCamera pPrevCamera)
    {
        super.SetCameraPPDelay(pPrevCamera);
        // The native camera schedules its own effects/clothing handling using
        // this delay. Match those effects to the direct firearm scope entry.
        if (m_weaponUsed && m_opticsUsed && GRZQuickScopePolicy.IsSupportedSource(pPrevCamera) && GetGame() && GetGame().GetPlayer() == m_pPlayer)
            m_CameraPPDelay = 0;
    }
}
#endif
