# GUNRUNNERZ Quick Scope v0.2 — slower lens entry test

This revision responds to feedback that v0.1 is too fast and still exposes the character/weapon during entry.

- Magnified mounted scopes now ease from the prior camera FOV to the native scope FOV over 0.18 seconds, with a smoothstep curve. Spatial scope entry/exit remains a direct cut: slowing camera travel would reintroduce the path through the character. Exit is still immediate; this is not a slower exit build.
- Native scope effects, clothing hide and configured barrel hide are requested synchronously at camera activation as well as through the existing native queued callbacks. This targets the first-frame visibility window without manually hiding entire player/weapon entities. Native exit restoration remains intact.
- Iron-sight camera blends are capped at 0.14 seconds instead of v0.1's 0.08.
- A [GRZQuickScope v0.2] entry is printed once per camera instance in script logs to identify the active build. Nothing appears on screen.

IMPORTANT: Native HideWeaponBarrel depends on the weapon model having its configured hide selection. This addon cannot guarantee that arbitrary modded weapon geometry disappears. If the whole gun remains visible after this build is confirmed active, provide a new clip and weapon/scope names/configs; do not assume timing is the only cause. It does not hide the entire gun/optic or remove view geometry. First-person/model visibility and queued callback ordering still require runtime testing.

Normal scope magnification after entry, breath holding, native readiness, firing/ballistics, bolt cycles, reloads, scope return and aim input cancellation are retained. No early readiness bypass is included. The lens ease temporarily changes visual FOV during entry, which changes perceived aim scale; verify shot/sight alignment while entering rather than assuming it is unaffected.

Replace v0.1 with this single PBO, on client/server shared -mod, after backing up outside loaded addons. Do not load both. Keep GRZ Movement/stamina/autorun and LUGU unchanged. Re-sign the changed PBO using your normal signing process. First test in Editor/test deployment with the same sequence. Check initial body visibility, full gun geometry, rapid release/repress, cycle while aiming, optics changes/NV, iron sights, first/third person, prone, menus and death. Send the new clip and script log if the problem remains. Rollback restores v0.1 and its matching signature; no persistence wipe.

Package integrity and SERVER preprocessing are checked locally. DayZ compilation, actual visual smoothness, first-frame hiding and all-gun compatibility are NOT verified.

The v0.1 description below is historical where superseded by these changes.

## v0.1 — camera-only test

Targets the uploaded 4.597-second clip: the scope mask is visible while the camera is still behind the character, showing the head/sleeve inside the reticle, followed by close weapon/arm geometry during the return. This is observed visual overlap, not proof of which mod causes it.

## What changes

Native firearm scope camera entry and exit use a direct camera cut (zero transition time), avoiding a long camera flight through the character. The existing native optic postprocess/clothing callback delay is set to zero for the local player's mounted firearm optic, matching the direct entry. Iron-sight entry/exit keeps a short blend, capped at 0.08 seconds. Existing shorter iron-sight transitions remain shorter. Scope-to-iron-sight transitions use a direct cut.

The direct scoped transition is intentionally crisp, not a cinematic blend. Actual perceived smoothness, first-frame mask/clothing ordering and custom geometry still need in-game validation. Setting a zero delay queues native callbacks; it does not prove that every renderer frame is free of clipping.

This uses native camera IDs with any firearm using them; it is not restricted to one weapon or scope class. Custom mods with separate cameras or callbacks may need additional work. Universal compatibility has NOT been verified.

## What stays native

No early-ADS permission or weapon readiness override is included. The earlier unpublished readiness/weapon-action draft was discarded after the user's clarification. Raising, firing, bolt cycles, reloads, scope return, input cancellation, recoil, sway, ballistics, near plane, scope magnification and damage are unchanged. A bolt cycle can still leave the scope. There is no automatic aim latch or automatic chambering.

Handheld binoculars are excluded by the firearm-in-hands check. Vehicle/unconscious/jump/climb camera pairs and ordinary stance-to-stance transitions are excluded. No third-party animation assets, LUGU changes, FOV slider changes, HUD/chat notifications, RPCs, profile files or new keybinds are included. GRZ Movement, stamina and autorun remain separate.

## Install and test

Extract and load @GRZ_QuickScope after your shared mods. For multiplayer distribute/load the same PBO via normal -mod on both clients/server. SERVER preprocessing excludes the client camera script. Do not load another quick-scope/camera-transition addon during the first comparison. Keep just one copy and sign the PBO with your normal process for signature-enforced servers; it is unsigned here. Back up existing files/mod lists outside loaded addons.

Test the exact uploaded sequence with and without this addon. Check if the character remains inside the reticle, whether the scope view clears cleanly on release, and whether a fast second ADS press leaves stale scope effects. Test vanilla bolt-action + scope, modded scoped rifle, semi-auto and pistol iron sights; first/third person; standing/crouched/prone; movement/lean; hold/toggle ADS; firing/cycling while aiming; release during cycling; optic switching; reload; night-vision optics; binoculars; walls; menus; death/respawn; and GRZ held zoom/FOV preview. Record another short clip if overlap remains. No need to replace GRZ Movement or alter LUGU.

Inspected against official DayZ 1.30.164200 scripts, commit e8204c69fcfd056ea29a9728990fd9f7941ce8a6. Packaging/checksum/source round-trip and SERVER preprocessing are static checks only. This has NOT been compiled or tested in DayZ.

## Rollback/source

Remove @GRZ_QuickScope from both mod lists, or remove only GRZ_QuickScope.pbo and its matching signature from your shared pack, then restart. No profile/persistence wipe is needed. Full addon source and Python standard-library build tools are included. No PK_BetterAim PBO or dependency is included.
