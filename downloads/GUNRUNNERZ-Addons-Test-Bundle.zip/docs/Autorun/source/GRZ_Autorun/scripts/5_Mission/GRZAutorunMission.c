#ifndef SERVER
modded class MissionGameplay
{
    override void OnInit()
    {
        super.OnInit();
        GRZAutorunState.Active = false;
    }

    override void OnUpdate(float timeslice)
    {
        super.OnUpdate(timeslice);
        PlayerBase player = PlayerBase.Cast(GetGame().GetPlayer());
        if (!GRZAutorunState.CanRun(player))
        {
            GRZAutorunState.Active = false;
            return;
        }
        if (GRZAutorunState.Pressed("UAGRZAutorunToggle"))
        {
            GRZAutorunState.Active = !GRZAutorunState.Active;
            GRZAutorunState.Notify();
        }
    }

    override void OnMissionFinish()
    {
        GRZAutorunState.Active = false;
        super.OnMissionFinish();
    }
}
#endif
