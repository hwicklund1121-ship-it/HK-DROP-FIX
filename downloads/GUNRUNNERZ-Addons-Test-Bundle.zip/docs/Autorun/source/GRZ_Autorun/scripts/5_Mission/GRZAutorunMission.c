#ifndef SERVER
modded class MissionGameplay
{
    protected ref set<int> m_GRZAutorunHeldKeys;
    protected bool m_GRZAutorunCancelledThisFrame;

    override void OnInit()
    {
        super.OnInit();
        GRZAutorunState.Active = false;
        m_GRZAutorunHeldKeys = new set<int>();
        m_GRZAutorunCancelledThisFrame = false;
    }

    override void OnKeyPress(int key)
    {
        if (!m_GRZAutorunHeldKeys)
            m_GRZAutorunHeldKeys = new set<int>();
        // Ignore keyboard-repeat events for a key already held down. The
        // initial autorun key must not cancel itself while it is being held.
        if (m_GRZAutorunHeldKeys.Find(key) == -1)
        {
            m_GRZAutorunHeldKeys.Insert(key);
            if (GRZAutorunState.Active)
            {
                GRZAutorunState.Active = false;
                m_GRZAutorunCancelledThisFrame = true;
            }
        }
        super.OnKeyPress(key);
    }

    override void OnKeyRelease(int key)
    {
        if (m_GRZAutorunHeldKeys)
        {
            int index = m_GRZAutorunHeldKeys.Find(key);
            if (index != -1) m_GRZAutorunHeldKeys.Remove(index);
        }
        super.OnKeyRelease(key);
    }

    override void OnUpdate(float timeslice)
    {
        bool cancelledByKey = m_GRZAutorunCancelledThisFrame;
        m_GRZAutorunCancelledThisFrame = false;
        super.OnUpdate(timeslice);
        PlayerBase player = PlayerBase.Cast(GetGame().GetPlayer());
        if (!GRZAutorunState.CanRun(player))
        {
            GRZAutorunState.Active = false;
            return;
        }
        // Keep the existing action ID so previously assigned bindings survive.
        // This action starts autorun; keyboard events stop it. Do not restart
        // on the same frame when pressing the bound key stopped a running mode.
        if (!cancelledByKey && !GRZAutorunState.Active && GRZAutorunState.Pressed("UAGRZAutorunToggle"))
        {
            GRZAutorunState.Active = true;
            GRZAutorunState.Notify();
        }
    }

    override void OnMissionFinish()
    {
        GRZAutorunState.Active = false;
        if (m_GRZAutorunHeldKeys) m_GRZAutorunHeldKeys.Clear();
        super.OnMissionFinish();
    }
}
#endif
