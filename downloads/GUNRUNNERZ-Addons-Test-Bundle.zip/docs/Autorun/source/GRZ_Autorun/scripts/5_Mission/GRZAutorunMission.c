#ifndef SERVER
modded class MissionGameplay
{
    override void OnInit()
    {
        super.OnInit();
        GRZAutorunState.Load();
    }

    override void OnUpdate(float timeslice)
    {
        super.OnUpdate(timeslice);
        PlayerBase player = PlayerBase.Cast(GetGame().GetPlayer());
        if (!GRZAutorunState.CanRun(player))
        {
            GRZAutorunState.Active = false;
            return;
        }
        if (GRZAutorunState.Pressed("UAGRZAutorunSpeed"))
        {
            GRZAutorunState.Speed++;
            if (GRZAutorunState.Speed > 3) GRZAutorunState.Speed = 1;
            GRZAutorunState.Save();
            GRZAutorunState.Notify();
        }
        if (GRZAutorunState.Pressed("UAGRZAutorunToggle"))
        {
            GRZAutorunState.Active = !GRZAutorunState.Active;
            GRZAutorunState.Notify();
        }
    }

    override void OnMissionFinish()
    {
        GRZAutorunState.Active = false;
        super.OnMissionFinish();
    }
}
#endif
