#ifndef SERVER
class GRZAutorunState
{
    static bool Active;

    static bool Pressed(string name)
    {
        UAInput input = GetUApi().GetInputByName(name);
        return input && input.LocalPress();
    }

    static bool Held(string name)
    {
        UAInput input = GetUApi().GetInputByName(name);
        return input && input.LocalValue() > 0.1;
    }

    static bool CanRun(PlayerBase player)
    {
        if (!player || !player.IsAlive() || player.IsUnconscious() || player.IsRestrained() || player.IsRaised())
            return false;
        if (!GetGame().GetMission() || GetGame().GetMission().IsControlDisabled() || GetGame().GetUIManager().GetMenu())
            return false;
        return player.GetCurrentCommandID() == DayZPlayerConstants.COMMANDID_MOVE;
    }

    static void Notify()
    {
        string status = "OFF";
        if (Active) status = "ON - Full sprint";
        NotificationSystem.AddNotificationExtended(2.0, "GUNRUNNERZ AUTORUN", status);
    }
}

modded class PlayerBase
{
    override void CommandHandler(float pDt, int pCurrentCommandID, bool pCurrentCommandFinished)
    {
        if (GetGame() && GetGame().GetPlayer() == this && GRZAutorunState.Active)
        {
            if (!GRZAutorunState.CanRun(this) || GRZAutorunState.Held("UAMoveForward") || GRZAutorunState.Held("UAMoveBack") || GRZAutorunState.Held("UAMoveLeft") || GRZAutorunState.Held("UAMoveRight"))
            {
                GRZAutorunState.Active = false;
            }
            else
            {
                HumanInputController controls = GetInputController();
                if (controls)
                {
                    controls.OverrideMovementSpeed(HumanInputControllerOverrideType.ONE_FRAME, 3.0);
                    controls.OverrideMovementAngle(HumanInputControllerOverrideType.ONE_FRAME, 0.0);
                }
            }
        }
        super.CommandHandler(pDt, pCurrentCommandID, pCurrentCommandFinished);
    }
}
#endif
