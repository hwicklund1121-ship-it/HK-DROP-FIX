#ifndef SERVER
class GRZAutorunPreferences
{
    int Speed = 2;
}

class GRZAutorunState
{
    static bool Active;
    static int Speed = 2;
    static const string FILE = "$profile:GRZ_Autorun.json";

    static void Load()
    {
        Active = false;
        GRZAutorunPreferences settings = new GRZAutorunPreferences();
        string error;
        if (FileExist(FILE))
        {
            if (!JsonFileLoader<GRZAutorunPreferences>.LoadFile(FILE, settings, error))
            {
                Print("[GRZAutorun] Could not load preferences; using jog. " + error);
                Speed = 2;
                return;
            }
        }
        if (settings.Speed < 1 || settings.Speed > 3)
            settings.Speed = 2;
        Speed = settings.Speed;
    }

    static void Save()
    {
        GRZAutorunPreferences settings = new GRZAutorunPreferences();
        settings.Speed = Speed;
        string error;
        if (!JsonFileLoader<GRZAutorunPreferences>.SaveFile(FILE, settings, error))
            Print("[GRZAutorun] Could not save preferences. " + error);
    }

    static bool Pressed(string name)
    {
        UAInput input = GetUApi().GetInputByName(name);
        return input && input.LocalPress();
    }

    static bool Held(string name)
    {
        UAInput input = GetUApi().GetInputByName(name);
        return input && input.LocalValue() > 0.1;
    }

    static bool CanRun(PlayerBase player)
    {
        if (!player || !player.IsAlive() || player.IsUnconscious() || player.IsRestrained() || player.IsRaised())
            return false;
        if (!GetGame().GetMission() || GetGame().GetMission().IsControlDisabled() || GetGame().GetUIManager().GetMenu())
            return false;
        return player.GetCurrentCommandID() == DayZPlayerConstants.COMMANDID_MOVE;
    }

    static void Notify()
    {
        string pace = "Jog";
        if (Speed == 1) pace = "Walk";
        else if (Speed == 3) pace = "Sprint";
        string status = "OFF - ";
        if (Active) status = "ON - ";
        NotificationSystem.AddNotificationExtended(2.0, "GUNRUNNERZ AUTORUN", status + pace);
    }
}

modded class PlayerBase
{
    override void CommandHandler(float pDt, int pCurrentCommandID, bool pCurrentCommandFinished)
    {
        if (GetGame() && GetGame().GetPlayer() == this && GRZAutorunState.Active)
        {
            if (!GRZAutorunState.CanRun(this) || GRZAutorunState.Held("UAMoveForward") || GRZAutorunState.Held("UAMoveBack") || GRZAutorunState.Held("UAMoveLeft") || GRZAutorunState.Held("UAMoveRight"))
            {
                GRZAutorunState.Active = false;
            }
            else
            {
                HumanInputController controls = GetInputController();
                if (controls)
                {
                    controls.OverrideMovementSpeed(HumanInputControllerOverrideType.ONE_FRAME, GRZAutorunState.Speed);
                    controls.OverrideMovementAngle(HumanInputControllerOverrideType.ONE_FRAME, 0.0);
                }
            }
        }
        super.CommandHandler(pDt, pCurrentCommandID, pCurrentCommandFinished);
    }
}
#endif
