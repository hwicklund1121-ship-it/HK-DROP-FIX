"""Build the standalone configurable GRZ autorun addon."""
import argparse
import hashlib
from pathlib import Path
import tempfile
import shutil
import zipfile
from build_grz_staged import make_pbo


def main(output):
    repo = Path(__file__).resolve().parents[1]
    source = repo / 'GRZ_Autorun'
    files = sorted(p for p in source.rglob('*') if p.is_file() and p.suffix in ('.c', '.cpp', '.xml', '.csv'))
    with tempfile.TemporaryDirectory(prefix='grz-autorun-') as directory:
        module = Path(directory) / source.name
        for path in files:
            target = module / path.relative_to(source)
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(path, target)
        pbo = make_pbo(module)
    addon = '@GRZ_Autorun/addons/GRZ_Autorun.pbo'
    output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(output, 'w', zipfile.ZIP_DEFLATED) as archive:
        archive.writestr(addon, pbo)
        archive.write(source / 'README.md', 'README.md')
        archive.writestr('SHA256.txt', hashlib.sha256(pbo).hexdigest() + '  ' + addon + '\n')
        for path in files:
            archive.write(path, 'source/GRZ_Autorun/' + path.relative_to(source).as_posix())
        for name in ('build_grz_autorun.py', 'build_grz_staged.py', 'repack_lugu_no_motorbike.py'):
            archive.write(repo / 'tools' / name, 'source/tools/' + name)
    with zipfile.ZipFile(output) as archive:
        assert archive.testzip() is None
        assert archive.read(addon) == pbo
    print('PASS: PBO checksum/source round-trip and ZIP payload verified. Runtime testing required.')
    print(output)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=Path(__file__).resolve().parents[1] / 'downloads/GRZ-Autorun-v0.1-TEST.zip')
    main(parser.parse_args().output)
