# GUNRUNNERZ AUTORUN v0.2 — full sprint, experimental

One unbound, rebindable action: **GUNRUNNERZ AUTORUN**, registered without a custom sorting group and intended for Controls > Unsorted. Bind it, release manual movement keys, then toggle autorun. Every player requests full normal sprint (native input speed 3.0). There is no speed selection, speed key or preferences file. Old GRZ_Autorun.json files are ignored. This is 100% normal sprint, not a speed boost; injuries, stance and other native restrictions still apply.

Manual forward/back/left/right input cancels autorun. It also cancels on menus/disabled controls, raised hands/weapon, death, unconsciousness, restraint or leaving the normal movement command, including jump, climbing, swimming or vehicle entry. Mission initialization/reconnect starts OFF. A notification shows status.

Uses local input-controller ONE_FRAME speed/angle requests before the inherited command handler. Does not write position/velocity, send custom movement RPCs, register timers, log per frame or replace stamina handling. Dedicated server script bodies are empty. No requests are submitted while inactive; the last request expires through the engine. This changes the input path while active and must be tested against the existing movement issue.

## Install and rollback

Stop client/server. Back up the old autorun PBO/signature outside loaded addon folders. Replace GRZ_Autorun on both sides through shared -mod distribution; do not load both versions, other autorun implementations or use -serverMod only. Bind GUNRUNNERZ AUTORUN in Controls. A stale v0.1 speed binding has no current action. Unsorted placement/localization must be checked in DayZ. Use the owner's signing/public-key workflow on signature-enforcing servers; do not disable verification.

Pair with GRZ_ActionStamina so only empty-hands punches and holding breath spend stamina. Autorun does not modify stamina. Keep server stamina enabled and disable competing stamina overrides. GRZ Movement/FOV/camera/weapon-lift code is unchanged.

Test toggle, full-sprint request, manual cancel, menus, aim, jump/vehicles, death/respawn and reconnect. Verify old speed JSON cannot affect pace. With ActionStamina, sprint must not drain, light/heavy unarmed punches and breath holding must drain, and free movement must remain usable after the action bar is exhausted. Other native restrictions remain. Test addons separately before combining.

Rollback: stop both, restore the backed-up autorun or remove @GRZ_Autorun from both launch lists, then restart. No persistence wipe required.

Package integrity, input XML/localization consistency and client/SERVER preprocessing checks run locally. Enforce compilation, UI placement and gameplay remain unverified. This is not a desync fix.
