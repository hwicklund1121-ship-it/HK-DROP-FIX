# GUNRUNNERZ AUTORUN v0.1 — experimental

Separate addon with two unbound, rebindable actions registered without a custom sorting group, intended for Settings > Controls > Unsorted:

- **GUNRUNNERZ AUTORUN**: toggle forward autorun.
- **GUNRUNNERZ AUTORUN SPEED**: cycle walk (1), jog (2, default), sprint (3). Selection is saved in the client's `$profile:GRZ_Autorun.json`. A short notification shows status and pace. To edit the JSON manually, close DayZ first; set `Speed` to 1, 2 or 3.

Bind both actions before use. Release manual movement keys, then toggle on. Any forward/back/left/right movement input cancels autorun. It also cancels when controls are disabled, a menu opens, the player raises hands/weapon, dies, becomes unconscious/restrained, or leaves the normal movement command (for example jumping, climbing, swimming or entering a vehicle). Reconnect/mission initialization starts OFF. The saved speed is a request to normal DayZ movement; injuries, stance, stamina and other native restrictions may limit actual pace. No promised world-speed multiplier.

Implementation uses local input-controller ONE_FRAME speed/angle requests before the inherited player command handler. It does not set player position/velocity, send custom movement RPCs, register timers, log every frame, replace stamina handling or force server corrections. Dedicated server script bodies are empty. It still changes the local input path while active; compatibility with the existing movement issue must be tested, not assumed. No overrides are submitted while inactive. Canceling allows the last one-frame request to expire through the engine.

Install the supplied same-name addon on both sides through shared `-mod` distribution so clients receive it. Do not use `-serverMod` only. Disable other autorun implementations. Server signature enforcement requires an owner-signed PBO and the corresponding public key; do not disable verification. Bindings are initially unassigned to avoid imposing conflicting keys. Unsorted placement, localization and rebinding are expected from the input registration and must be verified in DayZ.

Test toggling each pace, cancel with each manual direction, menus/inventory/chat, aiming, jump/vehicle transitions, death/respawn and reconnect. Check native stamina restrictions without the separate stamina addon, then with it. Verify there is no autorun input when OFF, and compare normal manual sprint/strafe before and after installation. Existing GRZ camera/FOV/stamina sources are unchanged. This addon is not a movement desync fix.

Rollback: stop client/server, remove `@GRZ_Autorun` from both launch lists, restart. The preferences JSON may remain without effect. No persistence wipe is needed.

Local validation: PBO checksum/source round-trip, ZIP CRC, XML/localization references, source API checks, and client/SERVER preprocessing. Enforce compilation and DayZ runtime behavior remain unverified.
