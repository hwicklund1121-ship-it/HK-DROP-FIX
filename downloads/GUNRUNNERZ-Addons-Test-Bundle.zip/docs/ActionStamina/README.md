# GRZ Action Stamina v0.1 — experimental

Standalone addon: stamina is spent only on empty-hands light/heavy punches and holding breath. Weapon/tool melee is free. Sprinting, swimming, ladder movement, jumping, vaulting, climbing, rolling, evading and pushing do not spend stamina through the native movement/action depletion paths. Native non-stamina restrictions still apply. Heavy-punch and breath thresholds, action cooldowns, positive recovery and native stamina synchronization remain. Carried weight does not shrink the action-stamina cap; the server-configured maximum is retained. Movement may hold the current stamina value rather than refill it; this does not continuously top up the bar.

No player position, velocity, camera, input, network-correction or movement-response changes. This does not fix the movement desync under investigation. GRZ Movement v0.33 and its FOV/camera/weapon-lift code are not modified by this addon. This policy must be shared by server and clients; it is not a server-only mod.

## Install and rollback

1. Stop the test server and client. Save their existing launch configurations. Back up any stamina addon being replaced outside loaded addon directories.
2. Extract this ZIP and add `@GRZ_ActionStamina` to the shared `-mod` list on both sides. Disable other unlimited/selective stamina implementations, including repacked copies. Keep server stamina enabled for punch/breath costs; a global stamina-disable setting or another overriding addon can defeat this policy. Do not modify unrelated movement settings.
3. This is unsigned: sign the PBO with the owner's normal signing workflow for signature-enforcing servers. Do not disable signature verification.
4. To roll back, stop both, remove this addon from both launch configurations and restore any previous stamina addon/configuration. Restart both. No persistence wipe is required.

## Required in-game checks

- Empty hands: light and heavy punches spend stamina. Repeated heavy punches respect native exhaustion/recovery.
- Aiming with a weapon: hold breath and verify drain, exhaustion and recovery after release.
- Sprint on ground and while strafing, swim fast, climb ladders, jump, vault, climb, roll and evade: no stamina expenditure. Repeat at an empty bar after punching; free actions must not be blocked by stamina, while injuries, stance, obstacles and other native restrictions remain.
- Weapon/tool melee: no stamina charge. Carried load: no weight-induced cap reduction.
- Verify the local bar and server-observed behavior, reconnect and respawn, then inspect client/server RPT and script errors. Exercise keycards and existing GRZ camera/FOV features as regression checks if those mods are loaded.

Validation performed locally: PBO checksum/decompression/source round-trip, ZIP integrity, shared client/SERVER preprocessing and override signature checks against the published BohemiaInteractive DayZ Script Diff source. No Enforce compiler or DayZ runtime is available here; exact DayZ 1.30 runtime behavior remains unverified. Third-party scripts calling `SetStamina` directly or using different action classifications can bypass this filter. Punch classification here means melee depletion while hands are empty, not an engine event identifying an individual fist strike.

Build: `python3 tools/build_grz_action_stamina.py --output /path/to/GRZ-ActionStamina-v0.1-TEST.zip`.
