"""Generic PBO serialization, compression and integrity checks."""
import hashlib
import struct


def read_cstring(data, position):
    end = data.index(b"\0", position)
    return data[position:end], end + 1


def read_pbo(data):
    position = 0
    headers = []
    properties = b""
    while True:
        start = position
        name, position = read_cstring(data, position)
        fields = struct.unpack_from("<5I", data, position)
        position += 20
        if not name and fields[0] == 0x56657273:
            while True:
                key, position = read_cstring(data, position)
                if not key:
                    break
                _, position = read_cstring(data, position)
            if properties:
                raise ValueError("Multiple property headers")
            properties = data[start:position]
            continue
        if not name:
            break
        headers.append((name, fields))
    entries = []
    for name, fields in headers:
        end = position + fields[4]
        entries.append((name, fields, data[position:end]))
        position = end
    if data[position:] != b"\0" + hashlib.sha1(data[:position]).digest():
        raise ValueError("PBO checksum mismatch or unexpected trailing data")
    return properties, entries


def decompress(data, size):
    ring = bytearray(b" " * 4096)
    cursor = 4078
    position = 0
    flags = 0
    output = bytearray()
    while len(output) < size:
        flags >>= 1
        if not flags & 256:
            flags = data[position] | 0xFF00
            position += 1
        if flags & 1:
            values = [data[position]]
            position += 1
            distance = None
        else:
            lo, hi = data[position:position + 2]
            position += 2
            distance = lo | ((hi & 240) << 4)
            values = range((hi & 15) + 3)
        for literal in values:
            value = literal if distance is None else ring[(cursor - distance) & 4095]
            output.append(value)
            ring[cursor] = value
            cursor = (cursor + 1) & 4095
    if len(output) != size or len(data) - position != 4:
        raise ValueError("Invalid compressed payload size")
    if struct.unpack("<I", data[position:])[0] != sum(output) & 0xFFFFFFFF:
        raise ValueError("Compressed payload checksum mismatch")
    return bytes(output)


def compress_literals(data):
    """Encode valid PBO Cprs/LZSS with literal groups and its payload checksum.

    Each entry retains the standard compressed payload checksum.
    """
    encoded = bytearray()
    for position in range(0, len(data), 8):
        group = data[position:position + 8]
        encoded.append((1 << len(group)) - 1)
        encoded.extend(group)
    encoded.extend(struct.pack("<I", sum(data) & 0xFFFFFFFF))
    return bytes(encoded)


def make_pbo(module):
    files = sorted(p for p in module.rglob('*') if p.is_file())
    header = b'\0' + struct.pack('<5I', 0x56657273, 0, 0, 0, 0) + b'prefix\0' + module.name.encode() + b'\0\0'
    payload = bytearray()
    for path in files:
        data = path.read_bytes()
        encoded = compress_literals(data)
        name = path.relative_to(module).as_posix().replace('/', '\\').encode()
        header += name + b'\0' + struct.pack('<5I', 0x43707273, len(data), 0, 0, len(encoded))
        payload.extend(encoded)
    body = header + b'\0' + bytes(20) + payload
    result = body + b'\0' + hashlib.sha1(body).digest()
    _, entries = read_pbo(result)
    assert len(entries) == len(files)
    for (name, metadata, stored), path in zip(entries, files):
        assert name.decode().replace('\\', '/') == path.relative_to(module).as_posix()
        assert decompress(stored, metadata[1]) == path.read_bytes()
    return result
