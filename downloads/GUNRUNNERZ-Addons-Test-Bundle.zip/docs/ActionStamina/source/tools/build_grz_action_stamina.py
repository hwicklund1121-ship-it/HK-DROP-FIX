"""Package the standalone shared GRZ action-stamina policy."""
import argparse
import hashlib
from pathlib import Path
import tempfile
import shutil
import zipfile

from build_grz_staged import make_pbo


def main(output):
    repo = Path(__file__).resolve().parents[1]
    source = repo / 'GRZ_ActionStamina'
    files = sorted(p for p in source.rglob('*') if p.is_file() and p.suffix in ('.c', '.cpp'))
    with tempfile.TemporaryDirectory(prefix='grz-stamina-') as directory:
        module = Path(directory) / source.name
        for path in files:
            target = module / path.relative_to(source)
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(path, target)
        pbo = make_pbo(module)
    addon_path = '@GRZ_ActionStamina/addons/GRZ_ActionStamina.pbo'
    output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(output, 'w', zipfile.ZIP_DEFLATED) as archive:
        archive.writestr(addon_path, pbo)
        archive.write(source / 'README.md', 'README.md')
        archive.writestr('SHA256.txt', hashlib.sha256(pbo).hexdigest() + '  ' + addon_path + '\n')
        for path in files:
            archive.write(path, 'source/GRZ_ActionStamina/' + path.relative_to(source).as_posix())
        for name in ('build_grz_action_stamina.py', 'build_grz_staged.py', 'repack_lugu_no_motorbike.py'):
            archive.write(repo / 'tools' / name, 'source/tools/' + name)
    with zipfile.ZipFile(output) as archive:
        assert archive.testzip() is None
        assert archive.read(addon_path) == pbo
    print('PASS: PBO checksum, source round-trip, ZIP integrity and payload verified. DayZ runtime testing required.')
    print(output)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=Path(__file__).resolve().parents[1] / 'downloads/GRZ-ActionStamina-v0.1-TEST.zip')
    main(parser.parse_args().output)
