// Shared policy: preserve native stamina update, synchronization and cooldowns.
// Charge only empty-hands punches and breath holding. Never write player motion.
modded class StaminaHandler
{
    protected bool GRZIsUnarmed()
    {
        return m_Player && !m_Player.GetItemInHands();
    }

    override protected void ProcessMovementState()
    {
        super.ProcessMovementState();
        if (m_StaminaDelta < 0)
            m_StaminaDelta = 0;
    }

    override void DepleteStaminaEx(EStaminaModifiers modifier, float dT = -1, float coef = 1.0)
    {
        if (modifier == EStaminaModifiers.HOLD_BREATH)
        {
            super.DepleteStaminaEx(modifier, dT, coef);
            return;
        }

        if (GRZIsUnarmed() && (modifier == EStaminaModifiers.MELEE_LIGHT || modifier == EStaminaModifiers.MELEE_HEAVY))
            super.DepleteStaminaEx(modifier, dT, coef);
    }

    override void RecalculateStaminaCap()
    {
        // Carrying weight must not reduce the remaining action-stamina pool.
        m_StaminaCap = CfgGameplayHandler.GetStaminaMax();
        m_StaminaCapSynced = m_StaminaCap;
    }

    override bool HasEnoughStaminaFor(EStaminaConsumers consumer)
    {
        if (consumer == EStaminaConsumers.HOLD_BREATH || (consumer == EStaminaConsumers.MELEE_HEAVY && GRZIsUnarmed()))
            return super.HasEnoughStaminaFor(consumer);
        return true;
    }

    override bool HasEnoughStaminaToStart(EStaminaConsumers consumer)
    {
        if (consumer == EStaminaConsumers.HOLD_BREATH || (consumer == EStaminaConsumers.MELEE_HEAVY && GRZIsUnarmed()))
            return super.HasEnoughStaminaToStart(consumer);
        return true;
    }
}
