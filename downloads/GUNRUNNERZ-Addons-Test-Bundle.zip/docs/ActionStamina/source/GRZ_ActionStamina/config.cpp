class CfgPatches
{
    class GRZ_ActionStamina
    {
        units[] = {};
        weapons[] = {};
        requiredVersion = 0.1;
        requiredAddons[] = {"DZ_Scripts"};
    };
};
class CfgMods
{
    class GRZ_ActionStamina
    {
        dir = "GRZ_ActionStamina";
        name = "GRZ Action Stamina";
        author = "GRZ";
        type = "mod";
        dependencies[] = {"World"};
        class defs
        {
            class worldScriptModule
            {
                value = "";
                files[] = {"GRZ_ActionStamina/scripts/4_World"};
            };
        };
    };
};
