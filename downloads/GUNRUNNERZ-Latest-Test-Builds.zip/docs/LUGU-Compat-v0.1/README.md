# GRZ / LUGU graph compatibility v0.1 — test only

This separate addon selects the exact graphName referenced by the supplied fixed LUGU after the GRZ_Movement and LUGUINSTADROPFIX CfgPatches dependencies load. It changes only SurvivorBase.enfAnimSys.graphName; it does not replace the animation system, instance, clips, skeleton or gameplay callbacks. No LUGU PBO or animation data is included, modified or repacked. Keep the fixed LUGU installed separately. Its inspected SHA256 is b7828501469aa310f20700b1e7021c11f8656bc8170f291d85c4249f6417127b.

This is a graph-selection test, not a proven pose or desync fix. GRZ itself does not replace this graph. If it was already selected correctly, this config will not repair internal animation transitions. Unlisted third-party patches can still override this field later. MATCH means only the expected path won; it does not establish graph loading, resource integrity or runtime behavior.

Stop both client/server, save launch lists, and back up replaced files outside loaded addons. Add @GRZ_LUGU_Compat to shared -mod after the fixed LUGU and GRZ Movement on both sides. Do not merge PBOs or install old LUGU experimental replacements. This addon requires both dependency patches; a missing-dependency error means they are not installed/loaded as expected. Keep other addons unchanged for this comparison.

Unsigned test build: use the owner's normal signing/public-key process; do not disable signature checks. Check the client/server script logs for [GRZLUGU]. It prints the effective SurvivorBase graph once at mission initialization and, on the client, the inherited actual character-class graph once after the player exists. There are no UI notifications, per-frame log writes or RPCs. expected_graph=MISMATCH identifies a graph selection/config inheritance problem. MATCH followed by a broken drop/stand-up requires a different investigation; do not declare compatibility from MATCH alone.

Test drop initiation, stand-up recovery (body and camera separately), weapons/empty hands, both shoulders and flat/sloped ground. Runtime compilation, resource loading, graph winner and gameplay must be verified in DayZ. Local package/source checks cannot establish compatibility.

Rollback: stop both, remove only @GRZ_LUGU_Compat from both shared launch lists, restart. Original GRZ and LUGU are untouched; no persistence wipe needed.
