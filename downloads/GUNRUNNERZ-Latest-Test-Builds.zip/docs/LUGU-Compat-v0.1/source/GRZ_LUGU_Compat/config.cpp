class CfgPatches
{
    class GRZ_LUGU_Compat
    {
        units[] = {};
        weapons[] = {};
        requiredVersion = 0.1;
        requiredAddons[] = {"DZ_Scripts", "DZ_Characters", "LUGUINSTADROPFIX", "GRZ_Movement"};
    };
};
class CfgMods
{
    class GRZ_LUGU_Compat
    {
        dir = "GRZ_LUGU_Compat";
        name = "GRZ LUGU Graph Compatibility Test";
        author = "GRZ";
        type = "mod";
        dependencies[] = {"Mission"};
        class defs
        {
            class missionScriptModule
            {
                value = "";
                files[] = {"GRZ_LUGU_Compat/scripts/5_Mission"};
            };
        };
    };
};
class CfgVehicles
{
    class Man;
    class SurvivorBase: Man
    {
        class enfAnimSys
        {
            graphName = "LUGUINSTADROPFIX\IO2JF\GJDH4KD\FGHJDGH\I3FJ4\GJKL2H\GJKDF9G\JFLK21KGH\KLJSDF8F23\GHJKDSDSHIG.agr";
        };
    };
};
