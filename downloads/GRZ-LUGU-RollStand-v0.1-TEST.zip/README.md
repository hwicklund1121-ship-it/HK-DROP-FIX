# GRZ LUGU Roll Stand v0.1 — experimental

Separate script-only test that permits a prone-to-upright stance request during a roll, keeping its raised/lowered variant. It targets a stock script permission gate; it does not force a stance or rewrite an animation graph. LUGU remains required and unchanged. Original LUGU credits and ownership remain with its author.

The official DayZ 1.30.164200 source used for inspection is BohemiaInteractive/DayZ-Script-Diff commit e8204c69fcfd056ea29a9728990fd9f7941ce8a6. Its roll restriction also exists in 1.29. This build has NOT been compiled by DayZ or tested in game. Packaging checks do not establish runtime compatibility.

## Install and test

1. Back up the current mod list. Start with DayZ Editor + the same LUGU build + this addon. Leave GRZ_LUGU_Compat and other experimental LUGU patches out of this isolated test. Do not change or replace LUGU's PBO.
2. Extract the ZIP. Add `@GRZ_LUGU_RollStand` to the normal client `-mod` list after LUGU. For a multiplayer test load the same addon on both server and clients, using normal `-mod`, not server-only `-serverMod`.
3. Try throw mode -> instant prone drop -> roll -> press stand before the roll finishes. Also check normal prone/stand, both roll directions, and actual throw wind-up/release. In multiplayer have another player watch the transition.
4. If the game cannot compile the World script module, remove this addon and send the error. If it loads but stand-up is unchanged, check the client and server script logs for `[GRZRollStand v0.1]`.
5. That marker means the override allowed a request, not that the character stood up. If present but the roll still completes, the script gate alone is insufficient. If absent, the input may not reach this callback, the safety guards may reject it, or the addon may not be active; absence alone cannot distinguish those cases.

The marker prints once per player instance to the script log only. There are no chat messages, HUD notifications, keybinds, RPCs, position/speed writes, camera changes or stamina changes.

## Limits

The LUGU graph has timed roll exits. Even an allowed request may not interrupt the native command/graph or restore the old instant upright pose. This is a controlled candidate, not a confirmed fix.

The override calls `super.CanChangeStance` exactly once. For the narrow roll-to-upright case it can replace a false result with true after explicitly retaining stock action/throw/input guards and checking alive/conscious/unrestrained state. It cannot determine whether another mod returned false for an additional private reason. Therefore validate with LUGU alone first; compatibility with arbitrary stance overrides is not guaranteed. It does not relax the native check for crouching, non-roll transitions or transitions between raised/lowered variants.

The PBO is unsigned. Use your normal signing process and distribute the matching signature/key before a signature-enforced multiplayer test. Do not reuse a signature from a different PBO or disable signature verification.

## Rollback

Remove `@GRZ_LUGU_RollStand` from both client and server mod lists and restart. If placing its PBO inside a shared pack, remove only `GRZ_LUGU_RollStand.pbo` and its matching signature instead. Keep backups outside loaded addon folders. No profiles, persistence, LUGU files, or other GRZ addons need changing.

## Source

`source/GRZ_LUGU_RollStand` contains the complete addon source. `source/tools` contains the Python standard-library builder and generic PBO helper. No LUGU assets or repacking tools are included.
