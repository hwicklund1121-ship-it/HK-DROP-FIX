"""Build the external experimental roll-to-standing permission addon."""
import argparse
import hashlib
from pathlib import Path
import shutil
import tempfile
import zipfile
from pbo_format import make_pbo


def main(output):
    repo = Path(__file__).resolve().parents[1]
    source = repo / 'GRZ_LUGU_RollStand'
    files = sorted(p for p in source.rglob('*') if p.is_file() and p.suffix in ('.c', '.cpp'))
    with tempfile.TemporaryDirectory(prefix='grz-roll-') as directory:
        module = Path(directory) / source.name
        for path in files:
            target = module / path.relative_to(source)
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(path, target)
        pbo = make_pbo(module)
    addon = '@GRZ_LUGU_RollStand/addons/GRZ_LUGU_RollStand.pbo'
    output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(output, 'w', zipfile.ZIP_DEFLATED) as archive:
        archive.writestr(addon, pbo)
        archive.write(source / 'README.md', 'README.md')
        archive.write(source / 'README.md', 'source/GRZ_LUGU_RollStand/README.md')
        archive.writestr('SHA256.txt', hashlib.sha256(pbo).hexdigest() + '  ' + addon + '\n')
        for path in files:
            archive.write(path, 'source/GRZ_LUGU_RollStand/' + path.relative_to(source).as_posix())
        for name in ('build_grz_lugu_roll_stand.py', 'pbo_format.py'):
            archive.write(repo / 'tools' / name, 'source/tools/' + name)
    with zipfile.ZipFile(output) as archive:
        assert archive.testzip() is None
        assert archive.read(addon) == pbo
    print('PASS: PBO checksum/source round-trip and ZIP CRC. DayZ runtime validation required.')
    print(output)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=Path(__file__).resolve().parents[1] / 'downloads/GRZ-LUGU-RollStand-v0.1-TEST.zip')
    main(parser.parse_args().output)
