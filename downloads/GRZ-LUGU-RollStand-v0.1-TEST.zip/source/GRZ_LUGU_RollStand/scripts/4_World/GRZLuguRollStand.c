// External permission test only. No animation assets or forced stance commands.
modded class PlayerBase
{
    protected bool m_GRZRollStandLogged;

    override bool CanChangeStance(int previousStance, int newStance)
    {
        bool originalResult = super.CanChangeStance(previousStance, newStance);
        if (originalResult)
            return originalResult;

        if (!GetGame().ConfigIsExisting("CfgPatches LUGUINSTADROPFIX"))
            return originalResult;

        // Only prone -> upright, retaining the raised/lowered variant.
        bool standRequest = previousStance == DayZPlayerConstants.STANCEIDX_PRONE && newStance == DayZPlayerConstants.STANCEIDX_ERECT;
        bool raisedStandRequest = previousStance == DayZPlayerConstants.STANCEIDX_RAISEDPRONE && newStance == DayZPlayerConstants.STANCEIDX_RAISEDERECT;
        if (!standRequest && !raisedStandRequest)
            return originalResult;

        HumanCommandMove move = GetCommand_Move();
        if (!move || !move.IsInRoll())
            return originalResult;

        if (!IsAlive() || IsUnconscious() || IsRestrained())
            return originalResult;

        // Retain stock 1.30.164200 action, throwing and input restrictions.
        if (GetActionManager() && GetActionManager().GetRunningAction() && !GetActionManager().GetRunningAction().CanBePerformedWhileChangingStance())
            return originalResult;

        if (!GetThrowing())
            return originalResult;
        if (GetThrowing().IsThrowingInProgress() || GetThrowing().IsThrowingAnimationPlaying())
            return originalResult;

        UAInterface inputInterface = GetInputInterface();
        if (!inputInterface)
            return originalResult;
        if (inputInterface.SyncedValue_ID(UAThrowitem) > 0 || inputInterface.SyncedValue_ID(UADropitem) > 0)
            return originalResult;

        // One script-log entry per player instance; no on-screen notification.
        if (!m_GRZRollStandLogged)
        {
            Print("[GRZRollStand v0.1] Allowed prone-to-upright request during roll. This does not confirm an animation transition.");
            m_GRZRollStandLogged = true;
        }
        return true;
    }
};
