class CfgPatches
{
    class GRZ_LUGU_RollStand
    {
        units[] = {};
        weapons[] = {};
        requiredVersion = 0.1;
        requiredAddons[] = {"DZ_Scripts", "LUGUINSTADROPFIX"};
    };
};
class CfgMods
{
    class GRZ_LUGU_RollStand
    {
        dir = "GRZ_LUGU_RollStand";
        name = "GRZ LUGU Roll Stand Test";
        author = "GRZ";
        type = "mod";
        dependencies[] = {"World"};
        class defs
        {
            class worldScriptModule
            {
                value = "";
                files[] = {"GRZ_LUGU_RollStand/scripts/4_World"};
            };
        };
    };
};
