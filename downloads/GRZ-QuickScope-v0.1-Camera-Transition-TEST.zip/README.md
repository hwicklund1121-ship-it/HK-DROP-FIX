# GUNRUNNERZ Quick Scope v0.1 — camera-only test

Targets the uploaded 4.597-second clip: the scope mask is visible while the camera is still behind the character, showing the head/sleeve inside the reticle, followed by close weapon/arm geometry during the return. This is observed visual overlap, not proof of which mod causes it.

## What changes

Native firearm scope camera entry and exit use a direct camera cut (zero transition time), avoiding a long camera flight through the character. The existing native optic postprocess/clothing callback delay is set to zero for the local player's mounted firearm optic, matching the direct entry. Iron-sight entry/exit keeps a short blend, capped at 0.08 seconds. Existing shorter iron-sight transitions remain shorter. Scope-to-iron-sight transitions use a direct cut.

The direct scoped transition is intentionally crisp, not a cinematic blend. Actual perceived smoothness, first-frame mask/clothing ordering and custom geometry still need in-game validation. Setting a zero delay queues native callbacks; it does not prove that every renderer frame is free of clipping.

This uses native camera IDs with any firearm using them; it is not restricted to one weapon or scope class. Custom mods with separate cameras or callbacks may need additional work. Universal compatibility has NOT been verified.

## What stays native

No early-ADS permission or weapon readiness override is included. The earlier unpublished readiness/weapon-action draft was discarded after the user's clarification. Raising, firing, bolt cycles, reloads, scope return, input cancellation, recoil, sway, ballistics, near plane, scope magnification and damage are unchanged. A bolt cycle can still leave the scope. There is no automatic aim latch or automatic chambering.

Handheld binoculars are excluded by the firearm-in-hands check. Vehicle/unconscious/jump/climb camera pairs and ordinary stance-to-stance transitions are excluded. No third-party animation assets, LUGU changes, FOV slider changes, HUD/chat notifications, RPCs, profile files or new keybinds are included. GRZ Movement, stamina and autorun remain separate.

## Install and test

Extract and load @GRZ_QuickScope after your shared mods. For multiplayer distribute/load the same PBO via normal -mod on both clients/server. SERVER preprocessing excludes the client camera script. Do not load another quick-scope/camera-transition addon during the first comparison. Keep just one copy and sign the PBO with your normal process for signature-enforced servers; it is unsigned here. Back up existing files/mod lists outside loaded addons.

Test the exact uploaded sequence with and without this addon. Check if the character remains inside the reticle, whether the scope view clears cleanly on release, and whether a fast second ADS press leaves stale scope effects. Test vanilla bolt-action + scope, modded scoped rifle, semi-auto and pistol iron sights; first/third person; standing/crouched/prone; movement/lean; hold/toggle ADS; firing/cycling while aiming; release during cycling; optic switching; reload; night-vision optics; binoculars; walls; menus; death/respawn; and GRZ held zoom/FOV preview. Record another short clip if overlap remains. No need to replace GRZ Movement or alter LUGU.

Inspected against official DayZ 1.30.164200 scripts, commit e8204c69fcfd056ea29a9728990fd9f7941ce8a6. Packaging/checksum/source round-trip and SERVER preprocessing are static checks only. This has NOT been compiled or tested in DayZ.

## Rollback/source

Remove @GRZ_QuickScope from both mod lists, or remove only GRZ_QuickScope.pbo and its matching signature from your shared pack, then restart. No profile/persistence wipe is needed. Full addon source and Python standard-library build tools are included. No PK_BetterAim PBO or dependency is included.
