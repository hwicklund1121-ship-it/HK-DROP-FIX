// Camera-only quick-scope candidate. No ADS/readiness/weapon-state overrides.
#ifndef SERVER
class GRZQuickScopePolicy
{
    static const float IRONSIGHT_BLEND_SECONDS = 0.08;

    static bool IsSightCamera(int camera)
    {
        return camera == DayZPlayerCameras.DAYZCAMERA_IRONSIGHTS || camera == DayZPlayerCameras.DAYZCAMERA_OPTICS;
    }

    static bool IsSupportedSource(DayZPlayerCamera camera)
    {
        if (!camera)
            return false;
        string name = camera.ClassName();
        return name == "DayZPlayerCamera1stPerson" || name == "DayZPlayerCamera3rdPersonErc" || name == "DayZPlayerCamera3rdPersonCrouch" || name == "DayZPlayerCamera3rdPersonProne" || name == "DayZPlayerCamera3rdPersonErcRaised" || name == "DayZPlayerCamera3rdPersonCrouchRaised" || name == "DayZPlayerCamera3rdPersonProneRaised" || name == "DayZPlayerCameraIronsights" || name == "DayZPlayerCameraOptics";
    }

    static bool IsOnFootCamera(int camera)
    {
        return IsSightCamera(camera) || camera == DayZPlayerCameras.DAYZCAMERA_1ST || camera == DayZPlayerCameras.DAYZCAMERA_3RD_ERC || camera == DayZPlayerCameras.DAYZCAMERA_3RD_CRO || camera == DayZPlayerCameras.DAYZCAMERA_3RD_PRO || camera == DayZPlayerCameras.DAYZCAMERA_3RD_ERC_RAISED || camera == DayZPlayerCameras.DAYZCAMERA_3RD_CRO_RAISED || camera == DayZPlayerCameras.DAYZCAMERA_3RD_PRO_RAISED;
    }
}

modded class DayZPlayerCameras
{
    override static float GetTransitionTime(int pFrom, int pTo)
    {
        float originalTime = super.GetTransitionTime(pFrom, pTo);
        if (!GetGame())
            return originalTime;
        PlayerBase player = PlayerBase.Cast(GetGame().GetPlayer());
        if (!player || !player.IsAlive() || !Weapon_Base.Cast(player.GetItemInHands()))
            return originalTime;
        if (!GRZQuickScopePolicy.IsOnFootCamera(pFrom) || !GRZQuickScopePolicy.IsOnFootCamera(pTo))
            return originalTime;
        if (pFrom == DAYZCAMERA_OPTICS || pTo == DAYZCAMERA_OPTICS)
            return 0.0;
        if (pFrom == DAYZCAMERA_IRONSIGHTS || pTo == DAYZCAMERA_IRONSIGHTS)
            return Math.Min(originalTime, GRZQuickScopePolicy.IRONSIGHT_BLEND_SECONDS);
        return originalTime;
    }
}

modded class DayZPlayerCameraOptics
{
    override void SetCameraPPDelay(DayZPlayerCamera pPrevCamera)
    {
        super.SetCameraPPDelay(pPrevCamera);
        // The native camera schedules its own effects/clothing handling using
        // this delay. Match those effects to the direct firearm scope entry.
        if (m_weaponUsed && m_opticsUsed && GRZQuickScopePolicy.IsSupportedSource(pPrevCamera) && GetGame() && GetGame().GetPlayer() == m_pPlayer)
            m_CameraPPDelay = 0;
    }
}
#endif
