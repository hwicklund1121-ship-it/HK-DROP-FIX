GRZ Sprint Lean Restore TEST
Only runtime change from GRZ-SprintStart-Test: call inherited OnSprintStart, then Unlock UALeanLeft and UALeanRight on client instances.
Original snappy response settings remain 0.06 / 100 / 0.14 / 17 / 6.5.
APIs verified against BohemiaInteractive/DayZ-Script-Diff commit e8204c69fcfd056ea29a9728990fd9f7941ce8a6.
IMPORTANT: that native callback only locks lean inputs. Unlocking them may restore the jitter; no extra native movement cleanup is shown. This is an experiment, not a confirmed fix.
Back up your working jitter-free PBO outside loaded addon folders. Replace GRZ_Movement.pbo on BOTH test server and clients; do not load duplicate versions. Restart both.
Unsigned: use your normal signing process if required.
Test sprint lean in both directions, sprint-stop, jog-stop, crouch-run-stop, and releasing lean before/after stopping. Have a second player observe. If jitter returns, restore the previous PBO and restart both.
Validation: all 13 packaged payloads, PBO checksum, ZIP integrity, client/SERVER preprocessing. No Enforce compiler or DayZ runtime validation performed.
